package MobileAutomationTask;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.concurrent.ConcurrentHashMap.KeySetView;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class MATask1 {

	public static void main(String[] args) throws InterruptedException, AWTException {
		
		AndroidDriver driver = null;
	
		        // Set desired capabilities
		        DesiredCapabilities caps = new DesiredCapabilities();

		        // Device details
		        caps.setCapability("platformName", "Android");           // Platform (Android/iOS)
		        caps.setCapability("appium:platformVersion", "12.0");          // Android OS version
		        caps.setCapability("appium:deviceName", "emulator-5554");      // Device name or ID
//		        caps.setCapability("appium:udid", "2C060DLH20004Y");            // Unique device identifier (optional for emulators)
		        caps.setCapability("appium:automationName", "UiAutomator2");   // Automation engine

		        // App details
//		        caps.setCapability("appium:app", "D:\\Multic.apk");      // Full path to your APK
		        caps.setCapability("appium:appPackage", "com.jee.calc");    // Package name of the app
		        caps.setCapability("appium:appActivity", "com.jee.calc.ui.activity.MainActivity");     // Main activity of the app

		        // Optional capabilities
		        caps.setCapability("appium:noReset", true);                   // Skip resetting app state
//		        caps.setCapability("fullReset", false);                // Avoid uninstalling the app
		        caps.setCapability("appium:autoGrantPermissions", true);      // Automatically grant app permissions
		        caps.setCapability("appium:skipDeviceInitialization", true);  // Skip device initialization for faster runs

		        try {
		            // Convert string to URL
		            URL appiumServerURL = new URL("http://127.0.0.1:4723/wd/hub");

//		            // Initialize AppiumDriver with the URL
		            URL appiumServerUrl = URI.create("http://172.40.10.109:4723").toURL();

		            driver = new AndroidDriver(appiumServerURL, caps);
		            Thread.sleep(5000);
		            driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.jee.calc:id/calc_clear_button\"]")).click();
		            driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.jee.calc:id/calc_num_2_button\"]")).click();
		            driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.jee.calc:id/calc_multiply_button\"]")).click();
		            driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.jee.calc:id/calc_num_2_button\"]")).click();
		            driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.jee.calc:id/calc_result_button\"]")).click();
		            driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.jee.calc:id/calc_clear_button\"]")).click();
		         
		            driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.jee.calc:id/calc_num_3_button\"]")).click();
		            driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.jee.calc:id/calc_num_5_button\"]")).click();
		            driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.jee.calc:id/calc_num_00_button\"]")).click();
		            driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.jee.calc:id/calc_num_7_button\"]")).click();
//		            driver.rotate(ScreenOrientation.LANDSCAPE);
//		            
//		            driver.lockDevice();
//		            driver.unlockDevice();
//		            WebElement passwordInput =  driver.findElement(By.xpath("//android.widget.LinearLayout[@resource-id=\"com.android.systemui:id/keyguard_selector_fade_container\"]"));
//		            Robot robot = new Robot();
//		            
//		            robot.keyPress(KeyEvent.VK_1);
//		            robot.keyRelease(KeyEvent.VK_1);
//		            
//		            robot.keyPress(KeyEvent.VK_2);
//		            robot.keyRelease(KeyEvent.VK_2);
//		            
//		            robot.keyPress(KeyEvent.VK_3);
//		            robot.keyRelease(KeyEvent.VK_3);
//		            
//		            robot.keyPress(KeyEvent.VK_4);
//		            robot.keyRelease(KeyEvent.VK_4);
//		            
//		            robot.keyPress(KeyEvent.VK_5);
//		            robot.keyRelease(KeyEvent.VK_5);
//		            
//		            
////		            passwordInput.sendKeys("12345");
//		            passwordInput.sendKeys(Keys.ENTER);

		            System.out.println("App launched successfully using Appium!");

		            // Perform actions here...

		            // Quit the driver
		            driver.quit();

		        } catch (MalformedURLException e) {
		            System.out.println("The provided URL is invalid.");
		            e.printStackTrace();
		        }

		        // Quit the driver
		        driver.quit();
		    }
		}

	
