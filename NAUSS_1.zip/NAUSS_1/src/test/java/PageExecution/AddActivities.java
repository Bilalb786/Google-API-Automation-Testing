package PageExecution;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;

import BaseClassPackage.BaseClass;

import static org.junit.Assert.assertTrue;
import dev.failsafe.internal.util.Assert;
import io.github.bonigarcia.wdm.WebDriverManager;

public class AddActivities extends BaseClass {

	public AddActivities(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

//	public AddActivities(WebDriver driver) {
//		super(driver);
//		// TODO Auto-generated constructor stub
//	}

//	static WebDriver driver;

	private static final String APPLICATION_NAME = "Google Sheets API";
	private static final JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();
	private static final String TOKENS_DIRECTORY_PATH = "tokens/path";

	private static final String existingSpreadSheetID = "13gfYl2OOdykh-oXCHtrygUDYETRCI2NXa7XPKT6hQoA";
	private static final List<String> SCOPES = Arrays.asList(SheetsScopes.SPREADSHEETS, SheetsScopes.DRIVE);
	private static final String CREDENTIALS_FILE_PATH = "/credentials.json";

	static Sheets.Spreadsheets spreadsheets;

	private static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
		InputStream in = SheetWriteExample.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
		if (in == null) {
			throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
		}
		GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

		GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(HTTP_TRANSPORT, JSON_FACTORY,
				clientSecrets, SCOPES)
				.setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
				.setAccessType("offline").build();

		LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
		return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
	}

	public static String path = System.getProperty("user.dir");

	public static void ScreenShot(WebDriver driver, String name) {
		// Specify the folder path where you want to save the extent report
		String folderPath = path + "/Screenshot/";

		// Create folder if it doesn't exist
		File folder = new File(folderPath);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		try {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File src = ts.getScreenshotAs(OutputType.FILE);
			File des = new File(folderPath + name + ".png");
			FileHandler.copy(src, des);
			// System.out.println("Screenshot saved at: " + des.getAbsolutePath());
		} catch (IOException e) {
			// e.printStackTrace();
			System.err.println("Error occurred while taking a screenshot: " + e.getMessage());
		}
	}

	public static WebElement waitForElementToBeClickable(By locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.elementToBeClickable(locator));
	}

	public static WebElement waitForElementToBeVisible(By locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}

	public WebDriverWait wait;

	public WebElement waitForElementToBePresent(By locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}

	public boolean waitForTextToBePresentInElement(By locator, String text, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
	}

	public boolean waitForElementToBeInvisible(By locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
	}

	public void verifyTextVisible(String expectedText, By locator) {
		// Wait until the element with the text is visible
		WebElement element = waitForElementToBeVisible(locator, 10);

		// Check if the element contains the expected text
		assertTrue("Text not visible or incorrect!", element.getText().contains(expectedText));

	}

	public static boolean isRadioButtonChecked(By locator) {
		try {
			WebElement radioButton = driver.findElement(locator);
			return radioButton.isSelected();
		} catch (NoSuchElementException e) {
			System.out.println("Radio button not found: " + e.getMessage());
			return false;
		}
	}

	public static void dragAndDrop(By sourceLocator, By targetLocator) {
		try {
			// Find source and target elements
			WebElement sourceElement = driver.findElement(sourceLocator);
			WebElement targetElement = driver.findElement(targetLocator);

			// Create Actions object
			Actions actions = new Actions(driver);

			// Perform drag and drop
			actions.dragAndDrop(sourceElement, targetElement).build().perform();
		} catch (Exception e) {
			System.out.println("Drag and drop failed: " + e.getMessage());
		}
	}

	public static void safeClickWithRetry(WebDriver driver, By locator) {
		int retries = 3; // Number of attempts
		for (int i = 0; i < retries; i++) {
			try {
				WebElement element = driver.findElement(locator);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
				break; // Break loop if click is successful
			} catch (StaleElementReferenceException e) {
				System.out.println("StaleElementReferenceException encountered. Retrying...");
			}
		}
	}

	public static void main(String[] args) throws IOException, GeneralSecurityException, TimeoutException {

//		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Google\\Chrome\\Application\\chromedriver.exe");

		WebElement element;
		WebElement courseLink;
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		AddActivities assertions = new AddActivities(driver);
		WebElement message;
		driver = new ChromeDriver();
		WebDriverManager.chromedriver().setup();
		driver.manage().window().maximize();
		driver.get(getColumnRow(1, 1));
		System.out.println("Chrome Browser is Launched");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Actions act = new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		WebElement SelectLag = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='select-selected']")));
		SelectLag.click();
		driver.findElement(By.xpath("//div[@class='select-item dropdown-en']")).click();
		driver.findElement(By.id("username")).sendKeys(getColumnRow(2, 1));
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys(getColumnRow(3, 1));
		driver.findElement(By.id("loginbtn")).click();

		driver.findElement(By.xpath("(//button[@class='language-select-box'])[1]")).click();
		driver.findElement(By.xpath("(//button[@id=\"en-btn\"])[1]")).click();
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement SelectCourse = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@data-course-id=1869])[2]")));
		SelectCourse.click();
		WebElement EditMode = driver.findElement(By.name("setmode"));
		EditMode.click();

		// Click Course Content tab
		try {
			driver.findElement(By.id("coursestructure-tab")).click();
		} catch (StaleElementReferenceException e) {
			driver.findElement(By.id("coursestructure-tab")).click();
		}

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		WebElement addActivity_btn = driver.findElement(By.xpath("//div[@id='coursecontentcollapse0']/button"));

		try {
			// Wait until the element is visible and clickable
			waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
			addActivity_btn = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
		} catch (TimeoutException e) {
			System.out.println("Element not found or not visible within timeout period");
		}

//		js1.executeScript("arguments[0].scrollIntoView(true);", addActivity_btn);
//		addActivity_btn.click();

		try {
			addActivity_btn.click();
		} catch (StaleElementReferenceException e) {
			addActivity_btn = driver.findElement(By.xpath("//div[@id='coursecontentcollapse0']/button"));
			addActivity_btn.click();
		}

		// Click Announcement tab
//		try {
//			driver.findElement(By.id("announcement-tab")).click();
//		} catch (StaleElementReferenceException e) {
//			driver.findElement(By.id("announcement-tab")).click();
//		}
//
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		WebElement Announcement =  waitForElementToBeVisible(By.xpath("//a/button/span[text()='Announcements']"),10);
//		 Announcement =  waitForElementToBeClickable(By.xpath("//a/button/span[text()='Announcements']"),30);
//		((JavascriptExecutor) driver).executeScript("arguments[0].click();", Announcement);
//		driver.findElement(By.xpath("//input[@id='id_subject']")).clear();
//	    driver.findElement(By.xpath("//input[@id='id_subject']")).sendKeys(getColumnRow(6, 1));
//	    driver.findElement(By.xpath("//textarea[@id=\"id_message\"]")).clear();
//	    driver.findElement(By.xpath("//textarea[@id=\"id_message\"]")).sendKeys(getColumnRow(7, 1));
//	    driver.findElement(By.xpath("//input[@id=\"id_submitbutton\"]")).click();
//	    AddActivities assertions = new AddActivities(driver);
//	    assertions.verifyTextVisible("Announcement - Activity", By.xpath("//*[@id='example']/tbody/tr/td[1]/a"));
//	    System.out.println("Announcement is present");

		// Participant tab
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		try {
//			driver.findElement(By.id("participant-tab")).click();
//		} catch (StaleElementReferenceException e) {
//			driver.findElement(By.id("participant-tab")).click();
//		}
//
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		//sms
//		WebElement MessageIcon = driver.findElement(By.xpath("//div[contains(@class,'sms-icon')]"));
//		
//		try {
//			boolean isEnabled = MessageIcon.isSelected();
//			if (isEnabled) {
//	            System.out.println("The button is enabled.");
//	        } else {
//	            System.out.println("The button is not enabled.");
//	        }
//		} catch (Exception e) {
//			 e.printStackTrace();
//		}
//		driver.findElement(By.xpath("//td[text()='202300292']//preceding::td//input")).click();
//		MessageIcon.click();
//		
//		By sms_radioButtonLocator = By.xpath("//div[contains(@class,'form-check')]//input[@value='sendsms']");
//		boolean isChecked = isRadioButtonChecked(sms_radioButtonLocator);
//
//        // Print the result
//        if (isChecked) {
//            System.out.println("Radio button is checked.");
//        } else {
//            System.out.println("Radio button is not checked.");
//        }
//        
//        waitForElementToBeClickable(By.xpath("//button[@id='submitButton']"),10);
//        driver.findElement(By.xpath("//button[@id='submitButton']")).click();
//        try {
//            WebElement Errormessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='smsInputBody1']/span")));
//            assertTrue("Expected error message is not visible or does not contain the correct text.",
//                    Errormessage.isDisplayed() && Errormessage.getText().contains("Please enter text to be sent as SMS"));
//     } catch (NoSuchElementException e) {
//         System.out.println("Error element not found: " + e.getMessage());
//     } catch (TimeoutException e) {
//         System.out.println("Error element not visible within wait time: " + e.getMessage());
//     } catch (Exception e) {
//         System.out.println("Unexpected error: " + e.getMessage());
//     }
//        System.out.println("Error is display successfully");
//        
//        driver.findElement(By.xpath("//*[@id=\"smsInputBody1\"]/input")).sendKeys(getColumnRow(8,1));
//        driver.findElement(By.xpath("//button[@id='submitButton']")).click();
//        
//        //maill
//        try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//        
//		driver.findElement(By.xpath("//td[text()="+getColumnRow(11,1)+"]//preceding::td//input")).click();
//		
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		waitForElementToBeClickable(By.xpath("//div[contains(@class,'sms-icon')]"),30);
//		try {
//		    WebElement messageIcon = driver.findElement(By.xpath("//div[contains(@class,'sms-icon')]")); // Adjust locator as needed
//		    messageIcon.click();
//		} catch (StaleElementReferenceException e) {
//		    // Re-locate the element and try clicking again
//		    WebElement messageIcon = driver.findElement(By.xpath("//div[contains(@class,'sms-icon')]")); // Adjust locator as needed
//		    messageIcon.click();
//		}
//		
//		WebElement mail_radioButton = driver.findElement(By.xpath("//div[contains(@class,'form-check')]//input[@value='sendemail']"));
//		
//		
//		By mail_radioButtonLocator = By.xpath("//div[contains(@class,'form-check')]//input[@value='sendemail']");
//		waitForElementToBeClickable(By.xpath("//div[contains(@class,'form-check')]//input[@value='sendemail']"),10);
//		mail_radioButton.click();
//		 isChecked = isRadioButtonChecked(mail_radioButtonLocator);
//
//        // Print the result
//        if (isChecked) {
//            System.out.println("Radio button is checked.");
//        } else {
//            System.out.println("Radio button is not checked.");
//        }
//		
//        waitForElementToBeClickable(By.xpath("//button[@id='submitButton']"),10);
//        driver.findElement(By.xpath("//button[@id='submitButton']")).click();
//        assertions.verifyTextVisible("Please enter Subject Line of email.", By.xpath("//div[@id='smsInputBody2']//span[text()='Please enter Subject Line of email.']"));
//        System.out.println("Error is display successfully");
//        driver.findElement(By.xpath("//*[@id='smsInputBody2']//input[@name='emailsubject']")).sendKeys(getColumnRow(9,1));
//        driver.findElement(By.xpath("//button[@id='submitButton']")).click();
//        assertions.verifyTextVisible("Please enter some content in email body.", By.xpath("//div[@id='smsInputBody2']//span[text()='Please enter some content in email body.']"));
//        System.out.println("Error is display successfully");
//        
//        try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//        driver.switchTo().frame(0);
//        WebElement message = driver.findElement(By.id("tinymce"));
//                message.sendKeys(getColumnRow(10,1));
//
//                driver.switchTo().defaultContent();
//                
//                driver.findElement(By.xpath("//button[@id='submitButton']")).click();
//                
//                System.out.println("Successfully message send");

		// Assignment Activity - Done
		// ------------------------------------------------------------------------------------>

		System.out.println(getColumnRow(4, 2));
		String run = "yes";
		if (getColumnRow(4, 2).equals(run)) {
			driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
			element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"), 10);
			element.click();
			WebElement Assignment = waitForElementToBeVisible(By.xpath(
					"(//div[contains(@id,'all')]/div/div[@aria-label='Assignment']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Assignment'])[1]"),
					10);
			Assignment = waitForElementToBeClickable(By.xpath(
					"(//div[contains(@id,'all')]/div/div[@aria-label='Assignment']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Assignment'])[1]"),
					30);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", Assignment);
			driver.findElement(By.id("id_name")).click();
			driver.findElement(By.id("id_name")).clear();
			driver.findElement(By.id("id_name")).sendKeys(getColumnRow(4, 1));
			driver.findElement(By.id("id_submitbutton")).click();
			driver.get("https://qalms.nauss.edu.sa/mod/assign/view.php?id=6118&forceview=1");

			try {
				// Check if the "grade" text is present
				WebElement Grades = driver.findElement(By.linkText("Grade"));
				if (Grades.isDisplayed()) {
					// Click on the grade button if "grade" text is present
					Grades.click();
					driver.get("https://qalms.nauss.edu.sa/mod/assign/view.php?id=6118&action=grader");
					driver.findElement(By.id("id_grade")).click();
					driver.findElement(By.id("id_grade")).clear();
					driver.findElement(By.id("id_grade")).sendKeys(getColumnRow(5, 1));
					driver.findElement(By.xpath("//button[@name='savechanges']")).click();
					System.out.println("Clicked on Grade Button.");
				}
			} catch (NoSuchElementException e) {
				// If "grade" text is not present, click on the continue button
				WebElement continueButton = driver.findElement(By.xpath("//button[text()='Continue']"));
				continueButton.click();
				System.out.println("Clicked on Continue Button.");
			}

			driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869");
			driver.findElement(By.id("coursestructure-tab")).click();

			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				EditMode = driver.findElement(By.name("setmode"));
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", EditMode);
			} catch (StaleElementReferenceException e) {
				EditMode = driver.findElement(By.name("setmode"));
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", EditMode);
			}
			System.out.println("Assignment Activity Successfully Completed");
		}

		// Attendance Activity - Done
		// ------------------------------------------------------------------------------------>

		driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
		waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"), 10);
		element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"), 10);
		element.click();
		WebElement Attendance = waitForElementToBeVisible(By.xpath(
				"(//div[contains(@id,'all')]/div/div[@aria-label='Attendance']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Attendance'])[1]"),
				10);
		Attendance = waitForElementToBeClickable(By.xpath(
				"(//div[contains(@id,'all')]/div/div[@aria-label='Attendance']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Attendance'])[1]"),
				30);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", Attendance);
		driver.get(
				"https://qalms.nauss.edu.sa/course/modedit.php?add=attendance&type&course=1869&section=0&return=0&sr=0&beforemod=0");
		driver.findElement(By.id("id_name")).click();
		driver.findElement(By.id("id_name")).click();
		driver.findElement(By.id("id_name")).clear();
		driver.findElement(By.id("id_name")).sendKeys(getColumnRow(12, 1));

		WebElement save_btn = driver.findElement(By.id("id_submitbutton"));
//		js1.executeScript("arguments[0].scrollIntoView(true);", save_btn);
		save_btn.click();

		waitForElementToBeVisible(By.xpath("//button[text()='Continue']"), 30);
		driver.findElement(By.xpath("//button[text()='Continue']")).click();
		driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
		driver.findElement(By.id("coursestructure-tab")).click();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			// Wait until the element is present in the DOM and visible
			waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
		} catch (StaleElementReferenceException e) {
			System.out.println(" ");
		}
		System.out.println("Attendance Activity Successfully Completed");

		// book activity - done
		// ------------------------------------------------------------------------------------>

//		driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
//		element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"), 10);
//		element.click();
//		WebElement Book = waitForElementToBeVisible(By.xpath(
//				"(//div[contains(@id,'all')]/div/div[@aria-label='Book']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Book'])[1]"),
//				10);
//		Book = waitForElementToBeClickable(By.xpath(
//				"(//div[contains(@id,'all')]/div/div[@aria-label='Book']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Book'])[1]"),
//				30);
//		driver.get(
//				"https://qalms.nauss.edu.sa/course/modedit.php?add=book&type&course=1869&section=0&return=0&sr=0&beforemod=0");
//		driver.findElement(By.id("id_name")).click();
//		driver.findElement(By.id("id_name")).clear();
//		driver.findElement(By.id("id_name")).sendKeys("Activity-Books");
//		driver.findElement(By.id("id_submitbutton")).click();
//		driver.get("https://qalms.nauss.edu.sa/mod/book/edit.php?cmid=6130");
//		
//		try {
//			
//			WebElement Title = driver.findElement(By.id("id_title"));
//			if (Title.isDisplayed()) {
//				
//				driver.findElement(By.id("id_title")).click();
//				driver.findElement(By.id("id_title")).clear();
//				driver.findElement(By.id("id_title")).sendKeys("Test Chapter");
//
//				driver.findElement(By.xpath("//html")).click();
//
//				driver.findElement(By.id("id_submitbutton")).click();
//				System.out.println("Clicked on submit Button.");
//			}
//		} catch (NoSuchElementException e) {
//			// If "grade" text is not present, click on the continue button
//			WebElement continueButton = driver.findElement(By.xpath("//button[text()='Continue']"));
//			continueButton.click();
//			continueButton.click();
//			System.out.println("Clicked on Continue Button.");
//		}
//
//		driver.get("https://qalms.nauss.edu.sa/mod/book/view.php?id=6130&chapterid=88");
//		((JavascriptExecutor) driver).executeScript("arguments[0].click();",
//				By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]"));
//		driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869");
//		driver.findElement(By.id("coursestructure-tab")).click();
//
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		try {
//			// Wait until the element is present in the DOM and visible
//			waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
//			((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
//		} catch (StaleElementReferenceException e) {
//			System.out.println(" ");
//		}
//		
//		try {
//			Thread.sleep(4000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		 SelectCourse = wait
//				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@data-course-id=1869])[2]")));
//		SelectCourse.click();
//		 EditMode = driver.findElement(By.name("setmode"));
//		EditMode.click();
//
//		// Click Course Content tab
//		try {
//			driver.findElement(By.id("coursestructure-tab")).click();
//		} catch (StaleElementReferenceException e) {
//			driver.findElement(By.id("coursestructure-tab")).click();
//		}
//
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		try {
//			// Wait until the element is present in the DOM and visible
//			waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
//			((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
//		} catch (StaleElementReferenceException e) {
//			System.out.println(" ");
//		}
////		js1.executeScript("arguments[0].scrollIntoView(true);", addActivity_btn);
////		addActivity_btn.click();
//
//		try {
//			addActivity_btn.click();
//		} catch (StaleElementReferenceException e) {
//			addActivity_btn = driver.findElement(By.xpath("//div[@id='coursecontentcollapse0']/button"));
//			addActivity_btn.click();
//		}

		// or getting error
//		driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869"); // <--
//		driver.findElement(By.id("coursestructure-tab")).click();
//
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		try {
//			 EditMode = driver.findElement(By.name("setmode"));
//		    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", EditMode);
//		} catch (StaleElementReferenceException e) {
//			 EditMode = driver.findElement(By.name("setmode"));
//		    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", EditMode);
//		}

		// Certificate Activity - Done
		// ------------------------------------------------------------------------------------>

		driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
		element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"), 10);
		element.click();
		WebElement Certificate = waitForElementToBeVisible(By.xpath(
				"(//div[contains(@id,'all')]/div/div[@aria-label='Certificate']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Certificate'])[1]"),
				10);
		Certificate = waitForElementToBeClickable(By.xpath(
				"(//div[contains(@id,'all')]/div/div[@aria-label='Certificate']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Certificate'])[1]"),
				30);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", Certificate);
		driver.get(
				"https://qalms.nauss.edu.sa/course/modedit.php?add=certificate&type&course=1869&section=0&return=0&sr=0&beforemod=0");
		driver.findElement(By.id("id_name")).click();
		driver.findElement(By.id("id_name")).clear();
		driver.findElement(By.id("id_name")).sendKeys(getColumnRow(13, 1));
		driver.findElement(By.id("id_submitbutton")).click();

		driver.get("https://qalms.nauss.edu.sa/mod/certificate/view.php?id=6138&forceview=1");

		try {
			courseLink = driver.findElement(By.xpath("//html/body/div[5]/div[1]/div[3]/div[2]/nav/ol/li[3]/a"));
			if (courseLink.isDisplayed()) {
				courseLink = waitForElementToBeClickable(
						By.xpath("//html/body/div[5]/div[1]/div[3]/div[2]/nav/ol/li[3]/a"), 30);
				js1.executeScript("arguments[0].click();", courseLink);
			}
		} catch (NoSuchElementException e) {
			WebElement continueButton = driver.findElement(By.xpath("//button[text()='Continue']"));
			continueButton.click();
			System.out.println("Clicked on Continue Button.");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			SelectCourse = wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("(//a[@href=\"../course/view.php?id=1869\"])[1]")));
			SelectCourse.click();

			safeClickWithRetry(driver, By.name("setmode"));

			driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869");
			driver.findElement(By.id("coursestructure-tab")).click();

			try {
				Thread.sleep(2000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			try {
				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 40);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}
			System.out.println("Certificate Activity Successfully Completed");

			// Chat Activity - Done
			// ------------------------------------------------------------------------------------>
			driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
			try {
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						30);
				element.click();
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}
			try {
				WebElement Chat = waitForElementToBeVisible(By.xpath(
						"(//div[contains(@id,'all')]/div/div[@aria-label='Chat']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Chat'])[1]"),
						30);
				Chat = waitForElementToBeClickable(By.xpath(
						"(//div[contains(@id,'all')]/div/div[@aria-label='Chat']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Chat'])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", Chat);
				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=chat&type&course=1869&section=0&return=0&sr=0&beforemod=0");
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(14, 1));
				driver.findElement(By.id("id_submitbutton")).click();
				driver.get("https://qalms.nauss.edu.sa/mod/chat/view.php?id=6141&forceview=1");
				driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869");
				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("Chat Activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// Checklist activity - done
			// ------------------------------------------------------------------------------------>
			driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
			try {
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						30);
				element.click();
				WebElement Checklist = waitForElementToBeVisible(By.xpath(
						"(//div[contains(@id,'all')]/div/div[@aria-label='Checklist']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Checklist'])[1]"),
						30);
				Checklist = waitForElementToBeClickable(By.xpath(
						"(//div[contains(@id,'all')]/div/div[@aria-label='Checklist']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Checklist'])[1]"),
						30);
				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=checklist&type&course=1869&section=0&return=0&sr=0&beforemod=0");
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(15, 1));
				driver.findElement(By.id("id_submitbutton")).click();
				waitForElementToBeVisible(By.xpath("//button[text()='Continue']"), 30);
				WebElement Continue_btn = waitForElementToBeClickable(By.xpath("//button[text()='Continue']"), 30);
				Continue_btn.click();
				driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("Checklist activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// Choice activity - Done
			// ------------------------------------------------------------------------------------>
			driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
			try {
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						30);
				element.click();
				WebElement Choice = waitForElementToBeVisible(By.xpath(
						"(//div[contains(@id,\"all\")]/div/div[@aria-label='Choice']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Choice'])[1]"),
						30);
				Choice = waitForElementToBeClickable(By.xpath(
						"(//div[contains(@id,\"all\")]/div/div[@aria-label='Choice']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Choice'])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", Choice);
				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=choice&type&course=1869&section=0&return=0&sr=0&beforemod=0");
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(16, 1));
				driver.findElement(By.id("id_option_0")).click();
				driver.findElement(By.id("id_option_0")).clear();
				driver.findElement(By.id("id_option_0")).sendKeys(getColumnRow(16, 2));
				driver.findElement(By.id("id_submitbutton")).click();
				driver.get("https://qalms.nauss.edu.sa/mod/choice/view.php?id=6144&forceview=1");
				driver.findElement(By.linkText("Responses")).click();
				driver.get("https://qalms.nauss.edu.sa/mod/choice/report.php?id=6144");
				driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}

				addActivity_btn = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button"),
						30);
				addActivity_btn.click();

				try {
					addActivity_btn.click();
				} catch (StaleElementReferenceException e1) {
					addActivity_btn = driver.findElement(By.xpath("//div[@id='coursecontentcollapse0']/button"));
					addActivity_btn.click();
				}
				System.out.println("Choice activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// Custom Certificate - done
			// ------------------------------------------------------------------------------------>
			driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
			try {
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						30);
				element.click();
				WebElement CustomCertificate = waitForElementToBeVisible(By.xpath(
						"(//div[@data-region=\"chooser-option-info-container\"]/following::a[@href='https://qalms.nauss.edu.sa/course/mod.php?id=1869&add=customcert&section=0&sr=0&beforemod=0' and @title='Add a new Custom certificate' and @data-action=\"add-chooser-option\"])[1]"),
						30);
				CustomCertificate = waitForElementToBeClickable(By.xpath(
						"(//div[@data-region=\"chooser-option-info-container\"]/following::a[@href='https://qalms.nauss.edu.sa/course/mod.php?id=1869&add=customcert&section=0&sr=0&beforemod=0' and @title='Add a new Custom certificate' and @data-action=\"add-chooser-option\"])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", CustomCertificate);

				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=customcert&type&course=1869&section=0&return=0&sr=0&beforemod=0");
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(17, 1));
				driver.findElement(By.id("id_submitbutton")).click();
				driver.get("https://qalms.nauss.edu.sa/mod/customcert/view.php?id=6157&forceview=1");
				driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869");
				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("Custom Certificate activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// Database activity - Done
			// ------------------------------------------------------------------------------------>
			try {
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						30);
				element.click();
				WebElement Database = waitForElementToBeVisible(By.xpath(
						"(//div[contains(@id,\"all\")]/div/div[@aria-label='Database']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Database'])[1]"),
						30);
				Database = waitForElementToBeClickable(By.xpath(
						"(//div[contains(@id,\"all\")]/div/div[@aria-label='Database']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Database'])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", Database);

				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=data&type&course=1869&section=0&return=0&sr=0&beforemod=0");
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(18, 1));
				driver.findElement(By.id("id_submitbutton")).click();
				driver.get("https://qalms.nauss.edu.sa/mod/data/view.php?id=6165&forceview=1");
				driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869");
				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("Database activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// External activity - Done
			// ------------------------------------------------------------------------------------>

			driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
			try {
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						10);
				element.click();
				WebElement External_tool = waitForElementToBeVisible(By.xpath(
						"(//div[contains(@id,\"all\")]/div/div[@aria-label='External tool']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new External tool'])[1]"),
						10);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", External_tool);
				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=lti&type&course=1869&section=0&return=0&sr=0&beforemod=0");
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(19, 1));
				driver.findElement(By.id("id_submitbutton")).click();
				waitForElementToBeVisible(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]"), 30);
				driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869");

				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("External - Activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// Feedback activity - Done
			// ------------------------------------------------------------------------------------>
			driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
			element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"), 30);
			element.click();
			driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
			try {
				WebElement Feedback = waitForElementToBeVisible(By.xpath(
						"(//a[@href='https://qalms.nauss.edu.sa/course/mod.php?id=1869&add=feedback&section=0&sr=0&beforemod=0'])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", Feedback);
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}
			driver.findElement(By.id("id_name")).click();
			driver.findElement(By.id("id_name")).clear();
			driver.findElement(By.id("id_name")).sendKeys(getColumnRow(20, 1));
			driver.findElement(By.id("id_submitbutton")).click();
			driver.get("https://qalms.nauss.edu.sa/mod/feedback/view.php?id=6167&forceview=1");
			driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
			driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869");

			try {
				driver.findElement(By.id("coursestructure-tab")).click();
			} catch (StaleElementReferenceException e1) {
				driver.findElement(By.id("coursestructure-tab")).click();
			}

			try {
				Thread.sleep(2000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			try {
				// Wait until the element is present in the DOM and visible
				waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
			} catch (StaleElementReferenceException e1) {
				System.out.println(" ");
			}
			System.out.println("Feedback - Activity Successfully Completed");

			// File Activity
			// ------------------------------------------------------------------------------------>

//		driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
//		element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"), 30);
//		element.click();
//		driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
//		WebElement File = waitForElementToBeVisible(By.xpath(
//				"(//div[contains(@id, 'all')]/div/div[@aria-label='File']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new File'])[3]"),
//				30);
//		waitForElementToBeClickable(By.xpath(
//				"(//div[contains(@id, 'all')]/div/div[@aria-label='File']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new File'])[3]"),
//				30);
//		driver.get(
//				"https://qalms.nauss.edu.sa/course/modedit.php?add=resource&type&course=1869&section=0&return=0&sr=0&beforemod=0");
//		driver.findElement(By.id("id_name")).click();
//		driver.findElement(By.id("id_name")).clear();
//		driver.findElement(By.id("id_name")).sendKeys("File - Activity");
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e1){
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		WebElement upload = driver.findElement(By.xpath("(//div/div/div[2]/div/div/i)[1]"));
//		act.scrollToElement(upload).build().perform();
//		dragAndDrop(By.xpath("C:\\fakepath\\NAUSS testing notes.txt"), By.xpath("(//div/div/div[2]/div/div/i)[1]"));
//	
//		((JavascriptExecutor) driver).executeScript("arguments[0].click();", upload);
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e1){
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		waitForElementToBeVisible(By.xpath("//input[@name='repo_upload_file']"), 30);
//		driver.findElement(By.xpath("//input[@name='repo_upload_file']")).click();
//		driver.findElement(By.xpath("//input[@name='repo_upload_file']")).clear();
//		driver.findElement(By.xpath("//input[@name='repo_upload_file']"))
//				.sendKeys("C:\\fakepath\\NAUSS testing notes.txt");
//		driver.findElement(By.xpath("//input[@name='repo_upload_file']")).click();
//		driver.findElement(By.id("id_submitbutton")).click();
//		driver.get("https://qalms.nauss.edu.sa/mod/resource/view.php?id=6170&forceview=1");
//		driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
//		driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869");
//
//		try {
//			driver.findElement(By.id("coursestructure-tab")).click();
//		} catch (StaleElementReferenceException e1){
//			driver.findElement(By.id("coursestructure-tab")).click();
//		}
//
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e1){
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		try {
//			// Wait until the element is present in the DOM and visible
//			waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
//			((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
//		} catch (StaleElementReferenceException e1){
//			System.out.println(" ");
//		}

			// Folder Activity - Done
			// ------------------------------------------------------------------------------------>
			try {
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						10);
				element.click();
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				WebElement Folder = driver.findElement(By.xpath(
						"(//a[@href='https://qalms.nauss.edu.sa/course/mod.php?id=1869&add=folder&section=0&sr=0&beforemod=0'])[1]"));
				waitForElementToBeVisible(By.xpath(
						"(//a[@href='https://qalms.nauss.edu.sa/course/mod.php?id=1869&add=folder&section=0&sr=0&beforemod=0'])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", Folder);
				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=folder&type&course=1869&section=0&return=0&sr=0&beforemod=0");
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(21, 1));
				driver.findElement(By.id("id_submitbutton")).click();
				driver.get("https://qalms.nauss.edu.sa/mod/folder/view.php?id=6172&forceview=1");
				driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869");

				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("Folder - Activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// Forum Activity - Done
			// ------------------------------------------------------------------------------------>
			try {
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						10);
				element.click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				WebElement Forum = waitForElementToBeVisible(By.xpath(
						"(//a[@href='https://qalms.nauss.edu.sa/course/mod.php?id=1869&add=forum&section=0&sr=0&beforemod=0'])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", Forum);
				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=forum&type&course=1869&section=0&return=0&sr=0&beforemod=0");
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(22, 1));
				driver.findElement(By.id("id_submitbutton")).click();
				driver.get("https://qalms.nauss.edu.sa/mod/forum/view.php?id=6173&forceview=1");
				driver.findElement(By.id("id_subject")).click();
				driver.findElement(By.id("id_subject")).clear();
				driver.findElement(By.id("id_subject")).sendKeys(getColumnRow(22, 2));
				driver.findElement(By.xpath("//html")).click();
				driver.findElement(By.id("id_submitbutton")).click();
				driver.get("https://qalms.nauss.edu.sa/course/discussion.php?id=1869");
				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("Forum Activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// Glossary Activity - Done
			// ------------------------------------------------------------------------------------>
			try {
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						10);
				element.click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				WebElement Glossary = waitForElementToBeVisible(By.xpath(
						"(//a[@href='https://qalms.nauss.edu.sa/course/mod.php?id=1869&add=glossary&section=0&sr=0&beforemod=0'])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", Glossary);
				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=glossary&type&course=1869&section=0&return=0&sr=0&beforemod=0");
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(23, 1));
				driver.findElement(By.id("id_submitbutton")).click();
				driver.get("https://qalms.nauss.edu.sa/mod/glossary/view.php?id=6177&forceview=1");
				driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869");
				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("Glossary Activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// H5P Activity
			// ------------------------------------------------------------------------------------>
//	    driver.findElement(By.xpath("//div[@id='all-4']/div/div[17]/div/a/div[2]")).click();
//	    driver.get("https://qalms.nauss.edu.sa/course/modedit.php?add=h5pactivity&type&course=1869&section=0&return=0&sr=0&beforemod=0");
//	    driver.findElement(By.id("id_name")).click();
//	    driver.findElement(By.id("id_name")).clear();
//	    driver.findElement(By.id("id_name")).sendKeys("H5P - Activity");
//	    //ERROR: Caught exception [ERROR: Unsupported command [selectFrame | index=0 | ]]
//	    driver.findElement(By.xpath("//html")).click();
//	    //ERROR: Caught exception [unknown command [editContent]]
//	    //ERROR: Caught exception [ERROR: Unsupported command [selectFrame | relative=parent | ]]
//	    driver.findElement(By.xpath("//div[@id='yui_3_18_1_1_1730701348937_579']/div/div[2]/div/div")).click();
//	    driver.findElement(By.id("yui_3_18_1_1_1730701348937_1288")).click();
//	    driver.findElement(By.id("yui_3_18_1_1_1730701348937_1288")).clear();
//	    driver.findElement(By.id("yui_3_18_1_1_1730701348937_1288")).sendKeys("C:\\fakepath\\NAUSS testing notes.txt");
//	    driver.findElement(By.id("yui_3_18_1_1_1730701348937_1332")).click();

			// IMS Content Activity
			// ------------------------------------------------------------------------------------>
//	    driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
//	    driver.findElement(By.linkText("IMS content package")).click();
//	    driver.get("https://qalms.nauss.edu.sa/course/modedit.php?add=imscp&type&course=1869&section=0&return=0&sr=0&beforemod=0");
//	    driver.findElement(By.id("id_name")).click();
//	    driver.findElement(By.id("id_name")).clear();
//	    driver.findElement(By.id("id_name")).sendKeys("IMS Content - Activity");
//	    //ERROR: Caught exception [ERROR: Unsupported command [selectFrame | index=0 | ]]
//	    driver.findElement(By.xpath("//body[@id='tinymce']/p")).click();
//	    //ERROR: Caught exception [unknown command [editContent]]
//	    //ERROR: Caught exception [ERROR: Unsupported command [selectFrame | relative=parent | ]]
//	    driver.findElement(By.xpath("//form[@id='mform1_WJVhTHLR0S9oP23']/div[5]")).click();
//	    driver.findElement(By.id("id_submitbutton")).click();
//	    driver.get("https://qalms.nauss.edu.sa/course/modedit.php");
//	    driver.findElement(By.xpath("//div[@id='file_info_67286ba13cb96']/div/div/div/div/i")).click();
//	    driver.findElement(By.id("filepicker-button-67286ba13cb96")).click();
//	    driver.findElement(By.id("yui_3_18_1_1_1730702234133_1048")).click();
//	    driver.findElement(By.id("yui_3_18_1_1_1730702234133_1048")).clear();
//	    driver.findElement(By.id("yui_3_18_1_1_1730702234133_1048")).sendKeys("C:\\fakepath\\Course Details  NAUSS.pdf");
//	    driver.findElement(By.id("yui_3_18_1_1_1730702234133_1089")).click();
//	    driver.findElement(By.id("id_submitbutton")).click();

			// Intractive Content Activity
			// ------------------------------------------------------------------------------------>
//		driver.findElement(By.id("yui_3_18_1_1_1730702553116_544")).click();
//		driver.findElement(By.xpath("//div[@id='all-7']/div/div[19]/div/a/div[2]")).click();
//		driver.get(
//				"https://qalms.nauss.edu.sa/course/modedit.php?add=hvp&type&course=1869&section=0&return=0&sr=0&beforemod=0");
//		// ERROR: Caught exception [ERROR: Unsupported command [selectFrame | index=1 |
//		// ]]
//		driver.findElement(By.xpath("//body[@id='tinymce']/p")).click();
//		// ERROR: Caught exception [ERROR: Unsupported command [selectFrame |
//		// relative=parent | ]]
//		driver.findElement(By.xpath("//h3[@id='']")).click();
//		// ERROR: Caught exception [ERROR: Unsupported command [selectFrame | index=1 |
//		// ]]
//		driver.findElement(By.xpath("//html")).click();
//		driver.findElement(By.id("yui_3_18_1_1_1730703244362_707")).click();
//		driver.findElement(By.xpath("//form[@id='mform1_iOsHHs95gLb1spt']/div")).click();
//		// ERROR: Caught exception [unknown command [editContent]]
//		driver.findElement(By.xpath("//body[@id='tinymce']/p")).click();
//		// ERROR: Caught exception [unknown command [editContent]]
//		// ERROR: Caught exception [ERROR: Unsupported command [selectFrame |
//		// relative=parent | ]]
//		driver.findElement(By.id("id_submitbutton")).click();
//		driver.findElement(By.id("id_submitbutton")).click();
//		driver.findElement(By.id("id_submitbutton")).click();
//		// ERROR: Caught exception [ERROR: Unsupported command [selectFrame | index=1 |
//		// ]]
//		driver.findElement(By.xpath("//html")).click();
//		// ERROR: Caught exception [unknown command [editContent]]
//		driver.findElement(By.xpath("//body[@id='tinymce']/p")).click();
//		// ERROR: Caught exception [unknown command [editContent]]
//		// ERROR: Caught exception [ERROR: Unsupported command [selectFrame |
//		// relative=parent | ]]
//		driver.findElement(By.id("id_submitbutton")).click();

			// IOMAD Certificate - Activity
			// ------------------------------------------------------------------------------------>
//		driver.findElement(By.linkText("IOMAD Certificate")).click();
//	    driver.get("https://qalms.nauss.edu.sa/course/modedit.php?add=iomadcertificate&type&course=1869&section=0&return=0&sr=0&beforemod=0");
//	    driver.findElement(By.id("id_name")).click();
//	    driver.findElement(By.id("id_name")).clear();
//	    driver.findElement(By.id("id_name")).sendKeys("IOMAD Certificate - Activity");
//	    //ERROR: Caught exception [ERROR: Unsupported command [selectFrame | index=0 | ]]
//	    driver.findElement(By.xpath("//html")).click();
//	    driver.findElement(By.xpath("//html")).click();
//	    driver.findElement(By.xpath("//html")).click();
//	    //ERROR: Caught exception [unknown command [editContent]]
//	    //ERROR: Caught exception [ERROR: Unsupported command [selectFrame | relative=parent | ]]
//	    driver.findElement(By.id("id_submitbutton")).click();
//	    driver.get("https://qalms.nauss.edu.sa/mod/iomadcertificate/view.php?id=6216&forceview=1");
//	    driver.findElement(By.xpath("//div[@id='region-main']/div/div[3]/table/tbody/tr/td")).click();
//	    driver.findElement(By.id("yui_3_18_1_1_1730704610451_538")).click();

			// Lesson - Activity - Done
			// ------------------------------------------------------------------------------------>
			try {
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						10);
				element.click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				WebElement Lesson = waitForElementToBeVisible(By.xpath(
						"(//a[@href='https://qalms.nauss.edu.sa/course/mod.php?id=1869&add=lesson&section=0&sr=0&beforemod=0'])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", Lesson);
				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=lesson&type&course=1869&section=0&return=0&sr=0&beforemod=0");
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(24, 1));

				driver.switchTo().frame(0);
				message = driver.findElement(By.id("tinymce"));
				message.sendKeys(getColumnRow(24, 2));
				driver.switchTo().defaultContent();

				driver.findElement(By.id("id_submitbutton")).click();
				driver.get(
						"https://qalms.nauss.edu.sa/course/modregrade.php?id=6219&url=%2Fmod%2Flesson%2Fview.php%3Fid%3D6219%26forceview%3D1");
				driver.findElement(By.xpath("//button[text()='Edit lesson']")).click();
				driver.get("https://qalms.nauss.edu.sa/mod/lesson/edit.php?id=6219");
				driver.findElement(By.xpath("(//select[@class='custom-select singleselect'])[1]")).click();
				driver.findElement(By.xpath("(//option[text()='Add a cluster'])[1]")).click();
				driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869");
				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("Lesson - Activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// Pages - Activity - Done
			// ------------------------------------------------------------------------------------>
			try {
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						10);
				element.click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				WebElement Page = waitForElementToBeVisible(By.xpath(
						"(//a[@href='https://qalms.nauss.edu.sa/course/mod.php?id=1869&add=page&section=0&sr=0&beforemod=0'])[1]"),
						30);

				((JavascriptExecutor) driver).executeScript("arguments[0].click();", Page);
				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=page&type&course=1869&section=0&return=0&sr=0&beforemod=0");
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(25, 1));

				driver.switchTo().frame(1);
				message = driver.findElement(By.id("tinymce"));
				message.sendKeys(getColumnRow(25, 2));
				driver.switchTo().defaultContent();

				driver.findElement(By.id("id_submitbutton")).click();
				driver.get("https://qalms.nauss.edu.sa/mod/page/view.php?id=6223&forceview=1");
				driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("Pages - Activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// Questionnaire - Activity - Done
			// ------------------------------------------------------------------------------------>
			try {
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						10);
				element.click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				WebElement Questionnaire = waitForElementToBeVisible(By.xpath(
						"(//a[@href='https://qalms.nauss.edu.sa/course/mod.php?id=1869&add=questionnaire&section=0&sr=0&beforemod=0'])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", Questionnaire);
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(26, 1));

//			driver.switchTo().frame(2);
//			WebElement message = driver.findElement(By.id("tinymce"));
//			message.sendKeys(getColumnRow(10, 1));
//			driver.switchTo().defaultContent();

				driver.findElement(By.id("id_submitbutton")).click();
//			driver.get("https://qalms.nauss.edu.sa/mod/questionnaire/view.php?id=6230&forceview=1");
//			driver.findElement(By.linkText("Add questions")).click();
//			driver.get("https://qalms.nauss.edu.sa/mod/questionnaire/questions.php?id=6230");
//			driver.findElement(By.id("id_type_id")).click();
//			driver.findElement(By.id("id_addqbutton")).click();
//			driver.get("https://qalms.nauss.edu.sa/mod/questionnaire/questions.php");
//			driver.findElement(By.id("id_name")).click();
//			driver.findElement(By.id("id_name")).clear();
//			driver.findElement(By.id("id_name")).sendKeys("ques 1");
				//
//			driver.findElement(By.xpath("//body[@id='tinymce']/p")).click();
//			driver.findElement(By.id("id_allchoices")).click();
//			driver.findElement(By.id("id_allchoices")).clear();
//			driver.findElement(By.id("id_allchoices")).sendKeys("7");
//			driver.findElement(By.id("id_submitbutton")).click();
				driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("Questionnaire - Activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// Quiz - Activity - Done
			// ------------------------------------------------------------------------------------>
			try {
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						10);
				element.click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				WebElement Quiz = waitForElementToBeVisible(By.xpath(
						"(//div[contains(@id, 'all')]/div/div[@aria-label='Quiz']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Quiz'])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", Quiz);
				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=quiz&type&course=1869&section=0&return=0&sr=0&beforemod=0");
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(27, 1));

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				driver.switchTo().frame(1);
				message = driver.findElement(By.id("tinymce"));
				message.sendKeys(getColumnRow(10, 1));
				driver.switchTo().defaultContent();

				driver.findElement(By.id("id_submitbutton")).click();

				driver.findElement(By.xpath("//button[text()='Continue']")).click();

				waitForElementToBeVisible(By.xpath("//button[text()='Back to the course']"), 30);
				driver.findElement(By.xpath("//button[text()='Back to the course']")).click();
				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("Quiz - Activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// Scheduler - Activity - Done
			// ------------------------------------------------------------------------------------>
			try {
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						10);
				element.click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				WebElement Scheduler = waitForElementToBeVisible(By.xpath(
						"(//div[contains(@id, 'all')]/div/div[@aria-label='Scheduler']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Scheduler'])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", Scheduler);
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(28, 1));
				driver.findElement(By.id("id_submitbutton")).click();
				driver.get("https://qalms.nauss.edu.sa/mod/scheduler/view.php?id=6234&forceview=1");
				driver.findElement(By.id("action-menu-toggle-4")).click();
				driver.findElement(By.xpath("//div[@id='action-menu-4-menu']/div[2]")).click();
				driver.findElement(By.xpath("//div[@id='dashboard-page']/div[3]/div[2]/nav/ol/li[3]")).click();
				driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("Scheduler - Activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// Survey - Activity - Done
			// ------------------------------------------------------------------------------------>
			try {
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						10);
				element.click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				WebElement Survey = waitForElementToBeVisible(By.xpath(
						"(//div[contains(@id, 'all')]/div/div[@aria-label='Survey']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Survey'])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", Survey);
				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=survey&type&course=1869&section=0&return=0&sr=0&beforemod=0");
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(29, 1));
				driver.findElement(By.id("id_template")).click();
				new Select(driver.findElement(By.id("id_template"))).selectByVisibleText("Critical incidents");

				driver.findElement(By.id("id_submitbutton")).click();
				driver.get("https://qalms.nauss.edu.sa/mod/survey/view.php?id=6240&forceview=1");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
//			    driver.findElement(By.id("q69")).clear();
//			    driver.findElement(By.id("q69")).sendKeys("Maths class");
//			    driver.findElement(By.id("q70")).clear();
//			    driver.findElement(By.id("q70")).sendKeys("Middle");
//			    driver.findElement(By.id("q71")).clear();
//			    driver.findElement(By.id("q71")).sendKeys("Chat with class mates and teachers");
//			    driver.findElement(By.id("q71")).clear();
//			    driver.findElement(By.id("q71")).sendKeys("Helpfully Chat with classmates and teachers");
//			    driver.findElement(By.id("q72")).click();
//			    driver.findElement(By.id("q72")).clear();
//			    driver.findElement(By.id("q72")).sendKeys("Nill");
//			    driver.findElement(By.id("q73")).click();
//			    driver.findElement(By.id("q73")).clear();
//			    driver.findElement(By.id("q73")).sendKeys("Nill");
//			    driver.findElement(By.id("q71")).click();
//			    driver.findElement(By.id("q71")).clear();
//			    driver.findElement(By.id("q71")).sendKeys("Nill");
//			    driver.findElement(By.id("q70")).clear();
//			    driver.findElement(By.id("q70")).sendKeys("Nill");
//			    driver.findElement(By.id("q69")).clear();
//			    driver.findElement(By.id("q69")).sendKeys("Nill");
//			    driver.findElement(By.xpath("//input[@value='Submit']")).click();
//			    driver.findElement(By.xpath("//button[text()='Continue']")).click();

				driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();

				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("Survey - Activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// Text and Media - Done
			// ------------------------------------------------------------------------------------>
			try {
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						10);
				element.click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				WebElement TextMediaArea = waitForElementToBeVisible(By.xpath(
						"(//div[contains(@id, 'all')]/div/div[@aria-label='Text and media area']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Text and media area'])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", TextMediaArea);
				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=label&type&course=1869&section=0&return=0&sr=0&beforemod=0");

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
//			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(0));
				WebElement frameElement = driver.findElement(By.xpath("//iframe[@title='Rich text area']"));
				driver.switchTo().frame(frameElement);
				message = driver.findElement(By.id("tinymce"));
				message.sendKeys(getColumnRow(30, 1));
				driver.switchTo().defaultContent();

				waitForElementToBeVisible(By.id("id_submitbutton2"), 30);
				driver.findElement(By.id("id_submitbutton2")).click();

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("Text and Media activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// Training - Activity
			// ------------------------------------------------------------------------------------>
//			try {
//				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
//				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
//						10);
//				element.click();
//				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
//				try {
//					Thread.sleep(2000);
//				} catch (InterruptedException e1) {
//					e1.printStackTrace();
//				}
//				WebElement TrainingEvent = waitForElementToBeVisible(By.xpath(
//						"(//div[contains(@id, 'all')]/div/div[@aria-label='Training event']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Training event'])[1]"),
//						30);
//				((JavascriptExecutor) driver).executeScript("arguments[0].click();", TrainingEvent);
//				driver.get(
//						"https://qalms.nauss.edu.sa/course/modedit.php?add=trainingevent&type&course=1869&section=0&return=0&sr=0&beforemod=0");
//				driver.findElement(By.id("id_name")).click();
//				driver.findElement(By.id("id_name")).clear();
//				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(31, 1));
//
//				try {
//					Thread.sleep(2000);
//				} catch (InterruptedException e1) {
//					e1.printStackTrace();
//				}
//				driver.switchTo().frame(0);
//				message = driver.findElement(By.id("tinymce"));
//				message.sendKeys(getColumnRow(31, 2));
//				driver.switchTo().defaultContent();
//
//				driver.findElement(By.id("id_classroomid")).click();
//				driver.findElement(By.id("id_submitbutton2")).click();
//				driver.findElement(By.id("id_classroomid")).click();
//				driver.findElement(By.id("id_classroomid")).click();
//				driver.findElement(By.id("id_enddatetime_month")).click();
//				driver.findElement(By.id("id_startdatetime_month")).click();
//				new Select(driver.findElement(By.id("id_startdatetime_month")))
//						.selectByVisibleText(getColumnRow(31, 3));
//				driver.findElement(By.id("id_classroomid")).click();
//				driver.findElement(By.id("id_classroomid")).click();
//				driver.findElement(By.id("id_submitbutton2")).click();
//
//				try {
//					driver.findElement(By.id("coursestructure-tab")).click();
//				} catch (StaleElementReferenceException e1) {
//					driver.findElement(By.id("coursestructure-tab")).click();
//				}
//
//				try {
//					Thread.sleep(2000);
//				} catch (InterruptedException e1) {
//					e1.printStackTrace();
//				}
//
//				try {
//					// Wait until the element is present in the DOM and visible
//					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
//					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
//				} catch (StaleElementReferenceException e1) {
//					System.out.println(" ");
//				}
//				System.out.println("Training - Activity Successfully Completed");
//			} catch (TimeoutException e1) {
//				// TODO: handle exception
//			}

			// Wiki - Activity - Done
			// ------------------------------------------------------------------------------------>
			try {
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						10);
				element.click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				WebElement Wiki = waitForElementToBeVisible(By.xpath(
						"(//div[contains(@id, 'all')]/div/div[@aria-label='Wiki']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Wiki'])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", Wiki);
				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=wiki&type&course=1869&section=0&return=0&sr=0&beforemod=0");
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(32, 1));
				// ERROR: Caught exception [ERROR: Unsupported command [selectFrame | index=0 |
				// ]]
				driver.findElement(By.xpath("//html")).click();
				// ERROR: Caught exception [unknown command [editContent]]
				// ERROR: Caught exception [ERROR: Unsupported command [selectFrame |
				// relative=parent | ]]
				driver.findElement(By.id("id_introeditor_label")).click();

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				driver.switchTo().frame(0);
				message = driver.findElement(By.id("tinymce"));
				message.sendKeys(getColumnRow(32, 2));
				driver.switchTo().defaultContent();

				driver.findElement(By.id("id_firstpagetitle")).click();
				driver.findElement(By.id("id_firstpagetitle")).click();
				driver.findElement(By.id("id_firstpagetitle")).clear();
				driver.findElement(By.id("id_firstpagetitle")).sendKeys(getColumnRow(32, 3));
				driver.findElement(By.id("id_submitbutton")).click();
				driver.get(
						"https://qalms.nauss.edu.sa/mod/wiki/create.php?wid=22&group&uid=0&title=Introduction%20Page");
				driver.findElement(By.id("id_submitbutton")).click();
				driver.get("https://qalms.nauss.edu.sa/mod/wiki/edit.php?pageid=14");
				driver.findElement(By.id("save")).click();
				driver.get("https://qalms.nauss.edu.sa/mod/wiki/view.php?pageid=14&group=0");
				driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e1) {
					System.out.println(" ");
				}
				System.out.println("Wiki - Activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// Workshop - Activity
			// -------------------------------------------------------------------------------------->
			try {
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				element = waitForElementToBeClickable(By.xpath("//div[@id='coursecontentcollapse0']/button/span[2]"),
						10);
				element.click();
				driver.get("https://qalms.nauss.edu.sa/course/view.php?id=1869#coursestructure");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				WebElement Workshop = waitForElementToBeVisible(By.xpath(
						"(//div[contains(@id, 'all')]/div/div[@aria-label='Workshop']/div[@class='optioninfo card-body d-flex flex-column text-center p-1']//a[@title='Add a new Workshop'])[1]"),
						30);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", Workshop);
				driver.get(
						"https://qalms.nauss.edu.sa/course/modedit.php?add=workshop&type&course=1869&section=0&return=0&sr=0&beforemod=0");
				driver.findElement(By.id("id_name")).click();
				driver.findElement(By.id("id_name")).clear();
				driver.findElement(By.id("id_name")).sendKeys(getColumnRow(33, 1));

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				driver.switchTo().frame(0);
				message = driver.findElement(By.id("tinymce"));
				message.sendKeys(getColumnRow(33, 2));
				driver.switchTo().defaultContent();

				driver.findElement(By.id("id_submitbutton")).click();
				waitForElementToBeVisible(By.xpath("//button[text()='Continue']"), 30);
				driver.findElement(By.xpath("//button[text()='Continue']")).click();
//			    driver.findElement(By.xpath("//div[@id='region-main']/div/div/dl[2]/dd")).click();
//			    driver.findElement(By.xpath("//a[@id='action_link67289b2a6a99f20']/i")).click();
//			    driver.findElement(By.id("single_button67289b397fa9621")).click();
//			    driver.findElement(By.id("single_select67289b41991de33")).click();
//			    driver.findElement(By.xpath("//div[@id='workshop-viewlet-allsubmissions_inner']/nav[2]")).click();
				waitForElementToBeVisible(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]"), 30);
				driver.findElement(By.linkText("التحقيق في الجرائم الاقتصادية - طلاب [قصد532]")).click();
				try {
					driver.findElement(By.id("coursestructure-tab")).click();
				} catch (StaleElementReferenceException e1) {
					driver.findElement(By.id("coursestructure-tab")).click();
				}

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}

				try {
					// Wait until the element is present in the DOM and visible
					waitForElementToBeVisible(By.xpath("//div[@id='coursecontentcollapse0']/button"), 30);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", addActivity_btn);
				} catch (StaleElementReferenceException e11) {
					System.out.println(" ");
				}
				System.out.println("Workshop - Activity Successfully Completed");
			} catch (TimeoutException e1) {
				// TODO: handle exception
			}

			// driver.close();
		}
	}
}