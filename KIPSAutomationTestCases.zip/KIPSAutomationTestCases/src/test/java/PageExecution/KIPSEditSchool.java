package PageExecution;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;

import BaseClassPackage.BaseClass;
import BaseClassPackage.StepDefinationClass;

import static org.junit.Assert.assertTrue;
import dev.failsafe.internal.util.Assert;
import io.github.bonigarcia.wdm.WebDriverManager;

public class KIPSEditSchool extends StepDefinationClass {

	public KIPSEditSchool(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

//	public AddActivities(WebDriver driver) {
//		super(driver);
//		// TODO Auto-generated constructor stub
//	}

//	static WebDriver driver;

	private static final String APPLICATION_NAME = "Google Sheets API";
	private static final JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();
	private static final String TOKENS_DIRECTORY_PATH = "tokens/path";

	private static final String existingSpreadSheetID = "13gfYl2OOdykh-oXCHtrygUDYETRCI2NXa7XPKT6hQoA";
	private static final List<String> SCOPES = Arrays.asList(SheetsScopes.SPREADSHEETS, SheetsScopes.DRIVE);
	private static final String CREDENTIALS_FILE_PATH = "/credentials.json";

	static Sheets.Spreadsheets spreadsheets;

	private static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
		InputStream in = SheetWriteExample.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
		if (in == null) {
			throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
		}
		GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

		GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(HTTP_TRANSPORT, JSON_FACTORY,
				clientSecrets, SCOPES)
				.setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
				.setAccessType("offline").build();

		LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
		return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
	}

	public static String path = System.getProperty("user.dir");

	public static void ScreenShot(WebDriver driver, String name) {
		// Specify the folder path where you want to save the extent report
		String folderPath = path + "/Screenshot/";

		// Create folder if it doesn't exist
		File folder = new File(folderPath);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		try {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File src = ts.getScreenshotAs(OutputType.FILE);
			File des = new File(folderPath + name + ".png");
			FileHandler.copy(src, des);
			// System.out.println("Screenshot saved at: " + des.getAbsolutePath());
		} catch (IOException e) {
			// e.printStackTrace();
			System.err.println("Error occurred while taking a screenshot: " + e.getMessage());
		}
	}

	public static WebElement waitForElementToBeClickable(WebElement locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.elementToBeClickable(locator));
	}

	public static WebElement waitForElementToBeVisible(WebElement locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.visibilityOfElementLocated((By) locator));
	}

	public WebDriverWait wait;
	private static WebElement webElement;

	public WebElement waitForElementToBePresent(By locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}

	public boolean waitForTextToBePresentInElement(By locator, String text, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
	}

	public boolean waitForElementToBeInvisible(By locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
	}

	public void verifyTextVisible(String expectedText, By locator) {
		// Wait until the element with the text is visible
		WebElement element = waitForElementToBeVisible(locator, 10);

		// Check if the element contains the expected text
		assertTrue("Text not visible or incorrect!", element.getText().contains(expectedText));

	}

	public static boolean isRadioButtonChecked(By locator) {
		try {
			WebElement radioButton = driver.findElement(locator);
			return radioButton.isSelected();
		} catch (NoSuchElementException e) {
			System.out.println("Radio button not found: " + e.getMessage());
			return false;
		}
	}

	public static void dragAndDrop(By sourceLocator, By targetLocator) {
		try {
			// Find source and target elements
			WebElement sourceElement = driver.findElement(sourceLocator);
			WebElement targetElement = driver.findElement(targetLocator);

			// Create Actions object
			Actions actions = new Actions(driver);

			// Perform drag and drop
			actions.dragAndDrop(sourceElement, targetElement).build().perform();
		} catch (Exception e) {
			System.out.println("Drag and drop failed: " + e.getMessage());
		}
	}

	public static void safeClickWithRetry(WebDriver driver, By locator) {
		int retries = 3; // Number of attempts
		for (int i = 0; i < retries; i++) {
			try {
				WebElement element = driver.findElement(locator);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
				break; // Break loop if click is successful
			} catch (StaleElementReferenceException e) {
				System.out.println("StaleElementReferenceException encountered. Retrying...");
			}
		}
	}
	
	public static void treadWait(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	 public static void gettext(String word) {
	        String text = word;
	        Pattern pattern = Pattern.compile("Question ID (\\d+)");
	        Matcher matcher = pattern.matcher(text);

	        if (matcher.find()) {
	            String questionId = matcher.group(1);
	            System.out.println("Extracted Question ID: " + questionId);
	        } else {
	            System.out.println("No ID found.");
	        }						
	    }


	public static void main(String[] args) throws IOException, TimeoutException, GeneralSecurityException {
		
		login();
		GotoEditSchool();
		
//		createQueation();
		
	}
}