package PageExecution;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;

import BaseClassPackage.BaseClass;

import static org.junit.Assert.assertTrue;
import dev.failsafe.internal.util.Assert;
import io.github.bonigarcia.wdm.WebDriverManager;

public class EditQuestion extends BaseClass {

	public EditQuestion(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

//	public AddActivities(WebDriver driver) {
//		super(driver);
//		// TODO Auto-generated constructor stub
//	}

//	static WebDriver driver;

	public static final String APPLICATION_NAME = "Google Sheets API";
	public static final JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();
	public static final String TOKENS_DIRECTORY_PATH = "tokens/path";

	public static final String existingSpreadSheetID = "13gfYl2OOdykh-oXCHtrygUDYETRCI2NXa7XPKT6hQoA";
	public static final List<String> SCOPES = Arrays.asList(SheetsScopes.SPREADSHEETS, SheetsScopes.DRIVE);
	public static final String CREDENTIALS_FILE_PATH = "/credentials.json";

	static Sheets.Spreadsheets spreadsheets;

	public static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
		InputStream in = SheetWriteExample.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
		if (in == null) {
			throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
		}
		GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

		GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(HTTP_TRANSPORT, JSON_FACTORY,
				clientSecrets, SCOPES)
				.setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
				.setAccessType("offline").build();

		LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
		return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
	}

	public static String path = System.getProperty("user.dir");

	public static void ScreenShot(WebDriver driver, String name) {
		// Specify the folder path where you want to save the extent report
		String folderPath = path + "/Screenshot/";

		// Create folder if it doesn't exist
		File folder = new File(folderPath);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		try {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File src = ts.getScreenshotAs(OutputType.FILE);
			File des = new File(folderPath + name + ".png");
			FileHandler.copy(src, des);
			// System.out.println("Screenshot saved at: " + des.getAbsolutePath());
		} catch (IOException e) {
			// e.printStackTrace();
			System.err.println("Error occurred while taking a screenshot: " + e.getMessage());
		}
	}

	public static WebElement waitForElementToBeClickable(WebElement locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.elementToBeClickable(locator));
	}

	public static WebElement waitForElementToBeVisible(WebElement locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.visibilityOfElementLocated((By) locator));
	}

	public WebDriverWait wait;
	private static WebElement webElement;

	public WebElement waitForElementToBePresent(By locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}

	public boolean waitForTextToBePresentInElement(By locator, String text, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
	}

	public boolean waitForElementToBeInvisible(By locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
	}

	public void verifyTextVisible(String expectedText, By locator) {
		// Wait until the element with the text is visible
		WebElement element = waitForElementToBeVisible(locator, 10);

		// Check if the element contains the expected text
		assertTrue("Text not visible or incorrect!", element.getText().contains(expectedText));

	}

	public static boolean isRadioButtonChecked(By locator) {
		try {
			WebElement radioButton = driver.findElement(locator);
			return radioButton.isSelected();
		} catch (NoSuchElementException e) {
			System.out.println("Radio button not found: " + e.getMessage());
			return false;
		}
	}

	public static void dragAndDrop(By sourceLocator, By targetLocator) {
		try {
			// Find source and target elements
			WebElement sourceElement = driver.findElement(sourceLocator);
			WebElement targetElement = driver.findElement(targetLocator);

			// Create Actions object
			Actions actions = new Actions(driver);

			// Perform drag and drop
			actions.dragAndDrop(sourceElement, targetElement).build().perform();
		} catch (Exception e) {
			System.out.println("Drag and drop failed: " + e.getMessage());
		}
	}

	public static void safeClickWithRetry(WebDriver driver, By locator) {
		int retries = 3; // Number of attempts
		for (int i = 0; i < retries; i++) {
			try {
				WebElement element = driver.findElement(locator);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
				break; // Break loop if click is successful
			} catch (StaleElementReferenceException e) {
				System.out.println("StaleElementReferenceException encountered. Retrying...");
			}
		}
	}

	public static void treadWait(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void gettext(String word) {
		String text = word;
		Pattern pattern = Pattern.compile("Question ID (\\d+)");
		Matcher matcher = pattern.matcher(text);

		if (matcher.find()) {
			String questionId = matcher.group(1);
			System.out.println("Extracted Question ID: " + questionId);
		} else {
			System.out.println("No ID found.");
		}
	}

	public static void main(String[] args) throws IOException, TimeoutException, GeneralSecurityException {

//		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Google\\Chrome\\Application\\chromedriver.exe");

		WebElement element;
		WebElement courseLink;
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		EditQuestion assertions = new EditQuestion(driver);
//		WebElement message;
		driver = new ChromeDriver();
		WebDriverManager.chromedriver().setup();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get(SheetsQuickstart.getColumnRow(1, 1));
		System.out.println("Chrome Browser is Launched");
		treadWait(2000);
		Actions act = new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		driver.findElement(By.xpath("//input[@id=\"email\"]")).sendKeys(SheetsQuickstart.getColumnRow(2, 1));
		driver.findElement(By.xpath("//input[@id=\"password\"]")).sendKeys(SheetsQuickstart.getColumnRow(3, 1));
		driver.findElement(By.xpath("//div[3]/button")).click();

		driver.findElement(By.xpath("//select[@name='question']")).click();
		driver.findElement(
				By.xpath("//*[@id=\"questionbankid\"]/option[text()='" + SheetsQuickstart.getColumnRow(16, 1) + "']"))
				.click();
		driver.findElement(By.xpath("//div[text()='228129']//following::div[@id=\"edit\"][1]")).click();
		driver.findElement(By.xpath("//div[text()='228129']//following::div[@id=\"edit\"][1]//span[@id=\"edit\"]"))
				.click();

		System.out.println("Navigate to the Select question bank page");

//		treadWait(4000);
//		WebElement Qbank = driver.findElement(By.xpath("//div[1]/p[text()='"+SheetsQuickstart.getColumnRow(16, 1)+"']"));
//		
//		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Qbank);
//		webElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[1]/p[text()='"+SheetsQuickstart.getColumnRow(16, 1)+"']")));
//		treadWait(4000);
//		Qbank.click();
//		driver.findElement(By.xpath("//div/button[text()='Save & Continue']")).click();

		System.out.println("Navigate to the Basic Information page");

		System.out.println(SheetsQuickstart.getColumnRow(17, 3));

		String LOD = SheetsQuickstart.getColumnRow(17, 3);
		if (LOD.equals("yes")) {
			driver.findElement(By.xpath("//label[text()='" + SheetsQuickstart.getColumnRow(17, 2) + "']")).click();
			System.out.println("LOD is changeed");
		} else {
			System.out.println("LOD Not changeed");
		}

		String category = SheetsQuickstart.getColumnRow(18, 3);
		if (category.equals("yes")) {
			driver.findElement(
					By.xpath("//*[@id=\"category\"]/option[text()='" + SheetsQuickstart.getColumnRow(18, 2) + "']"))
					.click();
			System.out.println("category is changeed");
		} else {
			System.out.println("category Not changeed");
		}

		treadWait(2000);
		driver.findElement(By.xpath("//*[@id=\"academic_year\"]")).click();
		String academic_year = SheetsQuickstart.getColumnRow(19, 3);
		if (academic_year.equals("yes")) {
			driver.findElement(By
					.xpath("//*[@id=\"academic_year\"]/option[text()='" + SheetsQuickstart.getColumnRow(19, 2) + "']"))
					.click();
			System.out.println("academic_year is changeed");
		} else {
			System.out.println("academic_year Not changeed");
		}

		String Primary_Tags = SheetsQuickstart.getColumnRow(12, 3);
		if (Primary_Tags.equals("yes")) {
			driver.findElement(By.xpath("//div[text()='Primary Tags ']//following::input[@id='searchInput'][1]"))
					.sendKeys(SheetsQuickstart.getColumnRow(12, 2));
			System.out.println("Primary Tags is changeed");
			treadWait(4000);
			driver.findElement(By.xpath("//button[1]/span")).click();
		} else {
			System.out.println("Primary Tags Not changeed");
		}

		treadWait(4000);
		String Free_Tags = SheetsQuickstart.getColumnRow(13, 3);
		if (Free_Tags.equals("yes")) {
			driver.findElement(By.xpath("//div[text()='Free Tags']//following::input[@id='searchInput'][1]"))
					.sendKeys(SheetsQuickstart.getColumnRow(13, 2));
			driver.findElement(By.xpath("//button[1]/span[text()='" + SheetsQuickstart.getColumnRow(20, 2) + "']"))
					.click();
			System.out.println("Free Tags is changeed");
		} else {
			System.out.println("Free Tags Not changeed");
		}

		treadWait(4000);
		String Secondary_Tags = SheetsQuickstart.getColumnRow(12, 3);
		if (Secondary_Tags.equals("yes")) {
			driver.findElement(By.xpath("//div[text()='Secondary Tags ']//following::input[@id='searchInput'][1]"))
					.sendKeys(SheetsQuickstart.getColumnRow(12, 2));
			treadWait(4000);
			WebElement secondaryTag = driver.findElement(By.xpath("//button[1]/span"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", secondaryTag);
			treadWait(6000);
//			((BaseClass) driver).waitForElementToBePresent(secondaryTag, 10);
			secondaryTag.click();
			System.out.println("Secondary Tags is changeed");
		} else {
			System.out.println("Secondary Tags Not changeed");
		}

		WebElement saveBtn = driver.findElement(By.xpath("//button[text()='Save & Continue']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", saveBtn);
		saveBtn.click();

		System.out.println("Navigate to the Question Creation page");

		treadWait(4000);

		String Question_category_Tags = SheetsQuickstart.getColumnRow(21, 3);
		if (Question_category_Tags.equals("yes")) {
			driver.findElement(By.xpath("//button[text()='" + SheetsQuickstart.getColumnRow(21, 2) + "']")).click();
			System.out.println("Question category is changeed");
		} else {
			System.out.println("Question category Not changeed");
		}
		String Question_Type = SheetsQuickstart.getColumnRow(22, 3);
		if (Question_Type.equals("yes")) {
			driver.findElement(
					By.xpath("//button//preceding::p[text()='" + SheetsQuickstart.getColumnRow(22, 2) + "']")).click();
			System.out.println("Question type is changeed");
		} else {
			System.out.println("Question type Not changeed");
		}
		treadWait(4000);

		WebElement saveBtn1 = driver.findElement(By.xpath("//button[text()='Save & Continue']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", saveBtn1);
		saveBtn1.click();

		String Question_Short_Identifier = SheetsQuickstart.getColumnRow(14, 3);
		if (Question_Short_Identifier.equals("yes")) {
			driver.findElement(By.xpath("//textarea[@placeholder='Enter Question Short Identifier']")).clear();
			driver.findElement(By.xpath("//textarea[@placeholder='Enter Question Short Identifier']"))
					.sendKeys(SheetsQuickstart.getColumnRow(14, 2));
			System.out.println("Question Short Identifier is changeed");
		} else {
			System.out.println("Question Short Identifier Not changeed");
		}
		treadWait(4000);
		String ComposeQuestion = SheetsQuickstart.getColumnRow(15, 3);
		if (ComposeQuestion.equals("yes")) {
			WebElement iframe = driver.findElement(
					By.xpath("(//div[contains(@class,'createQuestion_ComposeQuestion')]//following::iframe)[1]"));
			driver.switchTo().frame(iframe);
			WebElement ComQues = driver.findElement(By.xpath("(//*[@id='tinymce'])[1]"));
			treadWait(4000);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ComQues);
			treadWait(4000);
			ComQues.clear();
			ComQues.sendKeys(SheetsQuickstart.getColumnRow(15, 2));
			driver.switchTo().defaultContent();
			System.out.println("ComposeQuestion is changeed");
		} else {
			System.out.println("ComposeQuestion is Not changeed");
		}

		String answer_format = SheetsQuickstart.getColumnRow(23, 3);
		if (answer_format.equals("yes")) {
			WebElement ansFormat = driver.findElement(By.xpath("//*[@id=\"answer-format\"]"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ansFormat);
			treadWait(4000);
			ansFormat.click();
			driver.findElement(By
					.xpath("//*[@id=\"answer-format\"]/option[text()='" + SheetsQuickstart.getColumnRow(23, 2) + "']"))
					.click();
			System.out.println("answer-format is changeed");
		} else {
			System.out.println("answer-format is Not changeed");
		}

		driver.findElement(By.xpath("//button[text()='Publish']"));
		treadWait(4000);
		WebElement publishBtn = driver.findElement(By.xpath("//button[text()='Publish']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", publishBtn);
		publishBtn.click();

		System.out.println("Navigate to the Send For Review page");

		treadWait(4000);
		WebElement GoBackQlist = driver.findElement(By.xpath("//button[text()='Go Back to Question Listing']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", GoBackQlist);
		GoBackQlist.click();

//		gettext("Your Question ID 137945 has been published successfully.");
		String text = "Your Question ID 137945 has been published successfully.";
		Pattern pattern = Pattern.compile("Question ID (\\d+)");
		Matcher matcher = pattern.matcher(text);

		String questionId = null;
		if (matcher.find()) {
			questionId = matcher.group(1);
			System.out.println("Extracted Question ID: " + questionId);
		} else {
			System.out.println("No ID found.");
		}

		driver.findElement(By.xpath("//select[@name='question']")).click();
		driver.findElement(By.xpath("//*[@id=\"questionbankid\"]/option[text()='Deployment Testing']")).click();

	}
}