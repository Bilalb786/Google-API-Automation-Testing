package BaseClassPackage;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import PageExecution.KIPSEditSchool;
import PageExecution.SheetsQuickstart;
import io.github.bonigarcia.wdm.WebDriverManager;

public class StepDefinationClass extends BaseClass{

	public StepDefinationClass(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	public static void treadWait(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void login() throws IOException, GeneralSecurityException {
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		KIPSEditSchool assertions = new KIPSEditSchool(driver);
		
		driver = new ChromeDriver();	
		WebDriverManager.chromedriver().setup();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get(SheetsQuickstart.getColumnRow(1, 1));
		System.out.println("Chrome Browser is Launched");
		treadWait(2000);
		Actions act = new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		
		driver.findElement(By.xpath("//input[@id=\"username\"]")).sendKeys(SheetsQuickstart.getColumnRow(2, 1));
		driver.findElement(By.xpath("//input[@id=\"password\"]")).sendKeys(SheetsQuickstart.getColumnRow(3, 1));
		treadWait(2000);
		driver.findElement(By.xpath("//button[@id='loginbtn']")).click();
//		String title =  driver.getTitle();
//		System.out.println("Application title: "+title);
		System.out.println("Navigate to the Dashboard page");

	}

	public static void GotoEditSchool() throws IOException, GeneralSecurityException {
		
		treadWait(2000);
//		BaseClass.waitForElementToBeClickable("//button[@id='mainNav']", 10);
		WebElement sideMenu = driver.findElement(By.xpath("//a//span[text()='"+SheetsQuickstart.getColumnRow(5, 1)+"']"));
		//verify the if condition value
		if (!sideMenu.isDisplayed()) {
			driver.findElement(By.xpath("//button[@id='mainNav']")).click();
		}
//		BaseClass.waitForElementToBePresent(sideMenu, 10);
		sideMenu.click();
		treadWait(2000);
		driver.findElement(By.xpath("(//input[@placeholder='Search'])[1]")).sendKeys(SheetsQuickstart.getColumnRow(6, 1));
		driver.findElement(By.xpath("//li[text()='"+SheetsQuickstart.getColumnRow(7, 1)+"']")).click();
		treadWait(4000);
		driver.findElement(By.xpath("//div[text()='"+SheetsQuickstart.getColumnRow(8, 1)+"']")).click();
		
		System.out.println("Navigate to Edit school page");
		
		//Combine Values
		String line1 = SheetsQuickstart.getColumnRow(9, 1);
		String line2 = SheetsQuickstart.getColumnRow(10, 1);
		
		String fullAddress = line1 + line2;
		
		BaseClass.ClearAndType("//textarea[@id=\"id_address\"]", fullAddress);	
		
		treadWait(2000);
		WebElement bandingCollope  = driver.findElement(By.xpath("//a[@id=\"collapseElement-2\"]"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", bandingCollope);
		bandingCollope.click();
		
		driver.findElement(By.xpath("(//a[@title='Add...'])[1]")).click();
		treadWait(2000);
		driver.findElement(By.xpath("repo_upload_file")).click();
		
		System.out.println("done s");
		
		 String ImagePath = "\"D:\\C Drive\\Downloads\\flat-web-template-with-lms-for-concept-design-vector-44391722.jpg\"";  // path to your CSV
	        String line;


	        try (BufferedReader br = new BufferedReader(new FileReader(ImagePath))) {
	            while ((line = br.readLine()) != null) {
	                String[] data = line.split(",");

	                String imagePath = data[0];
	                String description = data[1];

	                // Upload image
	                driver.findElement(By.id("imageUpload")).sendKeys(imagePath);

	                // Enter description
	                driver.findElement(By.id("description")).clear();
	                driver.findElement(By.id("description")).sendKeys(description);

	                // Submit
	                driver.findElement(By.id("submitBtn")).click();
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		
		driver.findElement(By.xpath("//*[@name='submitbutton']")).click();
		
		String successNotification = driver.findElement(By.xpath("//*[@id=\"user-notifications\"]//div")).getText();
		System.out.println(successNotification);
//		if (driver.getPageSource().contains(successNotification)) {
//			
//		}

		
//		driver.findElement(By.xpath("//*[@id=\"category\"]/option[text()='"+SheetsQuickstart.getColumnRow(18, 1)+"']")).click();
//		treadWait(2000);
//		driver.findElement(By.xpath("//*[@id=\"academic_year\"]")).click();
//		driver.findElement(By.xpath("//*[@id=\"academic_year\"]/option[text()='"+SheetsQuickstart.getColumnRow(19, 1)+"']")).click();
//		driver.findElement(By.xpath("//div[text()='Primary Tags ']//following::input[@id='searchInput'][1]")).sendKeys(SheetsQuickstart.getColumnRow(12, 1));
//		treadWait(4000);
//		driver.findElement(By.xpath("//button[1]/span")).click();
//		
//		treadWait(4000);
//		driver.findElement(By.xpath("//div[text()='Free Tags']//following::input[@id='searchInput'][1]")).sendKeys(SheetsQuickstart.getColumnRow(13, 1));
//		treadWait(4000);
//		driver.findElement(By.xpath("//button[1]/span[text()='"+SheetsQuickstart.getColumnRow(20, 1)+"']")).click();
//		
//		treadWait(4000);
//		driver.findElement(By.xpath("//div[text()='Secondary Tags ']//following::input[@id='searchInput'][1]")).sendKeys(SheetsQuickstart.getColumnRow(12, 1));
//		treadWait(4000);
//		WebElement secondaryTag = driver.findElement(By.xpath("//button[1]/span"));
//		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", secondaryTag);
//		treadWait(6000);
////		((BaseClass) driver).waitForElementToBePresent(secondaryTag, 10);
//		secondaryTag.click();
//		
//		WebElement saveBtn = driver.findElement(By.xpath("//button[text()='Save & Continue']"));
//		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", saveBtn);
//		saveBtn.click();
//		
//		System.out.println("Navigate to the Question Creation page");
//		
//		treadWait(4000);
//		driver.findElement(By.xpath("//button[text()='"+SheetsQuickstart.getColumnRow(21, 1)+"']")).click();
//		driver.findElement(By.xpath("//button//preceding::p[text()='"+SheetsQuickstart.getColumnRow(22, 1)+"']")).click();
//		treadWait(4000);
//		
//		WebElement saveBtn1 = driver.findElement(By.xpath("//button[text()='Save & Continue']"));
//		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", saveBtn1);
//		saveBtn1.click();
//		
//		driver.findElement(By.xpath("//textarea[@placeholder='Enter Question Short Identifier']")).sendKeys(SheetsQuickstart.getColumnRow(14, 1));
//		treadWait(4000);
//		WebElement iframe = driver.findElement(By.xpath("(//div[contains(@class,'createQuestion_ComposeQuestion')]//following::iframe)[1]"));
//		driver.switchTo().frame(iframe); 
//		WebElement ComQues  = driver.findElement(By.xpath("(//*[@id='tinymce'])[1]"));
//		treadWait(4000);
//		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ComQues);
//		treadWait(4000);
//		ComQues.sendKeys(SheetsQuickstart.getColumnRow(15, 1));
//		driver.switchTo().defaultContent();
//		
//		WebElement ansFormat  = driver.findElement(By.xpath("//*[@id=\"answer-format\"]"));
//		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ansFormat);
//		treadWait(4000);
//		ansFormat.click();
//		driver.findElement(By.xpath("//*[@id=\"answer-format\"]/option[text()='"+SheetsQuickstart.getColumnRow(23, 1)+"']")).click();
//		
//		 driver.findElement(By.xpath("//button[text()='Publish']"));
//		treadWait(4000);
//		WebElement publishBtn  = driver.findElement(By.xpath("//button[text()='Publish']"));
//		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", publishBtn);
//		publishBtn.click();
//		
//		System.out.println("Navigate to the Send For Review page");
//		
//		treadWait(4000);
//		WebElement GoBackQlist  = driver.findElement(By.xpath("//button[text()='Go Back to Question Listing']"));
//		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", GoBackQlist);
//		GoBackQlist.click();
//		
////		gettext("Your Question ID 137945 has been published successfully.");
//		String text = "Your Question ID 137945 has been published successfully.";
//        Pattern pattern = Pattern.compile("Question ID (\\d+)");
//        Matcher matcher = pattern.matcher(text);
//
//        String questionId = null;
//        if (matcher.find()) {
//             questionId = matcher.group(1);
//            System.out.println("Extracted Question ID: " + questionId);
//        } else {
//            System.out.println("No ID found.");
//        }
//		
//        driver.findElement(By.xpath("//select[@name='question']")).click();
//		driver.findElement(By.xpath("//*[@id=\"questionbankid\"]/option[text()='Deployment Testing']")).click();
		

	}
	
	
	
}

