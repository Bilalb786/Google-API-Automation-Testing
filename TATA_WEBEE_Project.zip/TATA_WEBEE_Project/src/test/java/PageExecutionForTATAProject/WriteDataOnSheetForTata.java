package PageExecutionForTATAProject;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.sheets.v4.model.UpdateValuesResponse;
import com.google.api.services.sheets.v4.model.ValueRange;

import BaseClassPackage.BaseClass;

public class WriteDataOnSheetForTata extends BaseClass{

	public WriteDataOnSheetForTata(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	private static final String APPLICATION_NAME = "Google Sheets API";
	private static final JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();
	private static final String TOKENS_DIRECTORY_PATH = "tokens/path";

	private static final String existingSpreadSheetID ="1uOoWQcXNq3LAXJHDH2Aub1y4jYw1cptzQumZg7VSPwU";
	private static final List<String> SCOPES = Arrays.asList(SheetsScopes.SPREADSHEETS,SheetsScopes.DRIVE);
	private static final String CREDENTIALS_FILE_PATH = "service_account.json";

	static Sheets.Spreadsheets spreadsheets;

	private static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
		InputStream in = SheetWriteExample.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
		if (in == null) {
			throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
		}
		GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

		GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
				HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, SCOPES)
				.setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
				.setAccessType("offline")
				.build();

		LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
		return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
	}

	public static void values(String sheetName,String column, String val) throws IOException, GeneralSecurityException, InterruptedException {

//		final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
//		final String spreadsheetId = "13ZdojmhuOlcGuGvbE24wVLVe-gLc0bpOEjjTdLRaTiI";
//		final String range = "OUP!A:A"; // specify the cell to write to
//
//		Sheets service = new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
//				.setApplicationName(APPLICATION_NAME).build();
//		ValueRange response = service.spreadsheets().values().get(spreadsheetId, range).execute();

		getSpreadsheetInstance();

//		try {
//			String cellValue = SheetsQuickstart.getColumnRow(0, 1);
//			if (cellValue != null && !cellValue.isEmpty()) {
//				System.out.println("Cell value: " + cellValue);

				writeDataGoogleSheets(sheetName, column,new ArrayList<>(Arrays.asList(val)), existingSpreadSheetID);

			

//			} else {
//				System.out.println("No value found in the specified cell no: ");
//				writeDataGoogleSheets("OUP", new ArrayList<>(Arrays.asList("NA")), existingSpreadSheetID);
//			}
//		} catch (IOException | GeneralSecurityException e) {
//			System.out.println(e.getMessage());
//		}
	}

	public static void writeDataGoogleSheets(String sheetName,String columnValue, List<Object> data, String existingSpreadSheetID) throws IOException {
		String column = columnValue;
		int nextRow = getRows(sheetName, column, existingSpreadSheetID) + 1;
		String range = sheetName + "!" + column + nextRow;
		writeSheet(data, range, existingSpreadSheetID);
	}

	public static int getRows(String sheetName, String column, String existingSpreadSheetID) throws IOException {
		String range = sheetName + "!" + column + ":" + column;
		ValueRange valueRange = spreadsheets.values().get(existingSpreadSheetID, range).execute();
		List<List<Object>> values = valueRange.getValues();

		return (values != null && !values.isEmpty()) ? values.size() : 0;
	}


	public static void getSpreadsheetInstance() throws GeneralSecurityException, IOException {
		final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
		spreadsheets = new Sheets.Builder(GoogleNetHttpTransport.newTrustedTransport(), GsonFactory.getDefaultInstance(),
				getCredentials(HTTP_TRANSPORT)).setApplicationName("Google Sheet Java Integrat").build().spreadsheets();
	}

	public static void writeSheet(List<Object> inputData,String sheetAndRange ,String existingSpredSheetID) throws IOException {

		@SuppressWarnings("unchecked")
		List<List<Object>> values = Arrays.asList(inputData);
		ValueRange body = new ValueRange().setValues(values);
		UpdateValuesResponse result = spreadsheets.values().update(existingSpredSheetID,sheetAndRange,body)
				.setValueInputOption("USER_ENTERED").execute();
		System.out.printf("%d cells updated.\n",result.getUpdatedCells());
	}
}
