package PageExecutionForTATAProject;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.googleapis.json.GoogleJsonError;
import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.Sheets.Spreadsheets;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.sheets.v4.model.AddSheetRequest;
import com.google.api.services.sheets.v4.model.BatchUpdateSpreadsheetRequest;
import com.google.api.services.sheets.v4.model.Request;
import com.google.api.services.sheets.v4.model.Sheet;
import com.google.api.services.sheets.v4.model.SheetProperties;
import com.google.api.services.sheets.v4.model.Spreadsheet;
import com.google.api.services.sheets.v4.model.SpreadsheetProperties;
import com.google.api.services.sheets.v4.model.UpdateValuesResponse;
import com.google.api.services.sheets.v4.model.ValueRange;

import BaseClassPackage.BaseClass;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebDriver;

public class SheetWriteExample extends BaseClass {
	public SheetWriteExample(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	private static final String APPLICATION_NAME = "Google Sheets API";
	private static final JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();
	private static final String TOKENS_DIRECTORY_PATH = "tokens/path";

	private static final String existingSpreadSheetID ="13gfYl2OOdykh-oXCHtrygUDYETRCI2NXa7XPKT6hQoA";
	private static final List<String> SCOPES = Arrays.asList(SheetsScopes.SPREADSHEETS,SheetsScopes.DRIVE);
	private static final String CREDENTIALS_FILE_PATH = "/credentials.json";

	static Sheets.Spreadsheets spreadsheets;

	private static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
		InputStream in = SheetWriteExample.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
		if (in == null) {
			throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
		}
		GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

		GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
				HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, SCOPES)
				.setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
				.setAccessType("offline")
				.build();

		LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
		return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
	}


	public static void main(String... args)throws IOException,GeneralSecurityException, InterruptedException{
		final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
		final String spreadsheetId = "13gfYl2OOdykh-oXCHtrygUDYETRCI2NXa7XPKT6hQoA";
		final String range = "Sample"+"!B:B"; // specify the cell to write to

		Sheets service = new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
				.setApplicationName(APPLICATION_NAME).build();
		ValueRange response = service.spreadsheets().values().get(spreadsheetId, range).execute();
		int totalCount = 0;
		List<List<Object>> values = response.getValues();
		if(values == null || values.isEmpty()) {
			System.out.println("No Data Found");
		}
		else {
			totalCount = values.size();
			System.out.println("Total Count: " + totalCount);
			//        	for(List row : values) {
			//        		System.out.printf("%s,%s\n" , row.get(0),row.get(1));
			//        	}
			for (List<Object> row : values) {
				if (!row.isEmpty()) {
					//    System.out.println(row.get(0));
				}
			}
		}

		getSpreadsheetInstance();
		//  createNewSpreadSheet();
		//  createNewSheet(existingSpreadSheetID,"test1123");
//		StudentLocator app = new StudentLocator();
		for (int i = 1; i <totalCount; i++) {
			try {
				String cellValue = SheetsQuickstart.getColumnRow(i, 3);
				if (cellValue != null && !cellValue.isEmpty()) {
					System.out.println("Cell value: " + cellValue);

					BaseClass.browserLaunch();
					BaseClass.loadUrl(cellValue);

					String title = BaseClass.getTitle();
					System.out.println("Current Page Title: " + title);

					// Find the index of " on the App Store" with variations in spacing
					int endIndex = title.indexOf(" on the App\u00a0Store");

					// Check if the substring was found
					if (endIndex != -1) {
						// Extract the substring up to the found index
						String extractedTitle = title.substring(0, endIndex).trim();

						System.out.println("Extracted Title: " + extractedTitle);
						Thread.sleep(1000);
//						try {
//							if(BaseClass.getWebElementByXpath(app.logoImageIOS).isDisplayed() || BaseClass.getWebElementByXpath("//h1[text()='"+extractedTitle+"']").isDisplayed()) {
//								BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(app.logoImageIOS));
//								System.out.println(extractedTitle+" Logo is Available");
//								BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath("//h1[text()='"+extractedTitle+"']"));
//								System.out.println(extractedTitle+" Application Name is same as Title Name");
//							}else {
//								System.out.println("Logo is not Available");
//								System.out.println("Application Name is not same as Title Name");
//							}
//
//							writeDataGoogleSheets(BaseClass.readProperty("iOSSheetName") , new ArrayList<Object>
//							(Arrays.asList("YES")),existingSpreadSheetID);
//						}
//						catch(Exception e) {
//							BaseClass.ScreenShot(driver, extractedTitle);
//							writeDataGoogleSheets(BaseClass.readProperty("iOSSheetName") , new ArrayList<Object>
//							(Arrays.asList("No")),existingSpreadSheetID);
//							System.out.println(e.getMessage());
//						}

						//Thread.sleep(1000);
						BaseClass.BrowserClose(); // Commented out to keep the browser open for debugging
					} else {
						System.out.println("Substring not found in the title.");
					}
				} else {
					System.out.println("No value found in the specified cell no: " + i);
					writeDataGoogleSheets(BaseClass.readProperty("iOSSheetName") , new ArrayList<Object>
					(Arrays.asList("NA")),existingSpreadSheetID);
				}
			} catch (IOException | GeneralSecurityException e) {
				e.printStackTrace();
			}
		}

	}

	//    public static void writeDataGoogleSheets(String sheetName,List<Object>data,String existingSpreadSheetID) throws IOException {
	//    	int nextRow = getRows(sheetName,existingSpreadSheetID)+1;
	//    	writeSheet(data,"!I"+nextRow,existingSpreadSheetID);
	//    }
	public static void writeDataGoogleSheets(String sheetName, List<Object> data, String existingSpreadSheetID) throws IOException {
		String column = "I";
		int nextRow = getRows(sheetName, column, existingSpreadSheetID) + 1;
		writeSheet(data, "!" + column + nextRow, existingSpreadSheetID);
		
	}
	public static int getRows(String sheetName, String column, String existingSpreadSheetID) throws IOException {
		String range = sheetName + "!" + column + ":" + column;
		ValueRange valueRange = spreadsheets.values().get(existingSpreadSheetID, range).execute();
		List<List<Object>> values = valueRange.getValues();

		return (values != null && !values.isEmpty()) ? values.size() : 0;
	}


	//    public static int getRows(String sheetName,String existingSpreadSheetID) throws  IOException {
	//		
	//    	List<List<Object>> values = spreadsheets.values().get(existingSpreadSheetID, sheetName).execute().getValues();
	//    	int numRows = values !=null ? values.size() :0;
	//    	System.out.printf("%d rows retrieved. in '"+sheetName+"'\n",numRows);
	//    }
	//    public static void createNewSpreadSheet() throws GeneralSecurityException, IOException {
	//    	
	//    	Spreadsheet createdResponse = null;
	//    	try {
	//    		final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
	//    		Sheets service = new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
	//    		.setApplicationName(APPLICATION_NAME).build();
	//    		
	//    		SpreadsheetProperties spreadsheetProperties = new SpreadsheetProperties();
	//    		spreadsheetProperties.setTitle("Abubacker");
	//    		SheetProperties sheetProperties = new SheetProperties();
	//    		sheetProperties.setTitle("Test suite 1");
	//    		Sheet sheet = new Sheet().setProperties(sheetProperties);
	//    		
	//    		Spreadsheet spreadsheet = new Spreadsheet().setProperties(spreadsheetProperties)
	//    		            .setSheets(Collections.singletonList(sheet));
	//    		createdResponse =  service.spreadsheets().create(spreadsheet).execute();
	//    		
	//    		System.out.println("SpreadsheetURL : "+createdResponse.getSpreadsheetUrl());
	//    		
	//    		List<List<Object>> data = new ArrayList<List<Object>>();
	//    		List<Object> list2 = new ArrayList<Object>();
	//    		
	//    		list2.add("Good");
	//    		list2.add("Morning");
	//    		list2.add("=1+1");
	//    		
	//    		data.add(list2);
	//    		
	//    	/*	ValueRange valuerange = new ValueRange().setValues(data);
	//    		service.spreadsheets().values().update(createdResponse.getSpreadsheetId(),
	//    				"A1",valuerange).setValueInputOption("RAW").execute();*/
	//    		
	//    		ArrayList<Object> data1 = new ArrayList<Object>(
	//    			Arrays.asList("Source","Status code","Test status","=5+5"));
	//    		writeSheet(data1,"A1",createdResponse.getSpreadsheetId());
	//    		
	//    	}
	//    	catch(GoogleJsonResponseException e) {
	//    		
	//    		GoogleJsonError error = e.getDetails();
	//    		if(error.getCode() ==404) {
	//    			System.out.printf("Spreadsheet not found with id '%s'./n", createdResponse.getSpreadsheetId());
	//    		}else {
	//    			throw e;
	//    		}
	//    	}	
	//    }

	//    public static void createNewSheet(String existingSpreadSheetID, String newsheetTitle) throws GeneralSecurityException, IOException {
	//    	AddSheetRequest addSheetRequest = new AddSheetRequest();
	//    	SheetProperties sheetProperties = new SheetProperties();
	//    	sheetProperties.setIndex(0);
	//    	
	//    	addSheetRequest.setProperties(sheetProperties);
	//    	addSheetRequest.setProperties(sheetProperties.setTitle(newsheetTitle));
	//    	
	//    	BatchUpdateSpreadsheetRequest batchUpdateSpreadsheetRequest = new BatchUpdateSpreadsheetRequest();
	//    	
	//    	List<Request> requestList = new ArrayList<Request>();
	//    	batchUpdateSpreadsheetRequest.setRequests(requestList);
	//    	
	//    	Request request = new Request();
	//    	request.setAddSheet(addSheetRequest);
	//    	requestList.add(request);
	//    	
	//    	batchUpdateSpreadsheetRequest.setRequests(requestList);
	//    	
	//    	spreadsheets.batchUpdate(existingSpreadSheetID,batchUpdateSpreadsheetRequest).execute();
	//    }

	public static void getSpreadsheetInstance() throws GeneralSecurityException, IOException {
		final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
		spreadsheets = new Sheets.Builder(GoogleNetHttpTransport.newTrustedTransport(), GsonFactory.getDefaultInstance(),
				getCredentials(HTTP_TRANSPORT)).setApplicationName("Google Sheet Java Integrat").build().spreadsheets();
	}

	public static void writeSheet(List<Object> inputData,String sheetAndRange ,String existingSpredSheetID) throws IOException {

		@SuppressWarnings("unchecked")
		List<List<Object>> values = Arrays.asList(inputData);
		ValueRange body = new ValueRange().setValues(values);
		UpdateValuesResponse result = spreadsheets.values().update(existingSpredSheetID,sheetAndRange,body)
				.setValueInputOption("USER_ENTERED").execute();
		System.out.printf("%d cells updated.\n",result.getUpdatedCells());
	}

	//   
}
