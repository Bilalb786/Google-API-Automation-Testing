package PageExecutionForTATAProject;

import static org.junit.Assert.assertTrue;
//	import static org.testng.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

import java.util.Properties;
import javax.mail.Session;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.net.ssl.TrustManager;

import javax.net.ssl.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import java.security.GeneralSecurityException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Transport;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.sheets.v4.model.UpdateValuesResponse;
import com.google.api.services.sheets.v4.model.ValueRange;
import com.google.auth.http.HttpCredentialsAdapter;
import com.google.auth.oauth2.GoogleCredentials;

import BaseClassPackage.BaseClass;
import io.github.bonigarcia.wdm.WebDriverManager;

//import jakarta.mail.internet.InternetAddress;
//import jakarta.mail.internet.MimeMessage;

public class TabDelimitedTextFile extends BaseClass {

	public TabDelimitedTextFile(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

//		public AddActivities(WebDriver driver) {
//			super(driver);
//			// TODO Auto-generated constructor stub
//		}

//		static WebDriver driver;

//		private static final String APPLICATION_NAME = "Google Sheets API";
//		private static final JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();
//		private static final String TOKENS_DIRECTORY_PATH = "tokens/path";
//
//		private static final String existingSpreadSheetID = "1uOoWQcXNq3LAXJHDH2Aub1y4jYw1cptzQumZg7VSPwU";
//		private static final List<String> SCOPES = Arrays.asList(SheetsScopes.SPREADSHEETS, SheetsScopes.DRIVE);
//		private static final String CREDENTIALS_FILE_PATH = "/credentials.json";

//		GoogleCredential credential = GoogleCredential
//		        .fromStream(new FileInputStream("path/to/credentials.json"))
//		        .createScoped(Collections.singleton(SheetsScopes.SPREADSHEETS_READONLY));

//		static Sheets.Spreadsheets spreadsheets;
//
//		private static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
//			InputStream in = SheetWriteExample.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
//			if (in == null) {
//				throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
//			}
//			GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));
//
//			GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(HTTP_TRANSPORT, JSON_FACTORY,
//					clientSecrets, SCOPES)
//					.setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
//					.setAccessType("offline").build();
//
//			LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
//			AuthorizationCodeInstalledApp app = new AuthorizationCodeInstalledApp(flow, receiver);
//			Credential credential = app.authorize("user");
//			return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
//		}
//
//		public static String path = System.getProperty("user.dir");
//
//		public static void ScreenShot(WebDriver driver, String name) {
//			// Specify the folder path where you want to save the extent report
//			String folderPath = path + "/Screenshot/";
//
//			// Create folder if it doesn't exist
//			File folder = new File(folderPath);
//			if (!folder.exists()) {
//				folder.mkdirs();
//			}
//			try {
//				TakesScreenshot ts = (TakesScreenshot) driver;
//				File src = ts.getScreenshotAs(OutputType.FILE);
//				File des = new File(folderPath + name + ".png");
//				FileHandler.copy(src, des);
//				// System.out.println("Screenshot saved at: " + des.getAbsolutePath());
//			} catch (IOException e) {
//				// e.printStackTrace();
//				System.err.println("Error occurred while taking a screenshot: " + e.getMessage());
//			}
//		}

//=============================================================================================================

//		private static final String APPLICATION_NAME = "Google Sheets API";
//		private static final JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();
//		private static final String TOKENS_DIRECTORY_PATH = "tokens/path";
	//

//		private static final List<String> SCOPES = Arrays.asList(SheetsScopes.SPREADSHEETS,SheetsScopes.DRIVE);
//		private static final String CREDENTIALS_FILE_PATH = "/credentials.json";
	//
//		static Sheets.Spreadsheets spreadsheets;
//	public static WebDriver driver;
	
	private static final String existingSpreadSheetID = "1uOoWQcXNq3LAXJHDH2Aub1y4jYw1cptzQumZg7VSPwU";
	private static final String APPLICATION_NAME = "ZaniAnalytics";
	private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
	private static final String SERVICE_ACCOUNT_KEY_FILE_PATH = "service_account.json"; // Ensure path is correct
	private static Sheets service;

	public static Sheets getSheetsService() throws IOException, GeneralSecurityException {
		final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
		InputStream in = TabDelimitedTextFile.class.getClassLoader().getResourceAsStream("service_account.json");

		if (in == null) {
			throw new FileNotFoundException("Resource not found: service_account.json");
		}

		GoogleCredentials credentials = GoogleCredentials.fromStream(in)
				.createScoped(Arrays.asList(SheetsScopes.SPREADSHEETS, SheetsScopes.DRIVE));

		return new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, new HttpCredentialsAdapter(credentials))
				.setApplicationName(APPLICATION_NAME).build();
	}

	public static Sheets.Spreadsheets getSpreadsheetInstance() throws IOException, GeneralSecurityException {
		if (service == null) {
			service = getSheetsService();
		}
		return service.spreadsheets();
	}

	public static void writeDataGoogleSheets(String sheetName, List<Object> data, String spreadsheetId, int row)
			throws IOException, GeneralSecurityException {
		Sheets.Spreadsheets spreadsheets = getSpreadsheetInstance();
		String Statuscolumn = "D"; // You can parameterize this too if needed
		String PassDatescolumn = "E"; // You can parameterize this too if needed

		// Use the provided row directly
		String Drange = sheetName + "!" + Statuscolumn + row;
		String Erange = sheetName + "!" + PassDatescolumn + row;

		List<List<Object>> values = Collections.singletonList(data);
		ValueRange body = new ValueRange().setValues(values);

		UpdateValuesResponse CredentialStatusresult = spreadsheets.values().update(spreadsheetId, Drange, body)
				.setValueInputOption("USER_ENTERED").execute();

		System.out.printf("%d cells updated at %s.\n", CredentialStatusresult.getUpdatedCells(), Drange);

		UpdateValuesResponse PassDateresult = spreadsheets.values().update(spreadsheetId, Erange, body)
				.setValueInputOption("USER_ENTERED").execute();

		System.out.printf("%d cells updated at %s.\n", PassDateresult.getUpdatedCells(), Erange);
	}

	public static int getRows(String sheetName, String column, String spreadsheetId)
			throws IOException, GeneralSecurityException {
		Sheets.Spreadsheets spreadsheets = getSpreadsheetInstance();
		String range = sheetName + "!" + column + ":" + column;
		ValueRange response = spreadsheets.values().get(spreadsheetId, range).execute();
		List<List<Object>> values = response.getValues();
		return (values != null && !values.isEmpty()) ? values.size() : 0;
	}

	public static String getColumnRowvalue(int row, int col) throws IOException, GeneralSecurityException {
		Sheets.Spreadsheets spreadsheets = getSpreadsheetInstance();
		String sheetName = "FailDatesSheet";
		String range = sheetName;

		ValueRange response = spreadsheets.values().get(existingSpreadSheetID, range).execute();

		List<List<Object>> values = response.getValues();

		if (values != null && row < values.size() && col < values.get(row).size()) {
			return values.get(row).get(col).toString();
		} else {
			throw new IndexOutOfBoundsException("Requested cell is out of sheet data bounds.");
		}
	}

	public static String getColumnRowD(int row, int col) throws IOException, GeneralSecurityException {
		Sheets.Spreadsheets spreadsheets = getSpreadsheetInstance();
		String sheetName = "FailDatesSheet";
		String range = sheetName;

		ValueRange response = spreadsheets.values().get(existingSpreadSheetID, range).execute();

		List<List<Object>> values = response.getValues();

		if (values != null && row < values.size() && col < values.get(row).size()) {
			return values.get(row).get(col).toString();
		} else {
			throw new IndexOutOfBoundsException("Requested cell is out of sheet data bounds.");
		}
	}

	// ================================================================================================================

	public static WebElement waitForElementToBeClickable(WebElement locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.elementToBeClickable(locator));
	}

	public static WebElement waitForElementToBeVisible(WebElement locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.visibilityOfElementLocated((By) locator));
	}

	public WebDriverWait wait;
//	private static WebElement webElement;

	public static WebElement waitForElementToBePresent(By locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}

	public boolean waitForTextToBePresentInElement(By locator, String text, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
	}

	public static boolean waitForElementToBeInvisible(WebElement locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.invisibilityOfElementLocated((By) locator));
	}

	public void verifyTextVisible(String expectedText, By locator) {
		// Wait until the element with the text is visible
		WebElement element = waitForElementToBeVisible(locator, 10);

		// Check if the element contains the expected text
		assertTrue("Text not visible or incorrect!", element.getText().contains(expectedText));

	}

	public static boolean isRadioButtonChecked(By locator) {
		try {
			WebElement radioButton = driver.findElement(locator);
			return radioButton.isSelected();
		} catch (NoSuchElementException e) {
			System.out.println("Radio button not found: " + e.getMessage());
			return false;
		}
	}

	public static void dragAndDrop(By sourceLocator, By targetLocator) {
		try {
			// Find source and target elements
			WebElement sourceElement = driver.findElement(sourceLocator);
			WebElement targetElement = driver.findElement(targetLocator);

			// Create Actions object
			Actions actions = new Actions(driver);

			// Perform drag and drop
			actions.dragAndDrop(sourceElement, targetElement).build().perform();
		} catch (Exception e) {
			System.out.println("Drag and drop failed: " + e.getMessage());
		}
	}

	public static void safeClickWithRetry(WebDriver driver, By locator) {
		int retries = 3; // Number of attempts
		for (int i = 0; i < retries; i++) {
			try {
				WebElement element = driver.findElement(locator);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
				break; // Break loop if click is successful
			} catch (StaleElementReferenceException e) {
				System.out.println("StaleElementReferenceException encountered. Retrying...");
			}
		}
	}

	public static void treadWait(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void gettext(String word) {
		String text = word;
		Pattern pattern = Pattern.compile("Question ID (\\d+)");
		Matcher matcher = pattern.matcher(text);

		if (matcher.find()) {
			String questionId = matcher.group(1);
			System.out.println("Extracted Question ID: " + questionId);
		} else {
			System.out.println("No ID found.");
		}
	}

	private static boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean acceptNextAlert = true;
	private static StringBuffer verificationErrors = new StringBuffer();

	static final String FILE_PATH = "1uOoWQcXNq3LAXJHDH2Aub1y4jYw1cptzQumZg7VSPwU"; // File to track progress
	static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	// ==========================================================================================================

//	private static final int BATCH_SIZE = 14; // Number of rows per column
//	private static char currentColumn = 'E'; // Start with column E
//	private static int currentRow = 2; // Start from row 2 (assuming row 1 is header)

	public static void writeDateToColumnE(String sheetName, String dateRange, String spreadsheetId, int row)
			throws IOException, GeneralSecurityException {
		Sheets.Spreadsheets spreadsheets = getSpreadsheetInstance();
		String range = sheetName + "!E" + row; // Column E
//		String range = sheetName + "!F" + row; // Column E

		// Create a simple list with the date range string
		List<Object> dataRow = Collections.singletonList(dateRange);
		List<List<Object>> values = Collections.singletonList(dataRow);

//		List<List<Object>> values = Collections.singletonList(Collections.singletonList(dateRange));
//		ValueRange body = new ValueRange().setValues(values);
//		ValueRange body = new ValueRange()
//		        .setValues(Collections.singletonList(Collections.singletonList(values)));
		ValueRange body = new ValueRange().setValues(values);

//		spreadsheets.values().update(spreadsheetId, range, body).setValueInputOption("USER_ENTERED").execute();
		try {
			UpdateValuesResponse result = spreadsheets.values().update(spreadsheetId, range, body)
					.setValueInputOption("USER_ENTERED").execute();

			System.out.println("Successfully wrote to " + range);
		} catch (GoogleJsonResponseException e) {
			System.err.println("Failed to write to Google Sheets: " + e.getDetails().getMessage());
			throw e;
		}

		// Move to next position
//		currentRow++;
//		if (currentColumn > BATCH_SIZE + 1) { // +1 because we started at row 2
//			currentColumn++; // Move to next column (E → F → G, etc.)
////			currentRow = 2; // Reset to row 2
//		}
	}

	// Modified writeDataGoogleSheets method to handle status and dates separately
	public static void writeStatusToColumnD(String sheetName, String status, String spreadsheetId, int row)
			throws IOException, GeneralSecurityException {
		Sheets.Spreadsheets spreadsheets = getSpreadsheetInstance();
		String range = sheetName + "!D" + row; // Column D

		List<List<Object>> values = Collections.singletonList(Collections.singletonList(status));
		ValueRange body = new ValueRange().setValues(values);

		spreadsheets.values().update(spreadsheetId, range, body).setValueInputOption("USER_ENTERED").execute();
	}

	// ==============================================================================================================

	// Updated method to properly handle Google Sheets API requests
	public static String getColumnRow(int row, int col) throws IOException, GeneralSecurityException {
		try {
			Sheets.Spreadsheets spreadsheets = getSpreadsheetInstance();

			// Convert column number to letter (1 = A, 2 = B, etc.)
			String columnLetter = Character.toString((char) ('B' + col - 1));
			String range = "FailDatesSheet!" + columnLetter + row; // Use your actual sheet name

			ValueRange response = spreadsheets.values().get(existingSpreadSheetID, range).execute();

			List<List<Object>> values = response.getValues();

			if (values != null && !values.isEmpty() && !values.get(0).isEmpty()) {
				return values.get(0).get(0).toString();
			}
			return ""; // Return empty string if no value found
		} catch (GoogleJsonResponseException e) {
			System.err.println("Google Sheets API Error: " + e.getDetails().getMessage());
			throw e;
		}
	}

	// Helper method to get row count
	public static int getRowCount(String sheetName, String column) throws IOException, GeneralSecurityException {
		Sheets.Spreadsheets spreadsheets = getSpreadsheetInstance();
		String range = sheetName + "!" + column + "1:" + column;

		ValueRange response = spreadsheets.values().get(existingSpreadSheetID, range).execute();

		List<List<Object>> values = response.getValues();
		return (values != null) ? values.size() : 0;
	}

	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//	private static final int BATCH_SIZE = 14; // Number of rows per column
//	private static char currentColumn = 'E'; // Start with column E
//	private static int currentRow = 2; // Start from row 2 (assuming row 1 is header)

	// Method to write to current column and row
//	public static void writeToCurrentPosition(String sheetName, String value, String spreadsheetId)
//			throws IOException, GeneralSecurityException {
//		Sheets.Spreadsheets spreadsheets = getSpreadsheetInstance();
//		String range = sheetName + "!" + currentColumn + currentRow;
//
//		ValueRange body = new ValueRange().setValues(Collections.singletonList(Collections.singletonList(value)));
//
//		spreadsheets.values().update(spreadsheetId, range, body).setValueInputOption("USER_ENTERED").execute();
//
//		// Move to next position
////		currentRow++;
//		if (currentColumn > BATCH_SIZE + 1) { // +1 because we started at row 2
//			currentColumn++; // Move to next column (E → F → G, etc.)
////			currentRow = 2; // Reset to row 2
//		}
//	}

//	    // Initialize Google Sheets service (implementation depends on your auth method)
//	    private static Sheets getSpreadsheetInstance() throws IOException, GeneralSecurityException {
//	        // Your implementation to get Sheets service
//	        // (Using service account, OAuth, etc.)
//	        return null;
//	    }

	// ==================================================================================================================

	// Global variables for tracking position
	private static char currentColumn = 'E'; // Start with column E
	private static int currentRow = 2; // Start from row 2 (row 1 for headers)
	private static final int MAX_ROWS_PER_COLUMN = 14; // 14 rows per column (2-15)

	// Method to write date range and move to next position
	public static void writeDateRange(String sheetName, String dateRange, String spreadsheetId)
			throws IOException, GeneralSecurityException {
		Sheets.Spreadsheets spreadsheets = getSpreadsheetInstance();
		String range = sheetName + "!" + currentColumn + currentRow;

		// Create a simple list with the date range string
		List<Object> dataRow = Collections.singletonList(dateRange);
		List<List<Object>> values = Collections.singletonList(dataRow);

		ValueRange body = new ValueRange().setValues(values);

		try {
			UpdateValuesResponse result = spreadsheets.values().update(spreadsheetId, range, body)
					.setValueInputOption("USER_ENTERED").execute();

			System.out.println("Wrote to " + range + ": " + dateRange);

			// Move to next position
			currentRow++;

			// If we've filled 14 rows, move to next column
			if (currentRow > MAX_ROWS_PER_COLUMN + 1) { // +1 because we started at row 2
				currentColumn++;
				currentRow = 2; // Reset to row 2

				// Stop if we've reached column N
				if (currentColumn > 'N') {
					System.out.println("Reached column N. Stopping.");
					return;
				}
			}
		} catch (GoogleJsonResponseException e) {
			System.err.println("Failed to write to Google Sheets: " + e.getDetails().getMessage());
			throw e;
		}
	}

	// Global variables to track failed dates
	private static Map<String, LocalDate> failedDatesMap = new HashMap<>();

	// =======================================================================================================================

	public static int getColumnIndexForUsername(String sheetName, String username, String spreadsheetId)
			throws Exception {
		Sheets.Spreadsheets spreadsheets = getSpreadsheetInstance();
		String headerRange = sheetName + "!A1:Z1"; // Adjust if more columns
		ValueRange response = spreadsheets.values().get(spreadsheetId, headerRange).execute();
		List<Object> headers = response.getValues().get(0); // Row 1

		for (int col = 0; col < headers.size(); col++) {
			if (username.equalsIgnoreCase(headers.get(col).toString().trim())) {
				return col;
			}
		}
		throw new Exception("Username column not found for: " + username);
	}

//	public static int getRowIndexForUsername(List<List<Object>> rows, String username) throws Exception {
//	    for (int i = 0; i < rows.size(); i++) {
//	        List<Object> row = rows.get(i);
//	        if (row.size() > 1 && row.get(1).toString().equalsIgnoreCase(username)) { // Column B
//	            return i + 1; // +1 because Sheets are 1-indexed
//	        }
//	    }
//	    throw new Exception("Username row not found for: " + username);
//	}
//
//	public static int getColumnIndexByHeader(List<Object> headerRow, String headerName) throws Exception {
//	    for (int i = 0; i < headerRow.size(); i++) {
//	        if (headerRow.get(i).toString().equalsIgnoreCase(headerName)) {
//	            return i;
//	        }
//	    }
//	    throw new Exception("Header column not found for: " + headerName);
//	}

	public static void appendDateRangeToColumn(String sheetName, int columnIndex, String dateRange,
			String spreadsheetId) throws Exception {
		Sheets.Spreadsheets spreadsheets = getSpreadsheetInstance();

		// Convert columnIndex to A, B, C, etc.
		String columnLetter = String.valueOf((char) ('A' + columnIndex));
		String fullRange = sheetName + "!" + columnLetter + ":" + columnLetter;

		// Read existing column values
		ValueRange readResponse = spreadsheets.values().get(spreadsheetId, fullRange).execute();
		int nextEmptyRow = (readResponse.getValues() != null) ? readResponse.getValues().size() + 1 : 2;

		// Write the new dateRange at nextEmptyRow
		String writeRange = sheetName + "!" + columnLetter + nextEmptyRow;
		ValueRange body = new ValueRange().setValues(Collections.singletonList(Collections.singletonList(dateRange)));

		spreadsheets.values().update(spreadsheetId, writeRange, body).setValueInputOption("RAW").execute();

		System.out.println("✅ Date range added to " + writeRange);
	}
	
	public static void appendProcessRangeToColumn(String sheetName, int columnIndex, String dateRange,
			String spreadsheetId) throws Exception {
		Sheets.Spreadsheets spreadsheets = getSpreadsheetInstance();

		// Convert columnIndex to A, B, C, etc.
		String columnLetter = String.valueOf((char) ('A' + columnIndex));
		String fullRange = sheetName + "!" + columnLetter + ":" + columnLetter;

		// Read existing column values
		ValueRange readResponse = spreadsheets.values().get(spreadsheetId, fullRange).execute();
		int nextEmptyRow = (readResponse.getValues() != null) ? readResponse.getValues().size() + 1 : 2;

		// Write the new dateRange at nextEmptyRow
		String writeRange = sheetName + "!" + columnLetter + nextEmptyRow;
		ValueRange body = new ValueRange().setValues(Collections.singletonList(Collections.singletonList(dateRange)));

		spreadsheets.values().update(spreadsheetId, writeRange, body).setValueInputOption("RAW").execute();

		System.out.println("✅ Process range added to " + writeRange);
	}

	// ========================================================================================================================

	static String sheetName;

	public static String getLastFailedDateRange(String sheetName, String spreadsheetId, String username)
			throws IOException, GeneralSecurityException {
//	    Sheets sheetsService = getSheetsService(); // Your Google Sheets initialization
		Sheets.Spreadsheets spreadsheets = getSpreadsheetInstance();

		String range = sheetName + "!F2:G"; // Column F (Username), G (Date)
//	    ValueRange response = sheetsService.spreadsheets().values()
//	            .get(spreadsheetId, range)
//	            .execute();
		ValueRange response = spreadsheets.values().get(existingSpreadSheetID, range).execute();

		List<List<Object>> values = response.getValues();

		if (values != null) {
			for (List<Object> row : values) {
				if (row.size() > 0 && row.get(0).toString().equalsIgnoreCase(username)) {
					return (row.size() > 1) ? row.get(1).toString() : null;
				}
			}
		}
		return null;
	}

	public static LocalDate[] getNext15DayRangeAfterFailure(String failedRange) {
		if (failedRange == null || !failedRange.contains(">=") || !failedRange.contains("<=")) {
			return null;
		}

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Pattern pattern = Pattern.compile(">=\\s*(\\d{2}/\\d{2}/\\d{4})\\s*and\\s*<=\\s*(\\d{2}/\\d{2}/\\d{4})");
		Matcher matcher = pattern.matcher(failedRange);

		if (matcher.find()) {
			LocalDate startDate = LocalDate.parse(matcher.group(1), formatter);
			LocalDate newStart = startDate.plusDays(15);
			LocalDate newEnd = newStart.plusDays(14);
			return new LocalDate[] { newStart, newEnd };
		}

		return null;
	}

	// ==================================================================================================================

	public static String getPrevious15Days(String range) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

		// Extract dates from range
		String[] parts = range.replace(">=", "").replace("<=", "").split("and");
		LocalDate currentStart = LocalDate.parse(parts[0].trim(), formatter);

		// Subtract 15 days from the current start
		LocalDate newStart = currentStart.minusDays(7);
		LocalDate newEnd = newStart.plusDays(6);

		// Build the new range string
		return ">= " + newStart.format(formatter) + " and <= " + newEnd.format(formatter);
	}

	public static String readLastUpdatedDate(Sheets sheetsService, String spreadsheetId, String sheetName,
			String column) throws IOException, GeneralSecurityException {

		String range = sheetName + "!" + column + ":" + column; // Example: "FailDatesSheet!E:E"
		ValueRange response = sheetsService.spreadsheets().values().get(spreadsheetId, range).execute();

		List<List<Object>> values = response.getValues();

		// Check from bottom to top for the last non-empty value
		if (values != null && !values.isEmpty()) {
			for (int i = values.size() - 1; i >= 0; i--) {
				if (!values.get(i).isEmpty()) {
					return values.get(i).get(0).toString(); // Return last non-empty date
				}
			}
		}

		return null; // No date found
	}

	// =======================================================================================================================

	public static void sendEmail(String subject, String body) {
		final String fromEmail = "tatasend@yopmail.com"; // your Gmail
		final String password = "1234"; // app password from Gmail
		final String toEmail = "tatareceive@yopmail.com"; // destination email

		// Step 1: Setup mail server properties
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		// Step 2: Create session
		Session session = Session.getInstance(props, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(fromEmail, password);
			}
		});

		try {
			// Step 3: Create message
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(fromEmail));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
			message.setSubject("Automated Test Report");
			message.setText("Hi,\n\nThis is an automated email from your Java program.");

			// Step 4: Send message
			Transport.send(message);
			System.out.println("✅ Email sent successfully.");

		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	// =================================================================================================================

	public static void disableCertificateValidation() throws Exception {
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs, String authType) {
			}

			public void checkServerTrusted(X509Certificate[] certs, String authType) {
			}
		} };

		SSLContext sc = SSLContext.getInstance("TLS");
		sc.init(null, trustAllCerts, new SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

		// Disable hostname verification too
		HostnameVerifier allHostsValid = (hostname, session) -> true;
		HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	}

	// ====================================================================================================================

	public static void main(String[] args) throws Exception {

		final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
		final String spreadsheetId = "1uOoWQcXNq3LAXJHDH2Aub1y4jYw1cptzQumZg7VSPwU";
		final String range = "FailDatesSheet"; // specify the cell to write to
		Sheets sheetsService = getSheetsService(); // Your Google Sheets initialization

		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		TabDelimitedTextFile assertions = new TabDelimitedTextFile(driver);
		// =====================================================================================
		final String fromEmail = getColumnRow(2, 24); // your Gmail
		final String password = getColumnRow(2, 25); // app password from Gmail
		final String toEmail = getColumnRow(3, 24); // destination email
		
		System.out.println(fromEmail);
		System.out.println(password);
		System.out.println(toEmail);

		// Step 1: Setup mail server properties
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		// Step 2: Create session
		Session session = Session.getInstance(props, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(fromEmail, password);
			}
		});

//		
//================================================================================================================

//        String to = "barathselvi5317@outlook.com";
//        String from = "bilalhussainb786@outlook.com";
//        String host = "smtp.office365.com"; // For Outlook
//        final String username = "bilalhussainb786@outlook.com";
//        final String password = "cnihotojycsklqhz"; // NOT your login password
////        final String password = System.getenv("cnihotojycsklqhz");
//        
//
////        Properties props = new Properties();
////        props.put("mail.smtp.host", host);
////        props.put("mail.smtp.port", "587");
////        props.put("mail.smtp.auth", "true");
////        props.put("mail.smtp.starttls.enable", "true"); // STARTTLS
//        
//        Properties props = new Properties();
//        props.put("mail.smtp.auth", "true");
//        props.put("mail.smtp.starttls.enable", "true");
//        props.put("mail.smtp.host", "smtp.office365.com");
//        props.put("mail.smtp.port", "587");
//
//        Session session = Session.getInstance(props,
//            new Authenticator() {
//                protected PasswordAuthentication getPasswordAuthentication() {
//                    return new PasswordAuthentication(username, password);
//                }
//            });
//        
//        System.out.println("Email: " + username);
//        System.out.println("Password: " + (password != null ? "present" : "null"));
//
//        try {
//            Message message = new MimeMessage(session);
//            message.setFrom(new InternetAddress(from));
//            message.setRecipients(
//                Message.RecipientType.TO,
//                InternetAddress.parse(to)
//            );
//            message.setSubject("Automation Test Mail");
//            message.setText("This is a test mail from automation script.");
//
//            Transport.send(message);
//
//            System.out.println("Mail sent successfully!");
//        } catch (MessagingException e) {
//            e.printStackTrace();
//        }
		String downloadPath = System.getProperty("user.home") + "\\Downloads"; // Windows default
		String oldFileName = "output.csv";         // downloaded file name
//        String newFileName = "Accounting Extracts.csv";   // name you want to rename to
		
		HashMap<String, Object> chromePrefs = new HashMap<>();
		chromePrefs.put("download.default_directory", downloadPath);
		chromePrefs.put("download.prompt_for_download", false);
		chromePrefs.put("safebrowsing.enabled", true);

		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", chromePrefs);

		// =======================================================================================================
		
		driver = new ChromeDriver(options);
		WebDriverManager.chromedriver().setup();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//		driver.get("https://crmdms.inservices.tatamotors.com/siebel/app/distributor/enu?SWECmd=Logoff");
		driver.get("https://www.google.com/");
		System.out.println("Chrome Browser is Launched");
		treadWait(2000);
		Actions act = new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));

//		System.out.println(getColumnRow(13, 4));
//			WriteDataOnSheetForTata.values("FailDatesSheet","A","Pass");

//		Sheets sheetsService = getSheetsService(); // ← Make sure this is called BEFORE using sheetsService

		String lastDate = TabDelimitedTextFile.readLastUpdatedDate(sheetsService, spreadsheetId, "FailDatesSheet", "E");
//		String FailCredential = TabDelimitedTextFile.readLastUpdatedDate(sheetsService, spreadsheetId, "FailDatesSheet", "D");
		System.out.println("Last updated date: " + lastDate);
		System.out.println("Value Writtren");

		// Get total number of rows with data
		int totalRows = getRowCount("FailDatesSheet", "B");
//			int row3 = 2;
		outer:
		// Iterate through each row
		for (int rowNum = 2; rowNum <= totalRows; rowNum++) {

//				int row1 = i+1;  // Make `row` final or effectively final
//				int row2 = i+1;
//				int row1 = i;
//			    String username = credentials[i][0];
//			    String password = credentials[i][1];
			int credentialRow = rowNum; // Assuming credentials start from row 2
			int dateRow = credentialRow; // Same row for date tracking
			
			// Get the status from column D
		    String status = getColumnRow(rowNum, 3); // Column D (0-based index 3)
		    
		    String processStatus = null;
		    
		    // Skip if status is "Pass"
		    if ("Pass".equalsIgnoreCase(status)) {
		        System.out.println("Skipping credential at row " + rowNum + " as it's already marked as Pass");
		        continue;
		    }

			// Check if this credential has a failed date to resume from
			LocalDate resumeDate = failedDatesMap.get(credentialRow);
			LocalDate endDate = (resumeDate != null) ? resumeDate : LocalDate.now();
			// 6 months ago from today
			LocalDate oneWeekAgo = endDate.minusDays(7);

			Thread.sleep(2000);
//				
			// Get values from columns B and C (index 1 and 2)
			String valueB = getColumnRow(rowNum, 1); // Column B
			String valueC = getColumnRow(rowNum, 2); // Column C
			String previousRange = null;
			
			


			try {
				// Enter username and password
				WebElement usernameField = wait
						.until(ExpectedConditions.visibilityOfElementLocated(By.id("s_swepi_1")));
				usernameField.clear();
				usernameField.sendKeys(valueB);
				WebElement passwordField = wait
						.until(ExpectedConditions.visibilityOfElementLocated(By.id("s_swepi_2")));
				passwordField.clear();
				passwordField.sendKeys(valueC);
				driver.findElement(By.id("s_swepi_22")).click();

				// Optional: Wait for error message or successful login
				try {
					WebElement errorMsg = wait
							.until(ExpectedConditions.visibilityOfElementLocated(By.className("siebui-error")));
					System.out.println("Login failed for user: " + valueB + " - Error: " + errorMsg.getText());
					try {
						// Step 3: Create message
						MimeMessage message = new MimeMessage(session);
						message.setFrom(new InternetAddress(fromEmail));
						message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
						message.setSubject("Automated Test Report For TATA CRM");
						message.setText(
								"Hi Sir,\n\nThis is an automated email from Webee. \n\nFollowing Credential is faild \nUsername: "
										+ valueB + "\nPassword: " + valueC);

						// Step 4: Send message
						Transport.send(message);
						System.out.println("✅ Email sent successfully.");

					} catch (MessagingException e) {
						e.printStackTrace();
					}
					continue;
				} catch (TimeoutException e) {
					System.out.println("Login successful for user: " + valueB);
					// Add logout step if continuing with next user
				}

			} catch (Exception e) {
				System.out.println("Exception during login for " + valueB + ": " + e.getMessage());
			}

//			driver.get("https://crmdms.inservices.tatamotors.com/siebel/app/distributor/enu");
			driver.navigate().refresh();
			Thread.sleep(4000);
			WebElement sitemapBtn = driver
					.findElement(By.xpath("//li/span[@class='siebui-icon-tb-sitemap ToolbarButtonOn']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", sitemapBtn);

			// Read the last success or failed date (if file exists)
//	        LocalDate resumeDate = readLastFailedDate();	
//	        int retryCount = 0;
//	        int maxRetries = 2; // Set how many retries you allow

//				int fileStartIndex = (i == resumeCredIndex) ? resumeFileIndex : 0;

			while (endDate.isAfter(oneWeekAgo)) {

//					for (boolean j = endDate.isAfter(sixMonthsAgo); j < endDate.isAfter(sixMonthsAgo).length; j++) {
//				        String inputRange = fileInputs[j];	

				LocalDate startDate = endDate.minusDays(7); // 15-day interval
				// Format and print the range
				String formattedStart = startDate.format(formatter);
				String formattedEnd = endDate.format(formatter);
				String dateRange = ">= " + formattedStart + " and <= " + formattedEnd;

				System.out.println(">= " + formattedStart + " and <= " + formattedEnd);

//				int colIndex = getColumnIndexForUsername("FailDatesSheet", valueB, spreadsheetId);
//				appendDateRangeToColumn("FailDatesSheet", colIndex, dateRange, spreadsheetId);

//	            if (resumeDate != null) {
//	                System.out.println("Resuming from last failed date: " + resumeDate.format(formatter));
//	                endDate = resumeDate;
//	                retryCount++;
//	                
//	            } else {
//	                System.out.println("No last failure recorded. Starting from today.");

				// If startDate is before the 6-month limit, clamp it
				if (startDate.isBefore(oneWeekAgo)) {
					startDate = oneWeekAgo;
				}

				try {
					boolean testPassed = runTestForRange(formattedStart, formattedEnd);

					if (!testPassed) {
						System.out.println("❌ Test failed for credential: " + valueB + ", file: ");

						int column = getColumnIndexForUsername("FailDatesSheet", valueB, spreadsheetId);
						appendDateRangeToColumn("FailDatesSheet", column, dateRange, spreadsheetId);

//			                saveResumeState(i, resumeCredIndex);
//						driver.quit();
						break outer;
					}

					String StatusValue = getColumnRow(3, rowNum);

					if (testPassed) {

//						driver.findElement(By.id("s_1_1_11_0_Ctrl")).click();

						JavascriptExecutor js = (JavascriptExecutor) driver;
						
						File downloadedFile;
						int waitTime;
						
						// Scenario 1

						boolean AccountingExtracts = isElementPresent(
								By.xpath("(//a[text()='Accounting Extracts'])[1]"));
						;
						if (AccountingExtracts == true) {

							try {
								System.out.println("Accounting Extracts process");
								driver.findElement(By.xpath("(//a[text()='Accounting Extracts'])[1]")).click();
								System.out.println("Scenario 1 executed.");
								Thread.sleep(6000);
								waitForElementToBePresent(By.xpath("//*[text()='OTC Sales Header']"), 10);
								driver.findElement(By.xpath("//*[text()='OTC Sales Header']")).click();
								driver.findElement(By.id("s_1_1_11_0_Ctrl")).click();

								Thread.sleep(4000);

								driver.findElement(By.id("1_s_1_l_Invoice_Date")).click();
								waitForElementToBePresent(By.id("1_Invoice_Date"), 10);
								driver.findElement(By.id("1_Invoice_Date")).clear();
								driver.findElement(By.id("1_Invoice_Date")).sendKeys(dateRange);
								driver.findElement(By.id("1_Invoice_Date")).sendKeys(Keys.ENTER);

								Thread.sleep(8000);
								wait.until(ExpectedConditions
										.elementToBeClickable(By.xpath("//*[@title='OTC Sales Header Menu']")));
								Thread.sleep(5000);
								driver.findElement(By.xpath("//*[@title='OTC Sales Header Menu']")).click();
//				        		    driver.findElement(By.xpath("//div[10]")).click();
								driver.findElement(By.xpath("//*[text()='Export...']")).click();
								Thread.sleep(4000);

								Thread.sleep(4000);
								js.executeScript("arguments[0].click();",
										driver.findElement(By.xpath("//button[@data-display='Next']")));
//								
								System.out.println("Wait the export done");

								Thread.sleep(2000);

//									// Warning: waitForTextPresent may require manual changes
								driver.findElement(By.cssSelector("BODY")).getText()
										.matches("^[\\s\\S]*id=_sweExportProgress_Label_2[\\s\\S]*$");
//								
								System.out.println("Export successfully done");
								
								// Step 5: Wait for the file to download
						         downloadedFile = new File(downloadPath + "\\" + oldFileName);
						         waitTime = 0;
						        while (!downloadedFile.exists() && waitTime < 30) {
						            try {
						                Thread.sleep(1000); // wait 1 second
						                waitTime++;
						            } catch (InterruptedException e) {
						                e.printStackTrace();
						            }
						        }
						        
						        String AccountingExtractsFile = valueB+"_Accounting_Extracts.csv"; 

						        // Step 6: Rename the file
						        if (downloadedFile.exists()) {
						            File renamedFile = new File(downloadPath + "\\" + AccountingExtractsFile);
						            if (downloadedFile.renameTo(renamedFile)) {
						                System.out.println("File renamed to: " + AccountingExtractsFile);
						            } else {
						                System.out.println("Failed to rename the file.");
						            }
						        } else {
						            System.out.println("Downloaded file not found after waiting.");
						        }

								Thread.sleep(4000);
								js.executeScript("arguments[0].click();",
										driver.findElement(By.xpath("//button[@title='Export:Close']")));
								System.out.println("Close the Popup");
								Thread.sleep(4000);
								((JavascriptExecutor) driver).executeScript("arguments[0].click();", sitemapBtn);

								System.out.println("Accounting Extracts is done");
								processStatus = "Accounting Extracts Pass";
								int column = getColumnIndexForUsername("FailDatesSheet", valueB, spreadsheetId);
								appendProcessRangeToColumn("FailDatesSheet", column, processStatus, spreadsheetId);
							} catch (Exception e) {
								// TODO: handle exception
								processStatus = "Accounting Extracts Fail";
								int column = getColumnIndexForUsername("FailDatesSheet", valueB, spreadsheetId);
								appendProcessRangeToColumn("FailDatesSheet", column, processStatus, spreadsheetId);
							}
						} else {
							System.out.println("Accounting Extracts not present, skipping...");
						}

						// ===============================================================================================

						// Receiving
						
						boolean Receiving = isElementPresent(By.xpath("(//a[text()='Receiving'])[1]"));
						;
						if (Receiving == true) {
							try {
								Thread.sleep(4000);
								System.out.println("Receiving process");
								driver.findElement(By.xpath("(//a[text()='Receiving'])[1]")).click();
								driver.findElement(By.xpath("//a[text()='Spares Purchase Line Items - Editable']")).click();
								driver.findElement(By.id("s_1_1_9_0_Ctrl")).click();
								Thread.sleep(4000);
								driver.findElement(By.id("1_s_1_l_Transaction_Date")).click();
								driver.findElement(By.id("1_Transaction_Date")).clear();
								driver.findElement(By.id("1_Transaction_Date")).sendKeys(dateRange);
								driver.findElement(By.id("1_Transaction_Date")).sendKeys(Keys.ENTER);

								Thread.sleep(8000);
								wait.until(ExpectedConditions
										.elementToBeClickable(By.xpath("//*[@title='Recv Line Items - Purchase Menu']")));

								Thread.sleep(20000);
								driver.findElement(By.xpath("//*[@title='Recv Line Items - Purchase Menu']")).click();

								Thread.sleep(4000);
								driver.findElement(By.xpath("//*[text()='Export...']")).click();

								Thread.sleep(4000);
								js.executeScript("arguments[0].click();",
										driver.findElement(By.xpath("//button[@data-display='Next']")));

								System.out.println("Wait the export done");
						        
								// Step 5: Wait for the file to download
						         downloadedFile = new File(downloadPath + "\\" + oldFileName);
						         waitTime = 0;
						        while (!downloadedFile.exists() && waitTime < 30) {
						            try {
						                Thread.sleep(1000); // wait 1 second
						                waitTime++;
						            } catch (InterruptedException e) {
						                e.printStackTrace();
						            }
						        }
						        
						        String ReceivingFile = valueB+"_Receiving.csv"; 

						        // Step 6: Rename the file
						        if (downloadedFile.exists()) {
						            File renamedFile = new File(downloadPath + "\\" + ReceivingFile);
						            if (downloadedFile.renameTo(renamedFile)) {
						                System.out.println("File renamed to: " + ReceivingFile);
						            } else {
						                System.out.println("Failed to rename the file.");
						            }
						        } else {
						            System.out.println("Downloaded file not found after waiting.");
						        }

								Thread.sleep(2000);

//									// Warning: waitForTextPresent may require manual changes
								driver.findElement(By.cssSelector("BODY")).getText()
										.matches("^[\\s\\S]*id=_sweExportProgress_Label_2[\\s\\S]*$");

								driver.findElement(By.xpath("//button[@title='Export:Close']")).click();
								System.out.println("Receiving is passed");
								processStatus = "Receiving Pass";
								int column = getColumnIndexForUsername("FailDatesSheet", valueB, spreadsheetId);
								appendProcessRangeToColumn("FailDatesSheet", column, processStatus, spreadsheetId);
							} catch (Exception e) {
								// TODO: handle exception
								processStatus = "Receiving Fail";
								int column = getColumnIndexForUsername("FailDatesSheet", valueB, spreadsheetId);
								appendProcessRangeToColumn("FailDatesSheet", column, processStatus, spreadsheetId);
							}
						} else {
							System.out.println("Receiving not present, skipping...");
						}

//					    =======================================================================================================

						// Payments
						
//						File downloadedFile;
//						int waitTime;
						try {
							Thread.sleep(4000);
							System.out.println("Payment process");
							driver.findElement(By.xpath("//a[text()='Home']")).click();
							Thread.sleep(4000);
							wait.until(ExpectedConditions.elementToBeClickable(By.id("j_s_sctrl_tabScreen")));
							driver.findElement(By.id("j_s_sctrl_tabScreen")).click();
							new Select(driver.findElement(By.id("j_s_sctrl_tabScreen"))).selectByVisibleText("Payments");

							Thread.sleep(4000);
							driver.findElement(By.id("s_1_1_10_0_Ctrl")).click();

							Thread.sleep(4000);
							driver.findElement(By.id("1_s_1_l__TMCV_Dealer_Receipt_Date")).click();
							driver.findElement(By.id("1__TMCV_Dealer_Receipt_Date")).clear();
							driver.findElement(By.id("1__TMCV_Dealer_Receipt_Date")).sendKeys(dateRange);
							driver.findElement(By.id("1__TMCV_Dealer_Receipt_Date")).sendKeys(Keys.ENTER);
							Thread.sleep(8000);
							wait.until(ExpectedConditions.elementToBeClickable(By.id("s_at_m_1")));
							driver.findElement(By.id("s_at_m_1")).click();
							System.out.println("Click payment");
							Thread.sleep(4000);
							driver.findElement(By.xpath("//*[text()='Export...']")).click();

							Thread.sleep(4000);
							js.executeScript("arguments[0].click();",
									driver.findElement(By.xpath("//button[@data-display='Next']")));

							System.out.println("Wait the export done");
							
							// Step 5: Wait for the file to download
					         downloadedFile = new File(downloadPath + "\\" + oldFileName);
					         waitTime = 0;
					        while (!downloadedFile.exists() && waitTime < 30) {
					            try {
					                Thread.sleep(1000); // wait 1 second
					                waitTime++;
					            } catch (InterruptedException e) {
					                e.printStackTrace();
					            }
					        }
					        
					        String PaymentsFile = valueB+"_Payments.csv"; 

					        // Step 6: Rename the file
					        if (downloadedFile.exists()) {
					            File renamedFile = new File(downloadPath + "\\" + PaymentsFile);
					            if (downloadedFile.renameTo(renamedFile)) {
					                System.out.println("File renamed to: " + PaymentsFile);
					            } else {
					                System.out.println("Failed to rename the file.");
					            }
					        } else {
					            System.out.println("Downloaded file not found after waiting.");
					        }

							Thread.sleep(2000);

//								// Warning: waitForTextPresent may require manual changes
							driver.findElement(By.cssSelector("BODY")).getText()
									.matches("^[\\s\\S]*id=_sweExportProgress_Label_2[\\s\\S]*$");

							driver.findElement(By.xpath("//button[@title='Export:Close']")).click();
							System.out.println("Payments is passed");
							processStatus = "Payments Pass";
							
							int column = getColumnIndexForUsername("FailDatesSheet", valueB, spreadsheetId);
							appendProcessRangeToColumn("FailDatesSheet", column, processStatus, spreadsheetId);
						} catch (Exception e) {
							// TODO: handle exception
							processStatus = "Payments Fail";
							int column = getColumnIndexForUsername("FailDatesSheet", valueB, spreadsheetId);
							appendProcessRangeToColumn("FailDatesSheet", column, processStatus, spreadsheetId);
						}

						// ==================================================================================================

						// Order
						
						try {
							Thread.sleep(4000);
							System.out.println("Order process");

							driver.findElement(By.xpath("//a[text()='Order']")).click();
							Thread.sleep(4000);
							driver.findElement(By.id("s_3_1_25_0_Ctrl")).click();
							Thread.sleep(4000);
							driver.findElement(By.id("1_s_3_l_Order_Date")).click();
							driver.findElement(By.id("1_Order_Date")).clear();
							driver.findElement(By.id("1_Order_Date")).sendKeys(dateRange);
							driver.findElement(By.id("1_Order_Date")).sendKeys(Keys.ENTER);
							Thread.sleep(8000);
							
							wait.until(ExpectedConditions.elementToBeClickable(By.id("s_at_m_3")));
							driver.findElement(By.id("s_at_m_3")).click();
							System.out.println("Click order");
							Thread.sleep(4000);
							driver.findElement(By.xpath("//*[text()='Export...']")).click();

							Thread.sleep(4000);
							js.executeScript("arguments[0].click();",
									driver.findElement(By.xpath("//button[@data-display='Next']")));

							System.out.println("Wait the export done");
							
							// Step 5: Wait for the file to download
					        downloadedFile = new File(downloadPath + "\\" + oldFileName);
					        waitTime = 0;
					        while (!downloadedFile.exists() && waitTime < 30) {
					            try {
					                Thread.sleep(1000); // wait 1 second
					                waitTime++;
					            } catch (InterruptedException e) {
					                e.printStackTrace();
					            }
					        }
					        
					        String OrderFile = valueB+"_Order.csv"; 

					        // Step 6: Rename the file
					        if (downloadedFile.exists()) {
					            File renamedFile = new File(downloadPath + "\\" + OrderFile);
					            if (downloadedFile.renameTo(renamedFile)) {
					                System.out.println("File renamed to: " + OrderFile);
					            } else {
					                System.out.println("Failed to rename the file.");
					            }
					        } else {
					            System.out.println("Downloaded file not found after waiting.");
					        }

							Thread.sleep(2000);

//								// Warning: waitForTextPresent may require manual changes
							driver.findElement(By.cssSelector("BODY")).getText()
									.matches("^[\\s\\S]*id=_sweExportProgress_Label_2[\\s\\S]*$");

							driver.findElement(By.xpath("//button[@title='Export:Close']")).click();
							System.out.println("Order is passed");
							processStatus = "Order Pass";
							int column = getColumnIndexForUsername("FailDatesSheet", valueB, spreadsheetId);
							appendProcessRangeToColumn("FailDatesSheet", column, processStatus, spreadsheetId);
						} catch (Exception e) {
							// TODO: handle exception
							processStatus = "Order Fail";
							int column = getColumnIndexForUsername("FailDatesSheet", valueB, spreadsheetId);
							appendProcessRangeToColumn("FailDatesSheet", column, processStatus, spreadsheetId);
						}
						
						//==================================================================================================
						
						//Sales return order
						
						if (AccountingExtracts == true) {
							try {
								Thread.sleep(4000);
								((JavascriptExecutor) driver).executeScript("arguments[0].click();", sitemapBtn);
								driver.findElement(By.xpath("(//a[text()='Accounting Extracts'])[1]")).click();
								System.out.println("Scenario 5 executed.");
								Thread.sleep(6000);
								
								waitForElementToBePresent(By.xpath("//*[text()='Sales Return Order Details']"), 10);
								driver.findElement(By.xpath("//*[text()='Sales Return Order Details']")).click();

								Thread.sleep(4000);
							    driver.findElement(By.id("s_smi_00110")).click();
							    
							    driver.findElement(By.id("1_s_1_l_TM_Invoice_Date")).click();
								waitForElementToBePresent(By.id("1_TM_Invoice_Date"), 10);
								driver.findElement(By.id("1_TM_Invoice_Date")).clear();
								driver.findElement(By.id("1_TM_Invoice_Date")).sendKeys(dateRange);
								driver.findElement(By.id("1_TM_Invoice_Date")).sendKeys(Keys.ENTER);

								Thread.sleep(8000);
								wait.until(ExpectedConditions
										.elementToBeClickable(By.xpath("//*[@title='Sales Return Order Details Menu']")));
								Thread.sleep(5000);
								driver.findElement(By.xpath("//*[@title='Sales Return Order Details Menu']")).click();
//				        		    driver.findElement(By.xpath("//div[10]")).click();
								driver.findElement(By.xpath("//*[text()='Export...']")).click();
								Thread.sleep(4000);
								js.executeScript("arguments[0].click();",
										driver.findElement(By.xpath("//button[@data-display='Next']")));
//								
								System.out.println("Wait the export done");

								Thread.sleep(2000);

//									// Warning: waitForTextPresent may require manual changes
								driver.findElement(By.cssSelector("BODY")).getText()
										.matches("^[\\s\\S]*id=_sweExportProgress_Label_2[\\s\\S]*$");
//								
								System.out.println("Export successfully done");
								
								// Step 5: Wait for the file to download
						         downloadedFile = new File(downloadPath + "\\" + oldFileName);
						         waitTime = 0;
						        while (!downloadedFile.exists() && waitTime < 30) {
						            try {
						                Thread.sleep(1000); // wait 1 second
						                waitTime++;
						            } catch (InterruptedException e) {
						                e.printStackTrace();
						            }
						        }
						        
						        String SalesReturnOrder = valueB+"_Sales_return_order.csv"; 

						        // Step 6: Rename the file
						        if (downloadedFile.exists()) {
						            File renamedFile = new File(downloadPath + "\\" + SalesReturnOrder);
						            if (downloadedFile.renameTo(renamedFile)) {
						                System.out.println("File renamed to: " + SalesReturnOrder);
						            } else {
						                System.out.println("Failed to rename the file.");
						            }
						        } else {
						            System.out.println("Downloaded file not found after waiting.");
						        }

								Thread.sleep(4000);
								js.executeScript("arguments[0].click();",
										driver.findElement(By.xpath("//button[@title='Export:Close']")));
								System.out.println("Close the Popup");
								Thread.sleep(4000);
								((JavascriptExecutor) driver).executeScript("arguments[0].click();", sitemapBtn);

								System.out.println("Accounting Extracts is done");
								processStatus = "Sales return order Pass";
								int column = getColumnIndexForUsername("FailDatesSheet", valueB, spreadsheetId);
								appendProcessRangeToColumn("FailDatesSheet", column, processStatus, spreadsheetId);
							} catch (Exception e) {
								// TODO: handle exception
								processStatus = "Sales return order Fail";
								int column = getColumnIndexForUsername("FailDatesSheet", valueB, spreadsheetId);
								appendProcessRangeToColumn("FailDatesSheet", column, processStatus, spreadsheetId);
							}
						}else {
							System.out.println("Sales return order not present, skipping...");
						}
						
						//==================================================================================================

						int column = getColumnIndexForUsername("FailDatesSheet", valueB, spreadsheetId);
						appendDateRangeToColumn("FailDatesSheet", column, dateRange, spreadsheetId);

						endDate = startDate.minusDays(1);
						dateRow++; // Move to next row for next date range
					} else {

						System.out.println("Test failed for: >= " + formattedStart + " and <= " + formattedEnd);

//							WriteDataOnSheetForTata.values("FailDatesSheet", "D", ">= " + formattedStart + " and <= " + formattedEnd);
//							writeDataGoogleSheets("FailDatesSheet", new ArrayList<>(Arrays.asList(">= " + formattedStart + " and <= " + formattedEnd)), existingSpreadSheetID,row1);
						// Move to next position

//						writeDateToColumnE("FailDatesSheet", dateRange, existingSpreadSheetID, dateRow);

						// Write failure status to column D
						writeStatusToColumnD("FailDatesSheet", "Fail", existingSpreadSheetID, credentialRow);
						// Write failed date range to column E
//						writeDateToColumnE("FailDatesSheet", dateRange, existingSpreadSheetID, dateRow);
//						writeDateRange("FailDatesSheet", dateRange, existingSpreadSheetID);

						// Handle failure - save the failed date and skip to next credential
						System.out.println("Test failed for credential " + valueB + ", date range: " + dateRange);

						// Save the failed date + 15 days to resume later
						LocalDate nextAttemptDate = endDate.plusDays(15);
						failedDatesMap.put(dateRange, nextAttemptDate);

						// Write failure to sheet
//		                writeTestResult(credential, "Fail", dateRange);
						break;

					}

					System.out.println(
							"✅ Test passed and file downloaded for " + formattedStart + " and <= " + formattedEnd);
					writeStatusToColumnD("FailDatesSheet", "Fail", existingSpreadSheetID, credentialRow);

					// Move to next 15-day range
					endDate = startDate.minusDays(1);
				} catch (Exception e) {

					System.out.println("❌ Exception for credential " + valueB + ", input " + dateRange);
//					String FailDate = ">= " + formattedStart + " and <= " + formattedEnd;
//					System.out.println(FailDate);
//					writeDateToColumnE("FailDatesSheet", dateRange, existingSpreadSheetID, dateRow);

					int column = getColumnIndexForUsername("FailDatesSheet", valueB, spreadsheetId);
					appendDateRangeToColumn("FailDatesSheet", column, dateRange, spreadsheetId);
					
					appendProcessRangeToColumn("FailDatesSheet", column, processStatus, spreadsheetId);
//			            writeDataGoogleSheets("FailDatesSheet", new ArrayList<>(Arrays.asList(">= " + formattedStart + " and <= " + formattedEnd)), existingSpreadSheetID,row1);
//			            writeDataGoogleSheets("FailDatesSheet", new ArrayList<>(Arrays.asList("Fail")), existingSpreadSheetID,row2);
					// Mark as passed in column D
					writeStatusToColumnD("FailDatesSheet", "Fail", existingSpreadSheetID, credentialRow);
//			            saveResumeState(i, resumeCredIndex);
//					driver.quit();

					try {
						// Step 3: Create message
						MimeMessage message = new MimeMessage(session);
						message.setFrom(new InternetAddress(fromEmail));
						message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
						message.setSubject("Automated Test Report For TATA CRM");
						message.setText(
								"Hi Sir,\n\nThis is an automated email from Webee. \n\nIn this credential "+valueB+" getting fail on current page. \nTATA CRM Test Report: 1uOoWQcXNq3LAXJHDH2Aub1y4jYw1cptzQumZg7VSPwU \n\nNote: Click the spreadsheet link, you can view the report");

						// Step 4: Send message
						Transport.send(message);
						System.out.println("✅ Email sent successfully.");

					} catch (MessagingException e1) {
						e1.printStackTrace();
					}
					break outer;
				}

			}
			driver.findElement(By.xpath("(//*[@title='Settings'])[1]")).click();
			driver.findElement(By.xpath("//button[text()='Logout']")).click();
			Thread.sleep(3000);
			// Mark as passed in column D
			writeStatusToColumnD("FailDatesSheet", "Pass", existingSpreadSheetID, credentialRow);
//				writeDataGoogleSheets("FailDatesSheet", new ArrayList<>(Arrays.asList("Pass")), existingSpreadSheetID,row2);
		}
		// If all credentials passed, delete the fail file
//			Files.deleteIfExists(Paths.get("C:\\Users\\Bilal Hussain\\Bilal Practice File\\last_failed.txt"));
//			writeDataGoogleSheets("FailDatesSheet", new ArrayList<>(Arrays.asList("")), existingSpreadSheetID,row3);
//			clearResumeState();
		System.out.println("✅ All credentials and inputs processed successfully.");
		System.out.println("Testcase successfully done");
		try {
			// Step 3: Create message
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(fromEmail));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
			message.setSubject("Automated Test Report For TATA CRM");
			message.setText(
					"Hi Sir,\n\nThis is an automated email from Webee. \n\nTATA CRM Test Report: 1uOoWQcXNq3LAXJHDH2Aub1y4jYw1cptzQumZg7VSPwU \n\nNote: Click the spreadsheet link, you can view the report");

			// Step 4: Send message
			Transport.send(message);
			System.out.println("✅ Email sent successfully.");

		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

//		}

	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	// Simulated test case logic
	public static boolean runTestForRange(String start, String end) {
		// Replace this with real Selenium logic
		// For demonstration, let's fail one condition
		return !start.equals("15/05/2025"); // Simulate a failure for this date
	}

	public static void saveLastSuccess(LocalDate date) {
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
			writer.write(date.format(formatter));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static LocalDate readLastFailedDate() {
		try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
			String line = reader.readLine();
			if (line != null && !line.isEmpty()) {
				return LocalDate.parse(line, formatter);
			}
		} catch (IOException ignored) {
		}
		return null;
	}

	// ===============================================================================

	String spreadsheetId = "1uOoWQcXNq3LAXJHDH2Aub1y4jYw1cptzQumZg7VSPwU";

//		  private final Sheets service;
//		    private final String spreadsheetId;
//
//		    this.service = service;
//	        this.spreadsheetId = spreadsheetId;

	public List<List<Object>> readCredentials() throws Exception {
		ValueRange response = service.spreadsheets().values().get(spreadsheetId, "Credentials!A2:B").execute();
		return response.getValues();
	}

	public int readLastIndex() throws Exception {
		ValueRange response = service.spreadsheets().values().get(spreadsheetId, "State!B1").execute();
		return Integer.parseInt(response.getValues().get(0).get(0).toString());
	}

	public String readLastDate() throws Exception {
		ValueRange response = service.spreadsheets().values().get(spreadsheetId, "State!B2").execute();
		return response.getValues().get(0).get(0).toString();
	}

	public void updateState(int index, String date) throws Exception {
		List<List<Object>> values = new ArrayList<>();
		values.add(List.of(index));
		values.add(List.of(date));
		ValueRange body = new ValueRange().setValues(values);
		service.spreadsheets().values().update(spreadsheetId, "State!B1:B2", body).setValueInputOption("RAW").execute();
	}

	// ===================================================================================================================

//		// Helper methods
//		private static LocalDate getResumeDate(int row) throws IOException {
//		    ValueRange response = sheetsService.spreadsheets().values()
//		        .get(SPREADSHEET_ID, "FailDatesSheet!F" + row)
//		        .execute();
//		    
//		    if (response.getValues() != null && !response.getValues().isEmpty()) {
//		        return LocalDate.parse((String)response.getValues().get(0).get(0), DATE_FORMATTER);
//		    }
//		    return null;
//		}

//		private static void updateCell(int row, String col, String value) throws IOException {
//		    ValueRange body = new ValueRange()
//		        .setValues(List.of(List.of(value)));
//		    
//		    Sheets sheetsService = null;
//			String SPREADSHEET_ID = null;
//			sheetsService.spreadsheets().values()
//		        .update(SPREADSHEET_ID, "FailDatesSheet!" + col + row, body)
//		        .setValueInputOption("USER_ENTERED")
//		        .execute();
//		}

	private static boolean executeTest(String dateRange) {
		try {
			// Your test implementation
			driver.findElement(By.id("dateField")).clear();
			driver.findElement(By.id("dateField")).sendKeys(dateRange);
			// ... rest of test steps
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}
