package BaseClassPackage;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import PageExecutionForTATAProject.SheetsQuickstart;

public class StepDefinationClass extends BaseClass{

	public StepDefinationClass(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	public static void treadWait(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void login() throws IOException, GeneralSecurityException {
		driver.findElement(By.xpath("//input[@id=\"email\"]")).sendKeys(SheetsQuickstart.getColumnRow(2, 1));
		driver.findElement(By.xpath("//input[@id=\"password\"]")).sendKeys(SheetsQuickstart.getColumnRow(3, 1));
		driver.findElement(By.xpath("//div[3]/button")).click();
		
		driver.findElement(By.xpath("//select[@name='question']")).click();
		driver.findElement(By.xpath("//*[@id=\"questionbankid\"]/option[text()='"+SheetsQuickstart.getColumnRow(16, 1)+"']")).click();
		driver.findElement(By.xpath("//button[contains(@class,'createQuestion_add_new')]")).click();

	}

	public static void createQueation() throws IOException, GeneralSecurityException {
		treadWait(4000);
		WebElement Qbank = driver.findElement(By.xpath("//div[1]/p[text()='"+SheetsQuickstart.getColumnRow(16, 1)+"']"));
		
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Qbank);
//		 Qbank = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[1]/p[text()='"+SheetsQuickstart.getColumnRow(16, 1)+"']")));
		treadWait(4000);
		Qbank.click();
		driver.findElement(By.xpath("//div/button[text()='Save & Continue']")).click();
		
		System.out.println("Navigate to the Basic Information page");
		
		driver.findElement(By.xpath("//label[text()='"+SheetsQuickstart.getColumnRow(17, 1)+"']")).click();
		driver.findElement(By.xpath("//*[@id=\"category\"]/option[text()='"+SheetsQuickstart.getColumnRow(18, 1)+"']")).click();
		treadWait(2000);
		driver.findElement(By.xpath("//*[@id=\"academic_year\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"academic_year\"]/option[text()='"+SheetsQuickstart.getColumnRow(19, 1)+"']")).click();
		driver.findElement(By.xpath("//div[text()='Primary Tags ']//following::input[@id='searchInput'][1]")).sendKeys(SheetsQuickstart.getColumnRow(12, 1));
		treadWait(4000);
		driver.findElement(By.xpath("//button[1]/span")).click();
		
		treadWait(4000);
		driver.findElement(By.xpath("//div[text()='Free Tags']//following::input[@id='searchInput'][1]")).sendKeys(SheetsQuickstart.getColumnRow(13, 1));
		treadWait(4000);
		driver.findElement(By.xpath("//button[1]/span[text()='"+SheetsQuickstart.getColumnRow(20, 1)+"']")).click();
		
		treadWait(4000);
		driver.findElement(By.xpath("//div[text()='Secondary Tags ']//following::input[@id='searchInput'][1]")).sendKeys(SheetsQuickstart.getColumnRow(12, 1));
		treadWait(4000);
		WebElement secondaryTag = driver.findElement(By.xpath("//button[1]/span"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", secondaryTag);
		treadWait(6000);
//		((BaseClass) driver).waitForElementToBePresent(secondaryTag, 10);
		secondaryTag.click();
		
		WebElement saveBtn = driver.findElement(By.xpath("//button[text()='Save & Continue']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", saveBtn);
		saveBtn.click();
		
		System.out.println("Navigate to the Question Creation page");
		
		treadWait(4000);
		driver.findElement(By.xpath("//button[text()='"+SheetsQuickstart.getColumnRow(21, 1)+"']")).click();
		driver.findElement(By.xpath("//button//preceding::p[text()='"+SheetsQuickstart.getColumnRow(22, 1)+"']")).click();
		treadWait(4000);
		
		WebElement saveBtn1 = driver.findElement(By.xpath("//button[text()='Save & Continue']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", saveBtn1);
		saveBtn1.click();
		
		driver.findElement(By.xpath("//textarea[@placeholder='Enter Question Short Identifier']")).sendKeys(SheetsQuickstart.getColumnRow(14, 1));
		treadWait(4000);
		WebElement iframe = driver.findElement(By.xpath("(//div[contains(@class,'createQuestion_ComposeQuestion')]//following::iframe)[1]"));
		driver.switchTo().frame(iframe); 
		WebElement ComQues  = driver.findElement(By.xpath("(//*[@id='tinymce'])[1]"));
		treadWait(4000);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ComQues);
		treadWait(4000);
		ComQues.sendKeys(SheetsQuickstart.getColumnRow(15, 1));
		driver.switchTo().defaultContent();
		
		WebElement ansFormat  = driver.findElement(By.xpath("//*[@id=\"answer-format\"]"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ansFormat);
		treadWait(4000);
		ansFormat.click();
		driver.findElement(By.xpath("//*[@id=\"answer-format\"]/option[text()='"+SheetsQuickstart.getColumnRow(23, 1)+"']")).click();
		
		 driver.findElement(By.xpath("//button[text()='Publish']"));
		treadWait(4000);
		WebElement publishBtn  = driver.findElement(By.xpath("//button[text()='Publish']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", publishBtn);
		publishBtn.click();
		
		System.out.println("Navigate to the Send For Review page");
		
		treadWait(4000);
		WebElement GoBackQlist  = driver.findElement(By.xpath("//button[text()='Go Back to Question Listing']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", GoBackQlist);
		GoBackQlist.click();
		
//		gettext("Your Question ID 137945 has been published successfully.");
		String text = "Your Question ID 137945 has been published successfully.";
        Pattern pattern = Pattern.compile("Question ID (\\d+)");
        Matcher matcher = pattern.matcher(text);

        String questionId = null;
        if (matcher.find()) {
             questionId = matcher.group(1);
            System.out.println("Extracted Question ID: " + questionId);
        } else {
            System.out.println("No ID found.");
        }
		
        driver.findElement(By.xpath("//select[@name='question']")).click();
		driver.findElement(By.xpath("//*[@id=\"questionbankid\"]/option[text()='Deployment Testing']")).click();
		

	}
	
	
	
}

