package StepDefinition;

import java.io.IOException;
import java.security.GeneralSecurityException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import BaseClassPackage.BaseClass;
import PageExecution.IMS_Flows;

public class SignInSteps extends BaseClass{


	@Test(priority = 1)
    public void testSuccessfulSignIn() throws GeneralSecurityException, IOException {
        // Create a SignInPage object
		IMS_Flows ims = new IMS_Flows(driver);

        // Perform sign-in with valid credentials
		ims.signIn(IMS_Flows.getValueFromKey("Username", 0, 1) , IMS_Flows.getValueFromKey("Password", 0, 1));

        // Add assertions to verify the login was successful (e.g., checking if the homepage is displayed)
        // This might vary depending on the application you're testing
        Assert.assertTrue(driver.getTitle().contains(IMS_Flows.getValueFromKey("Title", 0, 1)));
    }

	 
	
    @Test(priority = 2)
    public void testUnsuccessfulSignIn() throws GeneralSecurityException, IOException {
        // Create a SignInPage object
    	IMS_Flows ims = new IMS_Flows(driver);

        // Perform sign-in with invalid credentials
    	ims.signIn(IMS_Flows.getValueFromKey("InvaildUsername", 0, 1) , IMS_Flows.getValueFromKey("InvaildPassword", 0, 1));

//         Verify that the error message is displayed
        String errorMessage = ims.getErrorMessage();
        
        System.out.println(errorMessage);
        Assert.assertEquals(errorMessage, IMS_Flows.getValueFromKey("ErrorMessage", 0, 1));
    }
    
    @Test(priority = 3)
    public void testForgotPassword() throws GeneralSecurityException, IOException {
        // Create a SignInPage object
    	IMS_Flows ims = new IMS_Flows(driver);

        // Perform sign-in with invalid credentials
    	ims.forgotPassword(IMS_Flows.getValueFromKey("Username", 0, 1));
    	
    	//  Verify that the error message is displayed
          String PopupMessage = BaseClass.getPopupMessage();
          
          System.out.println(PopupMessage);
          Assert.assertEquals(PopupMessage, IMS_Flows.getValueFromKey("PasswordResetMessage", 0, 1));

    }
    
    @Test(priority = 4)
    public void testRememberMe() throws GeneralSecurityException, IOException {
        // Create a SignInPage object
    	IMS_Flows ims = new IMS_Flows(driver);

        // Perform sign-in with invalid credentials
    	ims.rememberMe(IMS_Flows.getValueFromKey("Username", 0, 1) , IMS_Flows.getValueFromKey("Password", 0, 1));
    }
    
}
