package PageFactory;

public class IMSLocator {
   
	
	//ims SignIn Locator
	public static String usernameField = "email";
	public static String passwordField = "password";
	public static String signInButton = "//button[contains(@class,'signin_bt_signup')]";
	public static String errorMessage = "//div[text()='The email and password that you entered are incorrect. Please try again!']";
	public static String rememberMeCheckBox = "//input[@id='rememberMe']";
	public static String forgotPassword = "//span[text()='Forgot Password?']";
	
	// Forgot Password Locator
	public static String sendLink = "//button[text()='Send Link']";
	public static String EmailSentMessage = "//div/div[text()='Password reset email sent.']";
	
	// Dashboard Locator
	public static String logOut = "//span[text()='Logout']";


}
