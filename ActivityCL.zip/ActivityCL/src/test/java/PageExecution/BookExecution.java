package PageExecution;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.sheets.v4.model.UpdateValuesResponse;
import com.google.api.services.sheets.v4.model.ValueRange;

import BaseClassPackage.BaseClass;
import PageFactory.StudentLocator;

public class BookExecution extends BaseClass{

	private static final String APPLICATION_NAME = "Google Sheets API";
	private static final JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();
	private static final String TOKENS_DIRECTORY_PATH = "tokens/path";

	private static final String existingSpreadSheetID ="13gfYl2OOdykh-oXCHtrygUDYETRCI2NXa7XPKT6hQoA";
	private static final List<String> SCOPES = Arrays.asList(SheetsScopes.SPREADSHEETS,SheetsScopes.DRIVE);
	private static final String CREDENTIALS_FILE_PATH = "/credentials.json";

	static Sheets.Spreadsheets spreadsheets;

	private static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
		InputStream in = SheetWriteExample.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
		if (in == null) {
			throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
		}
		GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

		GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
				HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, SCOPES)
				.setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
				.setAccessType("offline")
				.build();

		LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
		return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
	}
	public static void login() throws Exception {
		try {
			StudentLocator sl = new StudentLocator();
			BaseClass.browserSelect(BaseClass.readProperty("BrowserType"));
			BaseClass.loadUrl(BaseClass.readProperty("Url"));
			Thread.sleep(2000);
			BaseClass.getWebElementByXpath(sl.acceptCookies).click();
			BaseClass.getWebElementByXpath(sl.login).click();
			BaseClass.getWebElementByXpath(sl.userName).sendKeys(BaseClass.readProperty("Username"));
			BaseClass.getWebElementByXpath(sl.submit).click();
			BaseClass.getWebElementByXpath(sl.passWord).sendKeys(BaseClass.readProperty("Password"));
			BaseClass.getWebElementByXpath(sl.passWordsubmit).click();
			final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
			final String spreadsheetId = "13gfYl2OOdykh-oXCHtrygUDYETRCI2NXa7XPKT6hQoA";
			final String range = "Sample"+"!A:A"; // specify the cell to write to

			Sheets service = new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
					.setApplicationName(APPLICATION_NAME).build();
			ValueRange response = service.spreadsheets().values().get(spreadsheetId, range).execute();
			int totalCount = 0;
			List<List<Object>> values = response.getValues();
			if(values == null || values.isEmpty()) {
				System.out.println("No Data Found");
			}
			else {
				totalCount  = values.size();
				int totalRow = totalCount-1;
				System.out.println("Total Count: " + totalRow);
				for (List<Object> row : values) {
					if (!row.isEmpty()) {
					}
				}
			}
			for (int i = 1; i <totalCount; i++) {

				BaseClass.getWebElementByXpath(sl.searchTitle).sendKeys(SheetsQuickstart.getColumnRow(i,0));
				Thread.sleep(1500);
				try {
					if (BaseClass.getWebElementByXpath(sl.firstTitle).isDisplayed()) {
						System.out.println("Title Found : "+ i);
						BaseClass.getWebElementByXpath(sl.firstTitle).click();
						Thread.sleep(1500);
						try {
							BaseClass.getWebElementByXpath(sl.fortsätt).click();
						}
						catch(Exception e) {
							try {
								BaseClass.getWebElementByXpath(sl.Öppna).click();
							}
							catch(Exception e1) {
								try {
									BaseClass.getWebElementByXpath(sl.ÖppnaBok).click();
								}
								catch(Exception e2) {
									BaseClass.getWebElementByXpath(sl.kop).click();
									Thread.sleep(6000);
									BaseClass.getWebElementByXpath(sl.Öppna).click();
								}
							}
						}
						// Define the frame locator
						By frameLocator = By.id("readeriframe");

//						// Set up the explicit wait with a timeout of seconds
//						WebDriverWait wait = new WebDriverWait(driver, 50);

						try {
							// Wait until the frame is available and then switch to it
//							wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameLocator));

							System.out.println("Inside the Frame");

							// Define the locator for the book element
							By bookLocator = By.xpath(sl.book);

//							wait.until(ExpectedConditions.visibilityOfElementLocated(bookLocator));
							WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"C","Pass");
							try {
								if (BaseClass.getWebElementByXpath(sl.toggleOpen).isDisplayed()) {
									BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.toggleOpen));
									System.out.println("This is Linked Book");
									WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"B","Linked");
									epubSearch();
								}
							} 
							catch (Exception e) {
								System.out.println("Toggle Icon is not displayed");
								try {
									if (BaseClass.getWebElementByXpath(sl.thumbnailIcon).isDisplayed()) {
										BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.thumbnailIcon));
										WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"B","Fixed");
										searchFunc();
									}
								}catch (Exception e1) {
									System.out.println(e1.getMessage());
								}
							}

							// Switch back to the default content
							driver.switchTo().defaultContent();
						} catch (Exception e) {
							System.out.println("Frame not found or not available within the timeout");
						}
					}
				} catch (Exception e) {
					System.out.println("Title not Found" + i);try {
						BaseClass.getWebElementByXpath(sl.searchClear).click();
					}
					catch(Exception e1) {
						System.out.println("Search Clear NA");
					}
					Thread.sleep(200);
					WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"B","Book NA");
					WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"C","Book NA");
					WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Book NA");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void searchFunc() throws IOException, GeneralSecurityException, InterruptedException {
		try {
			StudentLocator sl = new StudentLocator();
			BaseClass.getWebElementByXpath(sl.searchIcon).click();
			Thread.sleep(300);
			BaseClass.getWebElementByXpath(sl.searchInput).sendKeys("book"+Keys.ENTER);
			//			enterKey();
			Thread.sleep(300);
			try {
				if(BaseClass.getWebElementByXpath(sl.searchList).isDisplayed()) {
					System.out.println("Search Pass");
					WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Pass");
				}
			}catch (Exception e) {
				BaseClass.getWebElementByXpath(sl.searchInput).clear();
				BaseClass.getWebElementByXpath(sl.searchInput).sendKeys("utt"+Keys.ENTER);
				//				enterKey();
				Thread.sleep(300);
				try {
					if(BaseClass.getWebElementByXpath(sl.searchList).isDisplayed()) {
						System.out.println("Search Pass");
						WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Pass");
					}
				}catch (Exception e1) {
					BaseClass.getWebElementByXpath(sl.searchInput).clear();
					BaseClass.getWebElementByXpath(sl.searchInput).sendKeys("inn"+Keys.ENTER);
					//					enterKey();
					Thread.sleep(300);
					try {
						if(BaseClass.getWebElementByXpath(sl.searchList).isDisplayed()) {
							System.out.println("Search Pass");
							WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Pass");
						}
					}catch (Exception e2) {
						System.out.println("Search Fail");
						WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Fail");
					}
				}
			}
			BaseClass.getWebElementByXpath(sl.searchClose).click();
		}catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Search Fail");
			WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Fail");
		}
	}
	public static void epubSearch() throws IOException, GeneralSecurityException, InterruptedException {
		try {
			StudentLocator sl = new StudentLocator();
			BaseClass.getWebElementByXpath(sl.searchIcon).click();
			Thread.sleep(300);
			BaseClass.getWebElementByXpath(sl.searchInput).sendKeys("book"+Keys.ENTER);
			//			enterKey();
			Thread.sleep(300);
			try {
				if(BaseClass.getWebElementByXpath(sl.searchList).isDisplayed()) {
					searchEpubFunc();
				}
			}catch (Exception e) {
				BaseClass.getWebElementByXpath(sl.searchInput).clear();
				BaseClass.getWebElementByXpath(sl.searchInput).sendKeys("utt"+Keys.ENTER);
				//				enterKey();
				Thread.sleep(300);
				try {
					if(BaseClass.getWebElementByXpath(sl.searchList).isDisplayed()) {
						searchEpubFunc();
					}
				}catch (Exception e1) {
					BaseClass.getWebElementByXpath(sl.searchInput).clear();
					BaseClass.getWebElementByXpath(sl.searchInput).sendKeys("inn"+Keys.ENTER);
					//					enterKey();
					Thread.sleep(300);
					try {
						if(BaseClass.getWebElementByXpath(sl.searchList).isDisplayed()) {
							searchEpubFunc();
						}
					}catch (Exception e2) {
						System.out.println("Search Fail");
						WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Fail");
					}
				}
			}
		}catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Search Fail");
			WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Fail");
		}
	}

	public static void searchEpubFunc() throws IOException, GeneralSecurityException, InterruptedException {
		try {
			StudentLocator sl = new StudentLocator();
			BaseClass.getWebElementByXpath(sl.searchClose).click();
			BaseClass.getWebElementByXpath(sl.toggleOpen).click();
			Thread.sleep(5500);
			driver.switchTo().frame("reflowableView");//linked-book
			BaseClass.getWebElementByXpath(sl.searchIcon).click();
			Thread.sleep(300);
			BaseClass.getWebElementByXpath(sl.searchInput).sendKeys("book"+Keys.ENTER);
			//			enterKey();
			Thread.sleep(300);
			try {
				if(BaseClass.getWebElementByXpath(sl.groupsearchlist).isDisplayed()) {
					System.out.println("Search Pass");
					WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Pass");
				}
			}catch (Exception e) {
				BaseClass.getWebElementByXpath(sl.searchInput).clear();
				BaseClass.getWebElementByXpath(sl.searchInput).sendKeys("utt"+Keys.ENTER);
				//				enterKey();
				Thread.sleep(300);
				try {
					if(BaseClass.getWebElementByXpath(sl.groupsearchlist).isDisplayed()) {
						System.out.println("Search Pass");
						WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Pass");
					}
				}catch (Exception e1) {
					BaseClass.getWebElementByXpath(sl.searchInput).clear();
					BaseClass.getWebElementByXpath(sl.searchInput).sendKeys("inn"+Keys.ENTER);
					//					enterKey();
					Thread.sleep(300);
					try {
						if(BaseClass.getWebElementByXpath(sl.groupsearchlist).isDisplayed()) {
							System.out.println("Search Pass");
							WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Pass");
						}
					}catch (Exception e2) {
						System.out.println("Search Fail");
						WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Fail");
					}
				}
			}
			BaseClass.getWebElementByXpath(sl.searchClose).click();
			driver.switchTo().parentFrame();

		}catch (Exception e) {
			System.out.println(e.getMessage());
			WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Fail");
		}
	}
	public static void highlightFunc() throws IOException, GeneralSecurityException, InterruptedException {
		try {
			StudentLocator sl = new StudentLocator();
			Thread.sleep(1000);
			String epub = BaseClass.getWebElementByXpath(sl.book).getAttribute("id");
			System.out.println(epub);
			// Use regular expression to extract the integer part
			String integerPart = epub.replaceAll("\\D+", "");  // \\D+ matches non-digit characters

			// Convert the extracted part to an integer
			int numberHighlight = Integer.parseInt(integerPart);

			System.out.println("Extracted integer: " + numberHighlight);
			BaseClass.getWebElementByXpath(sl.highlightIcon).click();
			Thread.sleep(500);
			driver.switchTo().frame("epub_" + numberHighlight);
			System.out.println("insode ");
			//			try {
			//				if(BaseClass.getWebElementByXpath("//span[@id=\"p" + numberHighlight + "-textid" + numberHighlight + "0001\"]").isDisplayed()) {
			Actions ac = new Actions(driver);
			ac.moveToElement(BaseClass.getWebElementByXpath("//span[@id=\"p1-textid10003\"]")).build().perform();
			ac.click().build().perform();
			driver.switchTo().parentFrame();
			System.out.println("outside frame");
			BaseClass.getWebElementByXpath(sl.orangeColor).click();
			WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"E","Pass");
			//				}
			//			}catch (Exception e) {
			//				BaseClass.getWebElementByXpath(sl.nextButton).click();
			//				int addFrame = numberHighlight+1;
			//				driver.switchTo().frame("epub_" + addFrame);
			//				Actions ac = new Actions(driver);
			//				ac.moveToElement(BaseClass.getWebElementByXpath("//span[@id=\"p" + addFrame + "-textid" + addFrame + "0001\"]")).build().perform();
			//				ac.click().build().perform();
			//				driver.switchTo().parentFrame();
			//				orange();
			//			}
		}catch (Exception e) {
			System.out.println("Highlight Fail");
			WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"E","Fail");
		}
	}
	public static void orange() throws IOException, GeneralSecurityException, InterruptedException {
		try {
			StudentLocator sl = new StudentLocator();
			if(BaseClass.getWebElementByXpath(sl.orangeColor).isDisplayed()) {
				System.out.println("Highlight Success Orange color");
				BaseClass.getWebElementByXpath(sl.orangeColor).click();
				WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"E","Pass");
			}
		}
		catch (Exception e) {
			System.out.println("Highlight Orange color NA Fail");
			WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"E","Fail");
		}
	}
	// 6.0 Online
	public static void login6() throws Exception {
		try {
			StudentLocator sl = new StudentLocator();
			BaseClass.browserSelect(BaseClass.readProperty("BrowserType"));
			BaseClass.loadUrl(BaseClass.readProperty("Url"));
			Thread.sleep(2000);
			BaseClass.getWebElementByXpath(sl.acceptCookies).click();
			BaseClass.getWebElementByXpath(sl.login).click();
			BaseClass.getWebElementByXpath(sl.userName).sendKeys(BaseClass.readProperty("Username1"));
			BaseClass.getWebElementByXpath(sl.submit).click();
			BaseClass.getWebElementByXpath(sl.passWord).sendKeys(BaseClass.readProperty("Password1"));
			BaseClass.getWebElementByXpath(sl.passWordsubmit).click();
			final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
			final String spreadsheetId = "1HqZqwuifaiBQa0rt1g8SLTJZ5QtQhmCNOCTXB1qoM-4";
			final String range = BaseClass.readProperty("SheetName")+"!A:A"; // specify the cell to write to

			Sheets service = new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
					.setApplicationName(APPLICATION_NAME).build();
			ValueRange response = service.spreadsheets().values().get(spreadsheetId, range).execute();
			int totalCount = 0;
			List<List<Object>> values = response.getValues();
			if(values == null || values.isEmpty()) {
				System.out.println("No Data Found");
			}
			else {
				totalCount  = values.size();
				int totalRow = totalCount-1;
				System.out.println("Total Count: " + totalRow);
				for (List<Object> row : values) {
					if (!row.isEmpty()) {
					}
				}
			}
			for (int i = 1; i <totalCount; i++) {

				BaseClass.getWebElementByXpath(sl.searchTitle).sendKeys(SheetsQuickstart.getColumnRow(i,0));
				Thread.sleep(1500);
				try {
					if (BaseClass.getWebElementByXpath(sl.firstTitle).isDisplayed()) {
						System.out.println("Title Found : "+ i);
						BaseClass.getWebElementByXpath(sl.firstTitle).click();
						Thread.sleep(1500);
						try {
							BaseClass.getWebElementByXpath(sl.fortsätt).click();
						}
						catch(Exception e) {
							try {
								BaseClass.getWebElementByXpath(sl.Öppna).click();
							}
							catch(Exception e1) {
								try {
									BaseClass.getWebElementByXpath(sl.ÖppnaBok).click();
								}
								catch(Exception e2) {
									BaseClass.getWebElementByXpath(sl.kop).click();
									Thread.sleep(6000);
									BaseClass.getWebElementByXpath(sl.Öppna).click();
								}
							}
						}
						// Define the frame locator
						By frameLocator = By.id("readeriframe");

//						// Set up the explicit wait with a timeout of seconds
//						WebDriverWait wait = new WebDriverWait(driver, 50);

						try {
							// Wait until the frame is available and then switch to it
//							wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameLocator));

							System.out.println("Inside the Frame");

							// Define the locator for the book element
							By tocLocator = By.xpath(sl.tocIcon6);

//							wait.until(ExpectedConditions.elementToBeClickable(tocLocator));

							BaseClass.getWebElementByXpath(sl.tocIcon6).click();
							Thread.sleep(500);
							BaseClass.getWebElementByXpath(sl.firstTocList6).click();
							// Define the locator for the book element
							By bookLocator = By.xpath(sl.book);

//							wait.until(ExpectedConditions.visibilityOfElementLocated(bookLocator));
							WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"C","Pass");
							try {
								if (BaseClass.getWebElementByXpath(sl.toggleOpen6).isDisplayed()) {
									BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.toggleOpen6));
									System.out.println("This is Linked Book");
									WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"B","Linked");
									highlightFunc();
									epubSearch6();
								}
							} 
							catch (Exception e) {
								System.out.println("Toggle Icon is not displayed");
								try {
									if (BaseClass.getWebElementByXpath(sl.thumbIcon6).isDisplayed()) {
										BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.thumbIcon6));
										WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"B","Fixed");
										highlightFunc();
										searchFunc6();
									}
								}catch (Exception e1) {
									System.out.println(e1.getMessage());
								}
							}

							// Switch back to the default content
							driver.switchTo().defaultContent();
						} catch (Exception e) {
							System.out.println("Frame not found or not available within the timeout");
							System.out.println(e.getMessage());
						}
					}
				} catch (Exception e) {
					System.out.println("Title not Found" + i);
					try {
						BaseClass.getWebElementByXpath(sl.searchClear).click();
					}
					catch(Exception e1) {
						System.out.println("Search Clear NA");
					}
					Thread.sleep(200);
					WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"B","Book NA");
					WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"C","Book NA");
					WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Book NA");
					WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"E","Book NA");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void searchFunc6() throws IOException, GeneralSecurityException, InterruptedException {
		try {
			StudentLocator sl = new StudentLocator();
			Thread.sleep(1000);
			BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.searchIcon6));
			//			BaseClass.getWebElementByXpath(sl.searchIcon6).click();
			Thread.sleep(300);
			BaseClass.getWebElementByXpath(sl.searchInput6).sendKeys("book"+Keys.ENTER);
			//			enterKey();
			Thread.sleep(300);
			try {
				if(BaseClass.getWebElementByXpath(sl.searchList6).isDisplayed()) {
					System.out.println("Search Pass");
					WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Pass");
				}
			}catch (Exception e) {
				BaseClass.getWebElementByXpath(sl.searchInput6).clear();
				BaseClass.getWebElementByXpath(sl.searchInput6).sendKeys("utt"+Keys.ENTER);
				//				enterKey();
				Thread.sleep(300);
				try {
					if(BaseClass.getWebElementByXpath(sl.searchList6).isDisplayed()) {
						System.out.println("Search Pass");
						WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Pass");
					}
				}catch (Exception e1) {
					BaseClass.getWebElementByXpath(sl.searchInput6).clear();
					BaseClass.getWebElementByXpath(sl.searchInput6).sendKeys("inn"+Keys.ENTER);
					//					enterKey();
					Thread.sleep(300);
					try {
						if(BaseClass.getWebElementByXpath(sl.searchList6).isDisplayed()) {
							System.out.println("Search Pass");
							WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Pass");
						}
					}catch (Exception e2) {
						System.out.println("Search Fail");
						WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Fail");
					}
				}
			}
			BaseClass.getWebElementByXpath(sl.searchClose6).click();
		}catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Search Fail");
			WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Fail");
		}
	}
	public static void epubSearch6() throws IOException, GeneralSecurityException, InterruptedException {
		try {
			StudentLocator sl = new StudentLocator();
			Thread.sleep(1000);
			BaseClass.getWebElementByXpath(sl.searchIcon6).click();
			Thread.sleep(300);
			BaseClass.getWebElementByXpath(sl.searchInput6).sendKeys("book"+Keys.ENTER);
			//			enterKey();
			Thread.sleep(300);
			try {
				if(BaseClass.getWebElementByXpath(sl.searchList6).isDisplayed()) {
					searchEpubFunc6();
				}
			}catch (Exception e) {
				BaseClass.getWebElementByXpath(sl.searchInput6).clear();
				BaseClass.getWebElementByXpath(sl.searchInput6).sendKeys("utt"+Keys.ENTER);
				//				enterKey();
				Thread.sleep(300);
				try {
					if(BaseClass.getWebElementByXpath(sl.searchList6).isDisplayed()) {
						searchEpubFunc6();
					}
				}catch (Exception e1) {
					BaseClass.getWebElementByXpath(sl.searchInput6).clear();
					BaseClass.getWebElementByXpath(sl.searchInput6).sendKeys("inn"+Keys.ENTER);
					//					enterKey();
					Thread.sleep(300);
					try {
						if(BaseClass.getWebElementByXpath(sl.searchList6).isDisplayed()) {
							searchEpubFunc6();
						}
					}catch (Exception e2) {
						System.out.println("Search Fail");
						WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Fail");
					}
				}
			}
		}catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Search Fail");
			WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Fail");
		}
	}

	public static void searchEpubFunc6() throws IOException, GeneralSecurityException, InterruptedException {
		try {
			StudentLocator sl = new StudentLocator();
			BaseClass.getWebElementByXpath(sl.searchClose6).click();
			BaseClass.getWebElementByXpath(sl.toggleOpen6).click();
			Thread.sleep(3500);
			driver.switchTo().frame("linked-book");//linked-book
			BaseClass.getWebElementByXpath(sl.searchIcon6).click();
			Thread.sleep(300);
			BaseClass.getWebElementByXpath(sl.searchInput6).sendKeys("book");
			enterKey();
			Thread.sleep(300);
			try {
				if(BaseClass.getWebElementByXpath(sl.groupsearchlist6).isDisplayed()) {
					System.out.println("Search Pass");
					WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Pass");
				}
			}catch (Exception e) {
				BaseClass.getWebElementByXpath(sl.searchInput6).clear();
				BaseClass.getWebElementByXpath(sl.searchInput6).sendKeys("utt");
				enterKey();
				Thread.sleep(300);
				try {
					if(BaseClass.getWebElementByXpath(sl.groupsearchlist6).isDisplayed()) {
						System.out.println("Search Pass");
						WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Pass");
					}
				}catch (Exception e1) {
					BaseClass.getWebElementByXpath(sl.searchInput6).clear();
					BaseClass.getWebElementByXpath(sl.searchInput6).sendKeys("inn");
					enterKey();
					Thread.sleep(300);
					try {
						if(BaseClass.getWebElementByXpath(sl.groupsearchlist6).isDisplayed()) {
							System.out.println("Search Pass");
							WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Pass");
						}
					}catch (Exception e2) {
						System.out.println("Search Fail");
						WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Fail");
					}
				}
			}
			BaseClass.getWebElementByXpath(sl.searchClose6).click();
			driver.switchTo().parentFrame();

		}catch (Exception e) {
			System.out.println(e.getMessage());
			WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"D","Fail");
		}
	}
	public static void enterKey() throws AWTException {
		Robot ro = new Robot();
		ro.keyPress(KeyEvent.VK_ENTER);
		ro.keyRelease(KeyEvent.VK_ENTER);
	}

	public static void main(String[] args) throws Exception {
		if(BaseClass.readProperty("SheetName").equals("5.0")) {
			System.out.println("5.0 Application Running !!!");
			BookExecution.login();
		}else if (BaseClass.readProperty("SheetName").equals("6.0")) {
			System.out.println("6.0 Application Running !!!");
			BookExecution.login6();
		}

	}

}
