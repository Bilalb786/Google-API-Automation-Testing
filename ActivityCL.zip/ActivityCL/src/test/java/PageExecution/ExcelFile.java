package PageExecution;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class ExcelFile {
    public static Workbook ExcelWBook;
    public static Sheet ExcelWSheet;

    // Method to initialize the Excel file and sheet
    public static void setExcelFile(String filePath, String sheetName) throws IOException {
        FileInputStream file = new FileInputStream(new File(filePath));

        // Load the workbook from the file
        ExcelWBook = WorkbookFactory.create(file);

        // Load the specific sheet from the workbook
        ExcelWSheet = ExcelWBook.getSheet(sheetName);

        if (ExcelWSheet == null) {
            throw new NullPointerException("Sheet with name '" + sheetName + "' not found in the file.");
        }

        file.close();
    }

    public static void main(String[] args) {
        try {
            // Initialize the file and sheet
            setExcelFile("C:\\Users\\Mohammed Abubacker s\\eclipse-workspace\\ActivityCL\\TestData\\userConfig.xlsx", "Android");

            // Access a row (e.g., row 0)
            if (ExcelWSheet != null) {
                System.out.println("Row 0: " + ExcelWSheet.getRow(0));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

