package PageExecution;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;
import java.time.Duration;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.sheets.v4.model.ValueRange;

import BaseClassPackage.BaseClass;
import BaseClassPackage.ExcelFile;
import PageFactory.StudentLocator;

public class CLExecution extends BaseClass{

	private static final String APPLICATION_NAME = "Google Sheets API";
	private static final JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();
	private static final String TOKENS_DIRECTORY_PATH = "tokens/path";

	private static final String existingSpreadSheetID ="1Ndb4y1AHxb51_ACx_UdyoXUwbAurs9h6lzQTuF7Anc0";
	private static final List<String> SCOPES = Arrays.asList(SheetsScopes.SPREADSHEETS,SheetsScopes.DRIVE);
	private static final String CREDENTIALS_FILE_PATH = "/credentials.json";

	static Sheets.Spreadsheets spreadsheets;

	private static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
		InputStream in = SheetWriteExample.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
		if (in == null) {
			throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
		}
		GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

		GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
				HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, SCOPES)
				.setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
				.setAccessType("offline")
				.build();

		LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
		return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
	}

	public static void closeAlert() throws AWTException {
		Robot ro = new Robot();
		ro.keyPress(KeyEvent.VK_TAB);
		ro.keyRelease(KeyEvent.VK_TAB);
		ro.keyPress(KeyEvent.VK_TAB);
		ro.keyRelease(KeyEvent.VK_TAB);
		ro.keyPress(KeyEvent.VK_ENTER);
		ro.keyRelease(KeyEvent.VK_ENTER);
	}
	public static void tab() throws AWTException {
		Robot ro = new Robot();
		ro.keyPress(KeyEvent.VK_TAB);
		ro.keyRelease(KeyEvent.VK_TAB);
	}  // Method to write a single string value to Excel in a specific row and column C
	public static void writeSingleValueToExcel(int rowNumber, String value) {
		try {String excelPath = "/TestData/userConfig.xlsx";
		String filePath = System.getProperty("user.dir") +excelPath;
		// Load the Excel file
		FileInputStream file = new FileInputStream(new File(filePath));
		Workbook workbook = WorkbookFactory.create(file);
		Sheet sheet = workbook.getSheet("Round5");

		if (sheet == null) {
			System.out.println("Sheet not found");
			file.close();
			return;
		}

		// Access the specified row, or create it if it doesn't exist
		Row row = sheet.getRow(rowNumber);
		if (row == null) {
			row = sheet.createRow(rowNumber); // Create row if it doesn't exist
		}

		// Access column C (index 2) and write the value, or create the cell if it doesn't exist
		Cell cell = row.getCell(2); // Column C (index 2)
		if (cell == null) {
			cell = row.createCell(2); // Create cell if it doesn't exist
		}

		// Write the value into column C
		cell.setCellValue(value);

		// Close the input stream
		file.close();

		// Write the changes back to the Excel file
		FileOutputStream outFile = new FileOutputStream(new File(filePath));
		workbook.write(outFile);

		// Close the output stream and workbook
		outFile.close();
		workbook.close();

		System.out.println("Data written successfully to Excel!");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void execution() {
		StudentLocator sl = new StudentLocator();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));  // 5 seconds timeout
		try {
			ExcelFile.setExcelFile(System.getProperty("user.dir") + "/TestData/userConfig.xlsx", "Round5");
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			BaseClass.browserSelect(BaseClass.readProperty("BrowserType"));
			BaseClass.loadUrl(BaseClass.readProperty("Url"));
			Thread.sleep(2000);
			closeAlert();
			wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.userName)));
			BaseClass.getWebElementByXpath(sl.userName).sendKeys(BaseClass.readProperty("Username"));
			BaseClass.getWebElementByXpath(sl.passWord).sendKeys(BaseClass.readProperty("Password"));
			BaseClass.getWebElementByXpath(sl.submit).click();
			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(20));
			wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.firstValue)));
			for (int i = 44; i <678; i++) {
				try {
					Thread.sleep(1000);
					BaseClass.getWebElementByXpath(sl.search).sendKeys(ExcelFile.getCellData(i, 1)+Keys.ENTER);
					Thread.sleep(1000);
					WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(20));
					wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.firstValueText)));
					BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.firstValueText));
					Thread.sleep(1000);
					wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.firstValueInfo)));
					BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.firstValueInfo));
					BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.firstValueInfo));
					Thread.sleep(1000);
					wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.infoDetails)));
					BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.infoDetails));
					BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.infoDetails));
					Thread.sleep(1000);
					wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.bannerTitle)));
					String banner =  BaseClass.getWebElementByXpath(sl.bannerTitle).getText();
					System.out.println(banner);
					String banner1 = " "+banner;
					System.out.println(banner1);
					String result = banner.split("__")[0];
					String finalText = result.trim();
					System.out.println(finalText);
					String finalText1 = " "+finalText;
					System.out.println(finalText1);
					wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.bannerTitleClose)));
					BaseClass.getWebElementByXpath(sl.bannerTitleClose).click();
					Thread.sleep(1000);
					wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.activity)));
					BaseClass.getWebElementByXpath(sl.activity).click();
					Thread.sleep(1000);
					WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(20));
					wait3.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.firstValue)));
					Thread.sleep(2000);
					BaseClass.getWebElementByXpath(sl.search).sendKeys(banner+Keys.ENTER);
					Thread.sleep(1000);
					try {
						try {
							wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='"+banner+"' or text()='"+banner1+"']")));
							BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath("//span[text()='"+banner+"' or text()='"+banner1+"']"));
							Thread.sleep(2000);
							wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='"+banner+"' or text()='"+banner1+"']//following::td[7]/button")));
							BaseClass.executeScripClick(BaseClass.getWebElementByXpath("//span[text()='"+banner+"' or text()='"+banner1+"']//following::td[7]/button"));

							Thread.sleep(3000);
							BaseClass.lastWindow();
							Thread.sleep(2000);
							driver.manage().window().maximize();
						}
						catch(Exception e) {
							System.out.println(e.getMessage());
							BaseClass.getWebElementByXpath(sl.search).clear();
							Thread.sleep(1000);
							BaseClass.getWebElementByXpath(sl.search).sendKeys(finalText+Keys.ENTER);
							Thread.sleep(2000);
							wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='"+finalText+"' or text()='"+finalText1+"']")));
							BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath("//span[text()='"+finalText+"' or text()='"+finalText1+"']"));
							Thread.sleep(2000);
							wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='"+finalText+"' or text()='"+finalText1+"']//following::td[7]/button")));
							BaseClass.executeScripClick(BaseClass.getWebElementByXpath("//span[text()='"+finalText+"' or text()='"+finalText1+"']//following::td[7]/button"));
							Thread.sleep(3000);
							BaseClass.lastWindow();
							Thread.sleep(2000);
							driver.manage().window().maximize();
						}
//						try {
//							wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.student)));
//							BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.student));


							Thread.sleep(2000);

//							wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.teacher)));
//							BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.teacher));
//							Thread.sleep(4000);

							wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.step1)));
							BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.step1));
							String stepTitle = BaseClass.getWebElementByXpath(sl.stepText).getText();
							System.out.println("stepTitle :"+stepTitle);
							if (stepTitle.contains("Video")) {
								writeSingleValueToExcel(i,"Video Content"+ExcelFile.getCellData(i, 1));
							}
							else {
								writeSingleValueToExcel(i,"No Video Content"+ExcelFile.getCellData(i, 1));
							}
							Thread.sleep(2000);
							BaseClass.closeWindow();
							Thread.sleep(3000);
							BaseClass.lastWindow();
							Thread.sleep(3000);
							wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.text)));
							BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.text));
							
							
							
							
//							BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.step1));
//							Thread.sleep(11000);
//							//						for(int j=1;j<5;j++) {
//							Thread.sleep(2000);
//							try {
//								BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.video));
//							}catch(Exception e) {
//								System.out.println("No Video ");
//							}
//							tab();
//							Thread.sleep(2000);
//							tab();
//							Thread.sleep(2000);
//							BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.save));
//							BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.save));
//
//							wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.saveMsg)));
//							BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.saveMsg));
//							if (stepTitle.contains("Group Activity")) {
//								// True condition
//								System.out.println("Contains Group Activity");
//								List<WebElement> count= driver.findElements(By.xpath(sl.groupActivity));
//								int groupCount = count.size();
//								System.out.println("groupCount :"+groupCount);
//								Thread.sleep(2000);
//								BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.groupActivity1));
//								Thread.sleep(2000);
//								BaseClass.executeScripClick(BaseClass.getWebElementByXpath("(//div[@class=\"save-html column-content editables ng-pristine ng-untouched ng-valid\"])["+groupCount+"]"));
//								BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath("(//div[@class=\"save-html column-content editables ng-pristine ng-untouched ng-valid\"])["+groupCount+"]"));
//								Thread.sleep(1000);
//								BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.vertical));
//								Thread.sleep(1000);
//								wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.save)));
//								BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.save));
//								BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.save));
//
//								wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.saveMsg)));
//								BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.saveMsg));
//							} else {
//								// False condition
//								System.out.println("Does not contain Group Activity");
//							}
//							//							break;
//
//							//						}
//							Thread.sleep(2000);
//							wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.preview)));
//							BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.preview));
//							BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.preview));
//							Thread.sleep(5000);
//							wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.edit)));
//							BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.edit));
//							BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.edit));
//							Thread.sleep(3000);
//							wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.preview)));
//							BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.preview));
//							BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.preview));
//							Thread.sleep(3000);
//							try {
//								// Switch to the iframe by name
//								driver.switchTo().frame("previewIFrame");
//								Thread.sleep(4000);
//								BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.previewLoad));
//								driver.switchTo().defaultContent();
//							}
//							catch(Exception e) {
//								driver.switchTo().defaultContent();
//								System.out.println("No Preview");
//							}
//							Thread.sleep(3000);
//							wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.edit)));
//							BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.edit));
//							Thread.sleep(3000);
//							BaseClass.closeWindow();
//							Thread.sleep(3000);
//							BaseClass.lastWindow();
//							Thread.sleep(3000);
//
//							Thread.sleep(2000);
//							wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.search)));
//							BaseClass.getWebElementByXpath(sl.search).clear();
//							BaseClass.getWebElementByXpath(sl.search).sendKeys(banner+Keys.ENTER);
//							Thread.sleep(1000);
//							try {
//								wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='"+banner+"' or text()='"+banner1+"']")));
//								BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath("//span[text()='"+banner+"' or text()='"+banner1+"']"));
//								Thread.sleep(500);
//								wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='"+banner+"' or text()='"+banner1+"']//following::td[8]/button")));
//								BaseClass.executeScripClick(BaseClass.getWebElementByXpath("//span[text()='"+banner+"' or text()='"+banner1+"']//following::td[8]/button"));
//							}
//							catch(Exception e2) {
//
//								wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='"+finalText+"' or text()='"+finalText1+"']")));
//								BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(("//span[text()='"+finalText+"' or text()='"+finalText1+"']")));
//								Thread.sleep(1000);
//								wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='"+finalText+"' or text()='"+finalText1+"']//following::td[8]/button")));
//								BaseClass.executeScripClick(BaseClass.getWebElementByXpath("//span[text()='"+finalText+"' or text()='"+finalText1+"']//following::td[8]/button"));
//							}
//							Thread.sleep(1000);
//							wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.text)));
//							BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.text));
//							Thread.sleep(1000);
//							wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.html)));
//							BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.html));
//							Thread.sleep(1000);
//							wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.scorm)));
//							BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.scorm));
//							Thread.sleep(1000);
//							wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.publish)));
//							BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.publish));
//
//							WebDriverWait wait5 = new WebDriverWait(driver, Duration.ofSeconds(70));
//							wait5.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.publishConfirmation)));
//							BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.publishConfirmation));
//
//							writeSingleValueToExcel(i,"Success"+ExcelFile.getCellData(i, 1));
//
//							// WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"H","Success");
//						}
//						catch(Exception e) {
//							System.out.println("save not available"+i);
//							Thread.sleep(3000);
//							BaseClass.lastWindow();
//							Thread.sleep(5000);
//							BaseClass.closeWindow();
//							Thread.sleep(3000);
//							BaseClass.lastWindow();
//							Thread.sleep(3000);
//							writeSingleValueToExcel(i,"Check Manually"+ExcelFile.getCellData(i, 1));
//							// WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"H","Check Manually");
//							Thread.sleep(500);
//							wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.text)));
//							BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.text));
//						}
					}
					catch(Exception e) {
						System.out.println(e.getMessage());
						writeSingleValueToExcel(i,"Check Manually"+ExcelFile.getCellData(i, 1));
						// WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"H","Check Manually");
						Thread.sleep(500);
						wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.text)));
						BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.text));
					}
				}
				catch(Exception e) {
					System.out.println(e.getMessage());
					writeSingleValueToExcel(i,"Check Manually"+ExcelFile.getCellData(i, 1));
					// WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"H","Check Manually");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void login() throws Exception {
		StudentLocator sl = new StudentLocator();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));  // 5 seconds timeout

		try {
			BaseClass.browserSelect(BaseClass.readProperty("BrowserType"));
			BaseClass.loadUrl(BaseClass.readProperty("Url"));
			Thread.sleep(2000);
			closeAlert();
			wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.userName)));
			BaseClass.getWebElementByXpath(sl.userName).sendKeys(BaseClass.readProperty("Username"));
			BaseClass.getWebElementByXpath(sl.passWord).sendKeys(BaseClass.readProperty("Password"));
			BaseClass.getWebElementByXpath(sl.submit).click();
			final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
			final String spreadsheetId = "1Ndb4y1AHxb51_ACx_UdyoXUwbAurs9h6lzQTuF7Anc0";
			final String range = BaseClass.readProperty("SheetName")+"!B:B"; // specify the cell to write to

			Sheets service = new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
					.setApplicationName(APPLICATION_NAME).build();
			ValueRange response = service.spreadsheets().values().get(spreadsheetId, range).execute();
			int totalCount = 0;
			List<List<Object>> values = response.getValues();
			if(values == null || values.isEmpty()) {
				System.out.println("No Data Found");
			}
			else {
				totalCount  = values.size();
				int totalRow = totalCount-1;
				System.out.println("Total Count: " + totalRow);
				for (List<Object> row : values) {
					if (!row.isEmpty()) {
					}
				}
			}
			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(20));
			wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.firstValue)));
			String  value = BaseClass.readProperty("RowNo");
			int row = Integer.parseInt(value);  // Convert the String to an int
			//Ref ID Passing From the Google Sheet
			for (int i = row; i <70; i++) {
				// Wait for the firstChapDel element to be visible, with an extended timeout

				// wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.firstValue)));
				try {
					Thread.sleep(1000);
					BaseClass.getWebElementByXpath(sl.search).sendKeys(SheetsQuickstart.getColumnRow(i,1)+Keys.ENTER);
					Thread.sleep(500);
					WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(20));
					wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.firstValueText)));
					BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.firstValueText));

					wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.firstValueInfo)));
					BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.firstValueInfo));
					BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.firstValueInfo));

					wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.infoDetails)));
					BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.infoDetails));
					BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.infoDetails));

					wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.bannerTitle)));
					String banner =  BaseClass.getWebElementByXpath(sl.bannerTitle).getText();
					String result = banner.split("__")[0];
					String finalText = result.trim();
					System.out.println(finalText);
					wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.bannerTitleClose)));
					BaseClass.getWebElementByXpath(sl.bannerTitleClose).click();
					Thread.sleep(500);
					wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.activity)));
					BaseClass.getWebElementByXpath(sl.activity).click();
					WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(20));
					wait3.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.firstValue)));
					Thread.sleep(1000);
					BaseClass.getWebElementByXpath(sl.search).sendKeys(finalText+Keys.ENTER);
					Thread.sleep(500);
					try {
						wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='"+finalText+"']")));
						BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath("//span[text()='"+finalText+"']"));

						Thread.sleep(500);
						wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='"+finalText+"']//following::td[7]/button")));
						BaseClass.executeScripClick(BaseClass.getWebElementByXpath("//span[text()='"+finalText+"']//following::td[7]/button"));

						Thread.sleep(3000);
						BaseClass.lastWindow();
						driver.manage().window().maximize();

						Thread.sleep(3000);
						wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.student)));
						BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.student));
						Thread.sleep(2000);
						wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.teacher)));
						BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.teacher));
						Thread.sleep(3000);

						wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.step1)));
						BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.step1));
						String stepTitle = BaseClass.getWebElementByXpath(sl.stepText).getText();
						System.out.println("stepTitle :"+stepTitle);
						BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.step1));
						Thread.sleep(11000);
						for(int j=1;j<5;j++) {
							Thread.sleep(1000);
							tab();
							Thread.sleep(4000);
							try {
								BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.save));
								BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.save));

								wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.saveMsg)));
								BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.saveMsg));
								if (stepTitle.contains("Group Activity")) {
									// True condition
									System.out.println("Contains Group Activity");
									List<WebElement> count= driver.findElements(By.xpath(sl.groupActivity));
									int groupCount = count.size();
									System.out.println("groupCount :"+groupCount);
									Thread.sleep(2000);
									BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.groupActivity1));
									Thread.sleep(2000);
									BaseClass.executeScripClick(BaseClass.getWebElementByXpath("(//div[@class=\"save-html column-content editables ng-pristine ng-untouched ng-valid\"])["+groupCount+"]"));
									BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath("(//div[@class=\"save-html column-content editables ng-pristine ng-untouched ng-valid\"])["+groupCount+"]"));
									Thread.sleep(1000);
									BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.vertical));
									Thread.sleep(1000);
									wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.save)));
									BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.save));
									BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.save));

									wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.saveMsg)));
									BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.saveMsg));
								} else {
									// False condition
									System.out.println("Does not contain Group Activity");
								}
								break;
							}
							catch(Exception e) {
								System.out.println("Tab No" +j);
							}
						}
						// wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.enterQuestion)));
						// Thread.sleep(1000);
						// tab();
						// Thread.sleep(1500);
						// wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.save)));
						// BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.save));
						// BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.save));
						//
						// wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.saveMsg)));
						// BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.saveMsg));
						// List<WebElement> count= driver.findElements(By.xpath(sl.groupActivity));
						// int groupCount = count.size();
						// System.out.println("groupCount :"+groupCount);
						// Thread.sleep(2000);
						// BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.groupActivity1));
						// Thread.sleep(2000);
						//
						// BaseClass.executeScripClick(BaseClass.getWebElementByXpath("(//div[@class=\"save-html column-content editables ng-pristine ng-untouched ng-valid\"])["+groupCount+"]"));
						// BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath("(//div[@class=\"save-html column-content editables ng-pristine ng-untouched ng-valid\"])["+groupCount+"]"));
						//
						// Thread.sleep(1000);
						// BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.vertical));
						// try {
						// wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.enterQuestion)));
						// Thread.sleep(3000);
						// List<WebElement> count= driver.findElements(By.xpath(sl.enterQuestion));
						// int enterQuestion = count.size();
						// System.out.println(enterQuestion);
						// if(enterQuestion>=1) {
						// BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.enterQuestion));
						// String text = BaseClass.getWebElementByXpath(sl.enterQuestion).getText();
						//
						// if(!text.isEmpty()) {
						// BaseClass.getWebElementByXpath(sl.enterQuestion).sendKeys("2");
						// BaseClass.getWebElementByXpath(sl.enterQuestion).clear();
						// System.out.println("Question");
						// }
						// else {
						// BaseClass.getWebElementByXpath(sl.enterQuestion).clear();
						// Thread.sleep(500);
						// BaseClass.getWebElementByXpath(sl.enterQuestion).sendKeys(text);
						// System.out.println("Question");
						// }
						// }else {
						// System.out.println("Header Less Than One");
						// }
						// }
						// catch(Exception e) {
						// try {
						// Thread.sleep(1000);
						// List<WebElement> count= driver.findElements(By.xpath(sl.readerHeader));
						// int searchHeader = count.size();
						// System.out.println(searchHeader);
						// if(searchHeader>=1) {
						// BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.readerHeader));
						// String text = BaseClass.getWebElementByXpath(sl.readerHeader).getText();
						//
						// if(!text.isEmpty()) {
						// BaseClass.getWebElementByXpath(sl.readerHeader).sendKeys("2");
						// BaseClass.getWebElementByXpath(sl.readerHeader).clear();
						// System.out.println("Header");
						// }
						// else {
						// BaseClass.getWebElementByXpath(sl.readerHeader).clear();
						// Thread.sleep(500);
						// BaseClass.getWebElementByXpath(sl.readerHeader).sendKeys(text);
						// System.out.println("Header");
						// }
						// }else {
						// System.out.println("Header Less Than One");
						// }
						// }
						// catch(Exception e1) {
						// System.out.println(e1.getMessage());
						// try {
						// Thread.sleep(1000);
						// List<WebElement> count= driver.findElements(By.xpath(sl.fillInBlank));
						// int fillUp = count.size();
						// System.out.println(fillUp);
						// if(fillUp>=1) {
						// BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.fillInBlank));
						// String text = BaseClass.getWebElementByXpath(sl.fillInBlank).getText();
						//
						// if(!text.isEmpty()) {
						// BaseClass.getWebElementByXpath(sl.fillInBlank).sendKeys("2");
						// BaseClass.getWebElementByXpath(sl.fillInBlank).clear();
						// System.out.println("Fill Up");
						// }
						// else {
						// BaseClass.getWebElementByXpath(sl.fillInBlank).clear();
						// Thread.sleep(500);
						// BaseClass.getWebElementByXpath(sl.fillInBlank).sendKeys(text);
						// System.out.println("Fill Up");
						// }
						// }else {
						// System.out.println("Header Less Than One");
						// }
						// }
						// catch(Exception e2) {
						// System.out.println(e1.getMessage());
						// }
						// }
						// }
						// Thread.sleep(1500);
						// wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.save)));
						// BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.save));
						// BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.save));
						Thread.sleep(1000);
						wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.preview)));
						BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.preview));
						BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.preview));

						wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.edit)));
						BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.edit));
						Thread.sleep(1000);
						BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.edit));
						Thread.sleep(1000);
						wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.preview)));
						BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.preview));
						BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.preview));
						Thread.sleep(1000);
						try {
							// Switch to the iframe by name
							driver.switchTo().frame("previewIFrame");
							Thread.sleep(4000);
							BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.previewLoad));
							driver.switchTo().defaultContent();
						}
						catch(Exception e) {
							driver.switchTo().defaultContent();
							System.out.println("No Preview");
						}
						wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.edit)));
						BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.edit));
						Thread.sleep(1000);
						BaseClass.closeWindow();
						Thread.sleep(1000);
						BaseClass.lastWindow();
						Thread.sleep(1000);
						wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.search)));
						BaseClass.getWebElementByXpath(sl.search).clear();
						BaseClass.getWebElementByXpath(sl.search).sendKeys(finalText+Keys.ENTER);
						Thread.sleep(1000);
						wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='"+finalText+"']")));
						BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath("//span[text()='"+finalText+"']"));
						Thread.sleep(1000);
						wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='"+finalText+"']//following::td[8]/button")));
						BaseClass.executeScripClick(BaseClass.getWebElementByXpath("//span[text()='"+finalText+"']//following::td[8]/button"));
						Thread.sleep(1000);
						wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.text)));
						BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.text));
						Thread.sleep(1000);
						wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.html)));
						BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.html));
						Thread.sleep(1000);
						wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.scorm)));
						BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.scorm));
						Thread.sleep(1000);
						wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.publish)));
						BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.publish));

						WebDriverWait wait5 = new WebDriverWait(driver, Duration.ofSeconds(70));
						wait5.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sl.publishConfirmation)));
						BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.publishConfirmation));

						WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"H","Success");
					}
					catch(Exception e) {
						System.out.println(e.getMessage());
						WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"H","Check Manually");
						Thread.sleep(500);
						wait.until(ExpectedConditions.elementToBeClickable(BaseClass.getWebElementByXpath(sl.text)));
						BaseClass.executeScripClick(BaseClass.getWebElementByXpath(sl.text));
					}
				}
				catch(Exception e) {
					System.out.println(e.getMessage());
					WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"H","Check Manually");
				}

			}


			// WriteDataOnSheet.values(BaseClass.readProperty("SheetName"),"H","Book NA");
			// for (int i = 1; i <totalCount; i++) {
			// BaseClass.getWebElementByXpath(sl.searchTitle).sendKeys(SheetsQuickstart.getColumnRow(i,0));
			// Thread.sleep(1500);
			// try {
			// BaseClass.getWebElementByXpath(sl.firstTitle).click();
			// Thread.sleep(2000);
			// try {
			// BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.kop));
			// BaseClass.getWebElementByXpath(sl.kop).click();
			// }
			// catch(Exception e) {
			// System.out.println("No Kop");
			// }
			// } catch (Exception e) {
			// System.out.println("Title not Found" + i);
			// }
			// try {
			// BaseClass.getWebElementByXpath(sl.searchClear).click();
			// Thread.sleep(500);
			// } catch (Exception e) {
			// System.out.println("Clear not Found");
			// }
			// }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) throws Exception {
		execution();
	}

}