package PageExecution;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.sheets.v4.model.ValueRange;

import BaseClassPackage.BaseClass;
import PageFactory.StudentLocator;

public class BookShelf extends BaseClass{
	private static final String APPLICATION_NAME = "Google Sheets API";
	private static final JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();
	private static final String TOKENS_DIRECTORY_PATH = "tokens/path";

	private static final String existingSpreadSheetID ="1Ndb4y1AHxb51_ACx_UdyoXUwbAurs9h6lzQTuF7Anc0";
	private static final List<String> SCOPES = Arrays.asList(SheetsScopes.SPREADSHEETS,SheetsScopes.DRIVE);
	private static final String CREDENTIALS_FILE_PATH = "/credentials.json";


	static Sheets.Spreadsheets spreadsheets;

	private static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
		InputStream in = SheetWriteExample.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
		if (in == null) {
			throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
		}
		GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

		GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
				HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, SCOPES)
				.setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
				.setAccessType("offline")
				.build();

		LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
		return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
	}

	public static void closeAlert() throws AWTException {
		Robot ro = new Robot();
		ro.keyPress(KeyEvent.VK_TAB);
		ro.keyRelease(KeyEvent.VK_TAB);
		ro.keyPress(KeyEvent.VK_TAB);
		ro.keyRelease(KeyEvent.VK_TAB);
		ro.keyPress(KeyEvent.VK_ENTER);
		ro.keyRelease(KeyEvent.VK_ENTER);
	}
	
	
	public static void login() throws Exception {
		StudentLocator sl = new StudentLocator();
		try {
			BaseClass.browserSelect(BaseClass.readProperty("BrowserType"));
			BaseClass.loadUrl(BaseClass.readProperty("Url"));
			Thread.sleep(2000);
			closeAlert();
			BaseClass.getWebElementByXpath(sl.userName).sendKeys(BaseClass.readProperty("Username"));
			BaseClass.getWebElementByXpath(sl.passWord).sendKeys(BaseClass.readProperty("Password"));
			BaseClass.getWebElementByXpath(sl.submit).click();
			final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
			final String spreadsheetId = "1Ndb4y1AHxb51_ACx_UdyoXUwbAurs9h6lzQTuF7Anc0";
			final String range = BaseClass.readProperty("SheetName")+"!B:B"; // specify the cell to write to

			Sheets service = new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
					.setApplicationName(APPLICATION_NAME).build();
			ValueRange response = service.spreadsheets().values().get(spreadsheetId, range).execute();
			int totalCount = 0;
			List<List<Object>> values = response.getValues();
			if(values == null || values.isEmpty()) {
				System.out.println("No Data Found");
			}
			else {
				totalCount  = values.size();
				int totalRow = totalCount-1;
				System.out.println("Total Count: " + totalRow);
				for (List<Object> row : values) {
					if (!row.isEmpty()) {
					}
				}
			}
			
//			for (int i = 1; i <totalCount; i++) {
//				BaseClass.getWebElementByXpath(sl.searchTitle).sendKeys(SheetsQuickstart.getColumnRow(i,0));
//				Thread.sleep(1500);
//				try {
//						BaseClass.getWebElementByXpath(sl.firstTitle).click();
//						Thread.sleep(2000);
//						try {
//							BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(sl.kop));
//							BaseClass.getWebElementByXpath(sl.kop).click();
//						}
//						catch(Exception e) {
//								System.out.println("No Kop");
//							}
//				} catch (Exception e) {
//					System.out.println("Title not Found" + i);
//				}
//				try {
//				BaseClass.getWebElementByXpath(sl.searchClear).click();
//				Thread.sleep(500);
//				} catch (Exception e) {
//					System.out.println("Clear not Found");
//				}
//			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws Exception {
		login();
	}
}
