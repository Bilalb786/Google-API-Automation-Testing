package PageFactory;

public class StudentLocator {
   
	
	//CL Locator
	public String search = "//input[@id=\"test_headersearch_txt\"]";
	public String firstValue = "(//tbody[@role=\"rowgroup\"]/tr)[1]";
	public String firstValueText = "(//div[@class=\"mat-institute text-with-two-line\"]/span)[1]";
	public String firstValueInfo = "//div[@class=\"mat-institute text-with-two-line\"]//following::td[11]/button";
	public String infoDetails ="//button[@id=\"test_adminContentlist_info_btn\"]";
	public String bannerTitle ="//div[@class=\"banner-title-text\"]";
	public String bannerTitleClose ="//button[@class=\"close-icon-btn button\"]/span";
	public String text ="//mat-selection-list[@id=\"test_administrator_contenttype_ddl\"]/mat-list-option[1]";
	public String activity ="//mat-selection-list[@id=\"test_administrator_contenttype_ddl\"]/mat-list-option[2]";
	public String activityText = "(//tbody[@role=\"rowgroup\"]/tr)[1]";
	public String student = "//p[text()='Instructions for Students']";
	public String teacher = "//p[text()='Instructions for Teacher']";
	
	public String preview = "//button[@class=\"btn previw_btn btn previw_btn-lg\"]";
	public String step1 = "(//div[text()='Step: 1']//following::div[1]//following::div[1]/p)[1]";
	public String stepText = "(//div[text()='Step: 1']//following::div[1]//following::div[1]/p[2])[1]";
//	public String readerInside = "(//div[@id=\"desktop_view\"]/div[1]/div[2]//following::form/div[3]/div)[1]";
	public String readerInside = "//div[@placeholder=\"Header Text\"]/span[1]";
	public String readerHeader = "(//div[@placeholder=\"Header Text\"])[1]";
	public String enterQuestion = "(//div[contains(@placeholder, 'Question')])[1]";
	public String fillInBlank   = "(//div[@placeholder=\"Fill in the blanks\"])[1]";
	public String readerInside1 = "(//div[@id=\"desktop_view\"]/div[1]/div[2]//following::form/div[1]/div[2]/div)[1]";
	public String readerInside2 = "//div[@id=\"desktop_view\"]/div[1]/div[2]/section/section/figure";
	public String groupActivity = "//div[@class=\"save-html column-content editables ng-pristine ng-untouched ng-valid\"]";
	public String groupActivity1 = "(//div[@class=\"save-html column-content editables ng-pristine ng-untouched ng-valid\"])[1]";
	public String vertical    = "//img[@src=\"images/groupVertical.png\"]";
	public String video    = "(//video[@title=\"Video\"])[1]";
	public String previewLoad = "(//article[@data-platform=\"prod\"])[1]";
	public String save = "//button[@class=\"save save_btn btn\"]";
	public String saveMsg = "//span[text()='Page saved successfully.']";
	public String edit = "//button[@class=\"btn previw_btn edit-prv-btn\"]";
	public String html = "//span[text()='HTML']";
	public String scorm = "//span[text()=' SCORM ']";
	public String publish = "//span[text()='Publish']";
	public String publishConfirmation ="//span[text()=' Activity published successfully, Now you can add this activity to your ebook through the enrichment process. ']";
	
	
	//Login locator
	public String acceptCookies = "//button[@aria-label=\"Godkänn alla\"]";
	public String login = "//a[text()='Logga in']";
	public String userName = "//input[@id=\"login-username\"]";
	public String submit = "//button[@id=\"btnenabled\"]";
	public String passWord = "//input[@id=\"login-password\"]";
	public String passWordsubmit = "//button[@class=\"mdl-button mdl-js-button mdl-button--raised mdl-button--colored right rippler\"]";

	//5.0 Search Locator
	public String searchTitle = "//input[@id=\"search-bar\"]";
	public String firstTitle = "//ul[@class=\"MuiList-root MuiList-padding css-1j5xsxb\"]/li[1]";
	public String fortsätt = "//a[text()='Fortsätt']";
	public String Öppna = "//a[text()='Öppna']";
	public String ÖppnaBok = "//a[text()='Öppna bok']";
	public String kop = "//button[text()='Köp']";
	public String book = "(//div[@class=\"kitaboo-render-container\"]/div/iframe)[1]";
	public String toggleOpen = "//button[@aria-label=\"Omflödande vy\"]";
	public String toggleClose = "//button[@aria-label=\"Fast vy\"]";
	public String thumbnailIcon = "//button[@id=\"thumbnailButton\"]";
	public String searchIcon = "//button[@id=\"searchButton\"]";
	public String searchInput = "//input[@id=\"searchInputText\"]";
	public String searchList  = "//div[@id=\"searchlist\"]";
	public String searchClear  = "//button[@aria-label=\"Ta bort sökterm\"]";
	public String groupsearchlist  = "//div[@id=\"groupsearchlist\"]";
	public String searchClose = "//div[@id=\"closeSearchPanel\"]";
	public String tocIcon = "//button[@id=\"tocButton\"]";
	public String epubSearchFrame = "(//div[@class=\"kitaboo-iframe-container reflow-layout-epub\"]/iframe)[1]";

	//6.0 Highlight locator
	public String highlightIcon = "//button[@id=\"Highlights\"]";
	public String orangeColor = "//button[@aria-label=\"Orange\"]";
	public String nextButton = "//button[@id=\"default_next_bttn\"]";

	//6.0 Reader locator
	public String thumbIcon6 = "//button[@id=\"Thumbnail\"]";
	public String toggleOpen6 = "//mat-icon[@class=\"mat-icon notranslate page-icon material-icons toggle_reflowable_icon mat-icon-no-color\"]";
	public String searchIcon6 = "//button[@id=\"Search\"]";
	public String searchInput6 = "//input[@id=\"searchinput\"]";
	public String searchList6  = "//div[@class=\"search-list-result ng-star-inserted\"]";
	public String searchClose6 = "//button[@id=\"extraClose\"]";
	public String groupsearchlist6  = "//div[@class=\"search-list-result ng-star-inserted\"]";
	public String tocIcon6 = "//button[@id=\"Toc\"]";
	public String firstTocList6 = "(//li[@id=\"contentList\"])[1]";
	public String firstChapter6 = "//app-contents/div/div/div/ul/li[1]";


}
