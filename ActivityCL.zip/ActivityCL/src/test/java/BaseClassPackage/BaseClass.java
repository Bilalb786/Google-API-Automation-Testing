package BaseClassPackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.Select;

import PageExecution.SheetsQuickstart;
import PageFactory.StudentLocator;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass extends SheetsQuickstart{

	public static WebDriver driver;


	public static void browserSelect(String option) throws IOException {
		switch (option) {
		case "chrome":
//			WebDriverManager.chromedriver().setup();
			System.setProperty("webdriver.chrome.driver", BaseClass.readProperty("ChromeDriverPath"));
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			System.out.println("Chrome Browser is Launched");
			break;
		case "edge":
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			driver.manage().window().maximize();
			System.out.println("Edge Browser is Launched");
			break;
		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			System.out.println("FireFox Browser is Launched");
			break;
		}
	}
	public static void browserLaunch(){
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	public static void edgebrowserLaunch(){
		WebDriverManager.edgedriver().setup();
		driver = new EdgeDriver();
		driver.manage().window().maximize();
	}
	public static void firefoxbrowserLaunch(){
		WebDriverManager.firefoxdriver().setup();
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
	}
	public static void loadUrl(String url){
		driver.navigate().to(url);
	}
	public static void implicitWait(){
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	public static void windowHandles(int window) {
		Set<String> parentwindow =driver.getWindowHandles();
		List<String> list = new ArrayList<String>();
		for(String windows: parentwindow) {
			list.add(windows);
		}
		driver.switchTo().window(list.get(window));
	}
	public static void lastWindow() {
		Set<String> parentwindow =driver.getWindowHandles();
		List<String> list = new ArrayList<String>();
		for(String windows: parentwindow) {
			list.add(windows);
		}
		driver.switchTo().window(list.get(list.size()-1));
	}
	public static String getUrl() {
		return driver.getCurrentUrl();
	}
	public static String getPageSource() {
		return driver.getPageSource();
	}
	public static String getTitle() {
		return driver.getTitle();
	}
	public static WebElement getWebElementById(String id) {
		return driver.findElement(By.id(id));
	}
	public static WebElement getWebElementByName(String name) {
		return driver.findElement(By.name(name));
	}
	public static WebElement getWebElementByClassName(String classname) {
		return driver.findElement(By.className(classname));
	}
	public static WebElement getWebElementByXpath(String xpath) {
		return driver.findElement(By.xpath(xpath));
	}
	public static WebElement getWebElementByCSS(String selector) {
		return driver.findElement(By.cssSelector(selector));
	}
	public static void selectByValue(WebElement ele , String value) {
		Select ss = new Select(ele);
		ss.selectByValue(value);
	}
	public static void selectByVisibleText(WebElement ele , String text) {
		Select ss = new Select(ele);
		ss.selectByVisibleText(text);
	}
	public static void selectByIndex(WebElement ele , int index) {
		Select ss = new Select(ele);
		ss.selectByIndex(index);
	}
	public static void simpleAlert() {
		Alert alert = driver.switchTo().alert();
		alert.accept();
	}
	public static void moveToElement(WebElement from) {
		Actions ac = new Actions(driver);
		ac.moveToElement(from).build().perform();
	}
	public static void penDragAndDrop(WebElement from, int x, int y) {
		Actions ac = new Actions(driver);
		ac.dragAndDropBy(from, x, y).build().perform();
	}
	public static void moveToGivenPoint(WebElement from, int x, int y) {
		Actions action = new Actions(driver);
		action.clickAndHold(from);
		action.moveByOffset(x, y).build().perform();
		action.click();
	}
	public static void movetoAction(WebElement elem , WebElement elem1) {
		Actions ac = new Actions(driver);
		ac.dragAndDrop(elem,elem1).build().perform();
	}
	public static void doubleclickAction(WebElement eleme) {
		Actions ac = new Actions(driver);
		ac.doubleClick(eleme).build().perform();
	}
	public static void executeScripClick(WebElement exe) {
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", exe);
	}
	public static void executeScripScroll(WebElement scrl) {
		JavascriptExecutor js1 = (JavascriptExecutor)driver;
		js1.executeScript("arguments[0].scrollIntoView(true);",scrl);
	}
	public static void executeScripScrollDown() {
		JavascriptExecutor js2 = (JavascriptExecutor)driver;
		js2.executeScript("window.scrollBy(0,500)");
	}
	public static void executeScripHighlighter(WebElement highlight) {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;  
		jsExecutor.executeScript("arguments[0].style.border='2px solid red'", highlight);
	}
	public static void executeScripHighlighterBgColor(WebElement highlightBg) {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;  
		jsExecutor.executeScript("arguments[0].setAttribute('style', 'border:2px solid red; background:yellow')", highlightBg);
	}

	public static String path = System.getProperty("user.dir");
	public static void ScreenShot(WebDriver driver, String name) {
		// Specify the folder path where you want to save the extent report
		String folderPath = path + "/Screenshot/";

		// Create folder if it doesn't exist
		File folder = new File(folderPath);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		try {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File src = ts.getScreenshotAs(OutputType.FILE);
			File des = new File(folderPath + name + ".png");
			FileHandler.copy(src, des);
			//	        System.out.println("Screenshot saved at: " + des.getAbsolutePath());
		} catch (IOException e) {
			//	        e.printStackTrace();
			System.err.println("Error occurred while taking a screenshot: " + e.getMessage());
		}
	}
	public static String readProperty(String Key) throws IOException {
		File file = new File(path+"/InputCLGsheet.properties/");
		FileInputStream fis = new FileInputStream(file);
		Properties po = new Properties();
		po.load(fis);
		String value = po.getProperty(Key);
		return value;
	}
	
	public static void login(String url) throws Exception {
		StudentLocator app =new StudentLocator();
		switch (url) {
		case "Google":
			System.out.println(BaseClass.getColumnRow(0, 1));	
//			BaseClass.loadUrl(BaseClass.getColumnRow(1, 3));
//			System.out.println(BaseClass.getTitle());
//			BaseClass.executeScripHighlighter(BaseClass.getWebElementByXpath(app.logoImageIOS));
			break;
		case "Apple":
			break;
		}
	}
	public static void closeWindow(){
		driver.close();
	}
	public static void referesh(){
		driver.navigate().refresh();
	}
	public static void BrowserClose(){
		driver.quit();
		System.out.println("Browser closed");
	}
             public static void main(String[] args) throws Exception {
            	 login("Google");
			}



}